from typing import List, Optional, Union
from pydantic import BaseModel, Field

class ViralClip(BaseModel):
    title: str = Field(description="Catchy, specific clip title, max 8 words, in the transcript language. Avoid first-person framing. Use a speaker's name or role only when explicitly established by the transcript or video context; otherwise use neutral, topic-focused wording.")
    start_time: float = Field(description="Clip start in seconds, aligned to a sentence boundary")
    end_time: float = Field(description="Clip end in seconds, aligned to a sentence boundary")
    hook_time: float = Field(description="Absolute timestamp in seconds from video start where the potential hook occurs inside this clip range (must be >= start_time and <= end_time)")
    virality_score: int = Field(description="Overall AI viral potential score from 1-100, calibrated from the component scores")
    hook_strength: int = Field(default=0, ge=0, le=100, description="Strength of the opening hook in the first seconds, 0-100")
    emotional_impact: int = Field(default=0, ge=0, le=100, description="Emotional intensity, surprise, humor, tension, or inspiration, 0-100")
    standalone_value: int = Field(default=0, ge=0, le=100, description="How complete and understandable the clip is without the full video, 0-100")
    clarity: int = Field(default=0, ge=0, le=100, description="Clarity and specificity of the spoken point, 0-100")
    shareability: int = Field(default=0, ge=0, le=100, description="Likelihood viewers would share or discuss this moment, 0-100")
    score_reason: str = Field(default="", description="Short evidence-based explanation for the overall score in the transcript language")
    key_quotes: List[str] = Field(description="1-2 key quotes from the clip")
    transcript: str = Field(description="Spoken text of the clip")
    title_suggestion: str = Field(default="", description="A distinct, specific, compelling alternative title under 8 words, grounded in this clip. Avoid generic placeholders, invented claims, and first-person narration. Match the video language.")
    caption_suggestion: str = Field(default="", description="Natural, polished 1-2 sentence social caption with a strong relevant opening and a concrete clip detail or takeaway. No filler, generic templates, invented claims, or first-person editor voice. Match the video language.")
    hashtag_suggestion: str = Field(default="", description="Provide 3-6 distinct, focused hashtags relevant to this clip topic. No duplicates, spam tags, or unrelated generic hashtags. Match the video language.")

class ViralClipGemini(BaseModel):
    title: str = Field(description="Catchy, specific clip title, max 8 words, in the EXACT SAME LANGUAGE as the video transcript (STRICT ZERO-TRANSLATION RULE: English stays English, Indonesian stays Indonesian, Spanish stays Spanish). Avoid first-person framing. Use a speaker's name or role only when explicitly established by the transcript or video context; otherwise use neutral, topic-focused wording.")
    start_time: float = Field(description="Clip start in seconds, aligned to a sentence boundary")
    end_time: float = Field(description="Clip end in seconds, aligned to a sentence boundary")
    hook_time: float = Field(description="Absolute timestamp in seconds from video start where the potential hook occurs inside this clip range (must be >= start_time and <= end_time)")
    virality_score: int = Field(description="Overall AI viral potential score from 1-100, calibrated from the component scores")
    hook_strength: int = Field(default=0, ge=0, le=100, description="Strength of the opening hook in the first seconds, 0-100")
    emotional_impact: int = Field(default=0, ge=0, le=100, description="Emotional intensity, surprise, humor, tension, or inspiration, 0-100")
    standalone_value: int = Field(default=0, ge=0, le=100, description="How complete and understandable the clip is without the full video, 0-100")
    clarity: int = Field(default=0, ge=0, le=100, description="Clarity and specificity of the spoken point, 0-100")
    shareability: int = Field(default=0, ge=0, le=100, description="Likelihood viewers would share or discuss this moment, 0-100")
    score_reason: str = Field(default="", description="Short evidence-based explanation for the overall score in the transcript language")
    key_quotes: List[str] = Field(description="1-2 verbatim quotes directly spoken in the clip, in the original language of the video without translation")
    title_suggestion: str = Field(default="", description="A distinct, specific, compelling alternative title under 8 words in the EXACT SAME LANGUAGE as the video transcript. Avoid generic placeholders, invented claims, and first-person narration. Ground it in this clip.")
    caption_suggestion: str = Field(default="", description="A natural, polished 1-2 sentence social caption in the EXACT SAME LANGUAGE as the video transcript, with a strong relevant opening and a concrete clip detail or takeaway. No filler, generic templates, invented claims, or first-person editor voice.")
    hashtag_suggestion: str = Field(default="", description="Provide 3-6 distinct, focused hashtags relevant to this clip topic in the SAME LANGUAGE as the video transcript. No duplicates, spam tags, or unrelated generic hashtags.")

class VideoAnalysis(BaseModel):
    summary: str = Field(description="1-2 sentence video summary in the EXACT SAME LANGUAGE as the video transcript (STRICT ZERO-TRANSLATION RULE: English stays English, Indonesian stays Indonesian, Spanish stays Spanish), followed by 2-4 relevant hashtags")
    clips: List[ViralClipGemini] = Field(description="List of viral clip candidates, sorted by virality_score desc")

class AnalyzeRequest(BaseModel):
    url: str = Field(..., description="YouTube video URL")
    duration: str = Field("30s", description="Target clip duration: '15s', '30s', '60s', or 'auto'")
    api_key: Optional[str] = Field(None, description="Optional custom Gemini or fallback API key provided by the user")
    api_provider: Optional[str] = Field("gemini", description="AI provider: 'gemini' or 'openrouter'")
    openrouter_key: Optional[str] = Field(None, description="Optional OpenRouter API key provided by the user")
    openrouter_model: Optional[str] = Field(None, description="Preferred OpenRouter model name (e.g. 'google/gemini-2.5-flash')")
    model: Optional[str] = Field("gemini-2.5-flash", description="Preferred model name")
    custom_prompt: Optional[str] = Field(None, description="Optional custom focus prompt for clips search")
    range_start: Optional[float] = Field(None, description="Search range start in seconds")
    range_end: Optional[float] = Field(None, description="Search range end in seconds")
    subtitles: Optional[str] = Field(None, description="Optional manual subtitles text (SRT or TXT)")
    subtitles_filename: Optional[str] = Field(None, description="Optional manual subtitles filename")
    target_clip_count: Optional[Union[int, str]] = Field(None, description="Optional target number of clips or 'auto'")
    proxy: Optional[str] = Field(None, description="Optional custom proxy URL")
    cookies: Optional[str] = Field(None, description="Optional user YouTube cookies from browser LocalStorage")
    subtitle_enabled: bool = Field(True, description="Enable subtitle retrieval and transcription")
    transcript_language: Optional[str] = Field("id", description="Target transcript language for YouTube auto transcripts: 'id' or 'en'")

class HeatmapPoint(BaseModel):
    start_time: float
    end_time: float
    value: float

class TranscriptLine(BaseModel):
    start: float
    end: float
    text: str
    engagement: Optional[float] = None

class AnalyzeResponse(BaseModel):
    video_id: str
    title: str
    channel: Optional[str] = None
    duration: float
    heatmap: List[HeatmapPoint]
    summary: str
    clips: List[ViralClip]
    transcript: Optional[List[TranscriptLine]] = None
    model: Optional[str] = None
    video_url: Optional[str] = None
    source_type: Optional[str] = "youtube"
    subtitle_enabled: Optional[bool] = True
