"""Conservative validation for untrusted AI-generated clip copy and scores."""

import math
import re
import unicodedata


def _normalize_quote_text(value) -> str:
    """Normalize text for conservative transcript quote matching."""
    if not isinstance(value, str):
        return ""
    value = unicodedata.normalize("NFKC", value).casefold()
    # Ignore punctuation and layout differences, but preserve letters/numbers.
    return " ".join(re.findall(r"\w+", value, flags=re.UNICODE))


def _fully_contained_transcript_text(transcript_lines, clip_start: float, clip_end: float) -> str:
    """Build quote-verification text only from complete transcript lines inside the clip."""
    if not isinstance(transcript_lines, list):
        return ""
    try:
        clip_start = float(clip_start)
        clip_end = float(clip_end)
    except (TypeError, ValueError, OverflowError):
        return ""
    if not (math.isfinite(clip_start) and math.isfinite(clip_end) and clip_start < clip_end):
        return ""
    contained = []
    for line in transcript_lines:
        if not isinstance(line, dict) or not isinstance(line.get("text"), str):
            continue
        try:
            line_start = float(line.get("start"))
            line_end = float(line.get("end"))
        except (TypeError, ValueError, OverflowError):
            continue
        if not (math.isfinite(line_start) and math.isfinite(line_end)):
            continue
        if clip_start <= line_start < line_end <= clip_end:
            text = " ".join(line["text"].split()).strip()
            if text:
                contained.append(text)
    return " ".join(contained)


def _validated_key_quotes(raw_quotes, clip_transcript: str, has_transcript: bool) -> list[str]:
    """Keep at most two model quotes that are actually present in this clip."""
    if not has_transcript or not isinstance(raw_quotes, list) or not clip_transcript:
        return []
    source = _normalize_quote_text(clip_transcript)
    if not source:
        return []
    accepted = []
    seen = set()
    for quote in raw_quotes:
        if not isinstance(quote, str):
            continue
        quote = " ".join(quote.split()).strip()
        if len(quote) > 300:
            quote = quote[:300].rsplit(" ", 1)[0].rstrip()
        normalized = _normalize_quote_text(quote)
        # Very short fragments are too ambiguous to present as verified quotes.
        if len(normalized.split()) < 3 or f" {normalized} " not in f" {source} " or normalized in seen:
            continue
        accepted.append(quote[:300])
        seen.add(normalized)
        if len(accepted) == 2:
            break
    return accepted


def _clean_model_copy(value, max_chars: int) -> str:
    """Normalize untrusted model copy to bounded, plain display text."""
    if not isinstance(value, str):
        return ""
    value = unicodedata.normalize("NFKC", value)
    # Remove control characters (except ordinary whitespace), then collapse layout.
    value = "".join(
        char for char in value
        if char in "\n\r\t" or unicodedata.category(char)[0] != "C"
    )
    value = " ".join(value.split()).strip()
    return value[:max_chars].rstrip()


def _validated_title(value, max_words: int = 8) -> str:
    """Keep a concise, non-placeholder title without inventing replacement copy."""
    title = _clean_model_copy(value, 160)
    if not title:
        return ""
    words = title.split()
    if len(words) > max_words:
        title = " ".join(words[:max_words]).rstrip(" ,:;—-")
    normalized = re.sub(r"[^\w]+", " ", title.casefold(), flags=re.UNICODE).strip()
    placeholders = {
        "untitled", "clip", "video clip", "interesting moment",
        "viral moment", "best moment", "key moment", "important discussion",
    }
    if normalized in placeholders:
        return ""
    return title


def _validated_caption(value, max_chars: int = 500) -> str:
    """Bound caption text and avoid passing non-text model values to the schema."""
    return _clean_model_copy(value, max_chars)


def _validated_score_reason(value, max_chars: int = 300) -> str:
    """Keep score explanations short and type-safe."""
    return _clean_model_copy(value, max_chars)


def _normalized_title_identity(value: str) -> str:
    return " ".join(re.findall(r"\w+", value.casefold(), flags=re.UNICODE))


def _validated_hashtags(value, limit: int = 6) -> str:
    """Return distinct, syntactically valid hashtags; never invent missing tags."""
    if not isinstance(value, str) or not value.strip():
        return ""
    tags = []
    seen = set()
    for match in re.finditer(r"(?<![\w#])#([\w\u00C0-\u024F]+)", value, flags=re.UNICODE):
        tag = match.group(1).strip("_")
        normalized = tag.casefold()
        if len(tag) < 2 or normalized in seen:
            continue
        seen.add(normalized)
        tags.append("#" + tag.lower())
        if len(tags) >= limit:
            break
    return " ".join(tags)


def _bounded_score(value) -> int:
    """Normalize untrusted model score output to an integer in 0..100."""
    try:
        return max(0, min(100, int(float(value or 0))))
    except (TypeError, ValueError, OverflowError):
        return 0


def _calibrate_viral_score(clip: dict) -> int:
    """Use a transparent weighted score when component ratings are available."""
    weights = {
        "hook_strength": 0.25,
        "emotional_impact": 0.20,
        "standalone_value": 0.25,
        "clarity": 0.15,
        "shareability": 0.15,
    }
    values = {}
    for key in weights:
        try:
            values[key] = max(0, min(100, int(float(clip.get(key, 0) or 0))))
        except (TypeError, ValueError, OverflowError):
            values[key] = 0
    # Older models and recovery paths may not return component scores.
    if not any(values.values()):
        try:
            return max(0, min(100, int(float(clip.get("virality_score", 0) or 0))))
        except (TypeError, ValueError, OverflowError):
            return 0
    return round(sum(values[key] * weight for key, weight in weights.items()))


