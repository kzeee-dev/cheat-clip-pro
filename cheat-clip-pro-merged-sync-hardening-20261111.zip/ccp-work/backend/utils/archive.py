"""Small, dependency-free helpers for safe archive creation."""

import os
import tempfile
import zipfile
from pathlib import Path
from typing import Iterable, Tuple


def create_nonempty_zip(
    destination: Path,
    entries: Iterable[Tuple[Path, str]],
) -> bool:
    """Atomically create a ZIP containing only existing, non-empty files.

    Returns False and removes any stale destination when no usable entries
    remain. A failed write never leaves a partial archive at destination.
    """
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=str(destination.parent)
    )
    os.close(fd)
    temp_path = Path(temp_name)
    written = 0
    try:
        with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for source, archive_name in entries:
                source = Path(source)
                if not source.is_file() or source.stat().st_size <= 0:
                    continue
                archive.write(source, arcname=archive_name)
                written += 1
        if written == 0:
            destination.unlink(missing_ok=True)
            return False
        temp_path.replace(destination)
        return True
    except Exception:
        raise
    finally:
        temp_path.unlink(missing_ok=True)
