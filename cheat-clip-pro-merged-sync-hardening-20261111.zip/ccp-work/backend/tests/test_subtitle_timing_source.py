"""Regression tests for finite, clip-bounded ASS subtitle timing."""
import ast
import math
from pathlib import Path


def _load_timing_helpers():
    source = Path(__file__).resolve().parents[1] / "video_engine.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    wanted = {"format_ass_timestamp", "_normalize_subtitle_word_times"}
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    namespace = {"math": math, "List": list, "Dict": dict, "Any": object}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), "exec"), namespace)
    return namespace


def test_subtitle_word_times_apply_offset_and_stay_inside_clip():
    helpers = _load_timing_helpers()
    normalize = helpers["_normalize_subtitle_word_times"]
    result = normalize([
        {"word": "before", "start": -0.4, "end": 0.2},
        {"word": "middle", "start": 1.0, "end": 1.4},
        {"word": "late", "start": 4.8, "end": 5.4},
    ], 5.0, 0.2)
    assert len(result) == 2
    assert result[0]["start"] == 0.0 and result[0]["end"] == 0.4
    assert abs(result[1]["start"] - 1.2) < 1e-9
    assert abs(result[1]["end"] - 1.6) < 1e-9
    assert all(0.0 <= w["start"] < w["end"] <= 5.0 for w in result)


def test_subtitle_word_times_reject_nan_invalid_and_reversed_intervals():
    normalize = _load_timing_helpers()["_normalize_subtitle_word_times"]
    result = normalize([
        {"word": "nan", "start": float("nan"), "end": 1.0},
        {"word": "inf", "start": 1.0, "end": float("inf")},
        {"word": "bad", "start": "oops", "end": 2.0},
        {"word": "reverse", "start": 2.0, "end": 1.0},
        {"word": "valid", "start": 0.5, "end": 0.8},
    ], 3.0, 0.0)
    assert [w["word"] for w in result] == ["valid"]


def test_subtitle_offset_and_duration_are_safely_bounded():
    normalize = _load_timing_helpers()["_normalize_subtitle_word_times"]
    result = normalize([
        {"word": "first", "start": 29.8, "end": 30.2},
        {"word": "last", "start": 99.0, "end": 100.0},
    ], 4.0, -999.0)
    assert len(result) == 1
    assert result[0]["start"] == 0.0
    assert abs(result[0]["end"] - 0.2) < 1e-9


def test_ass_timestamp_rounds_centiseconds_with_carry():
    fmt = _load_timing_helpers()["format_ass_timestamp"]
    assert fmt(1.999) == "0:00:02.00"
    assert fmt(59.999) == "0:01:00.00"
    assert fmt(float("nan")) == "0:00:00.00"
    assert fmt(-1) == "0:00:00.00"


def test_ass_subtitle_generation_uses_clip_bounded_word_normalizer():
    source = Path(__file__).resolve().parents[1] / "video_engine.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "generate_ass_file")
    rendered = ast.unparse(fn)
    assert "_normalize_subtitle_word_times(words, duration_seconds, subtitle_offset_seconds)" in rendered
    assert "if c_end > c_start" in rendered


def _load_transcriber(whisper_model=None):
    source = Path(__file__).resolve().parents[1] / "video_engine.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "transcribe_clip_words")

    class _Logger:
        def info(self, *args, **kwargs):
            pass

        def warning(self, *args, **kwargs):
            pass

    import os
    import re
    import threading
    from typing import Any, Dict, List, Optional

    namespace = {
        "os": os,
        "math": math,
        "re": re,
        "Any": Any,
        "Dict": Dict,
        "List": List,
        "Optional": Optional,
        "logger": _Logger(),
        "get_whisper_model": lambda: whisper_model,
        "_WHISPER_LOCK": threading.Lock(),
        "clean_caption_text": lambda value: " ".join(str(value).split()),
        "_normalize_subtitle_word_times": _load_timing_helpers()["_normalize_subtitle_word_times"],
    }
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(source), "exec"), namespace)
    return namespace["transcribe_clip_words"]


def test_fallback_transcript_skips_malformed_times_and_bounds_words_to_clip():
    transcribe = _load_transcriber()
    result = transcribe(
        "missing.mp4",
        [
            {"text": "bad timestamp", "start": "not-a-time", "end": 3},
            {"text": "outside", "start": 2, "end": 4},
            {"text": "inside words", "start": 10, "end": 12},
            None,
            {"text": "nan timestamp", "start": float("nan"), "end": 15},
        ],
        10,
        11,
        "en",
    )
    assert result
    assert all(0.0 <= word["start"] < word["end"] <= 1.0 for word in result)
    assert all(word["word"] in {"inside", "words"} for word in result)


def test_fallback_transcript_handles_invalid_end_and_duration_without_crashing():
    transcribe = _load_transcriber()
    result = transcribe(
        "missing.mp4",
        [
            {"text": "invalid timing", "start": 1, "end": "bad", "duration": 2},
            {"text": "valid timing", "start": 2, "duration": 1},
        ],
        0,
        5,
        "en",
    )
    assert result
    assert all(0.0 <= word["start"] < word["end"] <= 5.0 for word in result)


def test_whisper_word_timestamps_are_normalized_to_downloaded_clip_duration(tmp_path):
    class _FakeWhisper:
        def transcribe(self, _path, **_kwargs):
            return {
                "segments": [{
                    "words": [
                        {"word": " before", "start": -0.2, "end": 0.1},
                        {"word": "inside", "start": 0.2, "end": 0.6},
                        {"word": "late", "start": 0.9, "end": 1.4},
                        {"word": "nan", "start": float("nan"), "end": 1.0},
                    ]
                }]
            }

    video = tmp_path / "clip.mp4"
    video.write_bytes(b"clip")
    transcribe = _load_transcriber(_FakeWhisper())
    result = transcribe(str(video), None, 20.0, 21.0, "en")
    assert [word["word"] for word in result] == ["before", "inside", "late"]
    assert all(0.0 <= word["start"] < word["end"] <= 1.0 for word in result)
