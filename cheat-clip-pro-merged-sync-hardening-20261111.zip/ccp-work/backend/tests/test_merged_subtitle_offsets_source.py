"""Regression tests for merged subtitle offsets based on actual segment durations."""
import ast
import math
import subprocess
from pathlib import Path


def _load_duration_probe(mock_run):
    source = Path(__file__).resolve().parents[1] / "services" / "render_service.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_probe_media_duration_seconds"
    )
    namespace = {"math": math, "subprocess": subprocess}
    namespace["subprocess"].run = mock_run
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(source), "exec"), namespace)
    return namespace[fn.name]


def test_duration_probe_prefers_actual_segment_duration():
    class _Result:
        returncode = 0
        stdout = "9.72\n"

    probe = _load_duration_probe(lambda *args, **kwargs: _Result())
    assert probe("part.mp4", 10.0) == 9.72


def test_duration_probe_uses_finite_fallback_when_probe_fails():
    class _Result:
        returncode = 1
        stdout = "N/A"

    probe = _load_duration_probe(lambda *args, **kwargs: _Result())
    assert probe("part.mp4", 10.0) == 10.0
    assert probe("part.mp4", float("nan")) == 0.1


def test_merged_subtitle_offsets_use_actual_part_and_merged_durations():
    source = Path(__file__).resolve().parents[1] / "services" / "render_service.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(
        node for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "render_merged_batch_clips"
    )
    rendered = ast.unparse(fn)
    assert "part_durations.append(actual_segment_duration)" in rendered
    assert "seg_dur = part_durations[i]" in rendered
    assert "total_duration_sec = _probe_media_duration_seconds" in rendered


def _load_segment_word_appender():
    source = Path(__file__).resolve().parents[1] / "services" / "render_service.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_append_segment_words"
    )
    namespace = {"math": math, "Any": object, "Dict": dict, "List": list}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(source), "exec"), namespace)
    return namespace[fn.name]


def test_merged_word_offsets_are_clipped_to_actual_segment_duration():
    append_words = _load_segment_word_appender()
    merged = []
    append_words(
        merged,
        [
            {"word": "inside", "start": 0.5, "end": 0.8},
            {"word": "tail", "start": 0.9, "end": 1.4},
            {"word": "outside", "start": 1.2, "end": 1.5},
            {"word": "nan", "start": float("nan"), "end": 1.0},
        ],
        9.72,
        1.0,
    )
    assert [word["word"] for word in merged] == ["inside", "tail"]
    assert merged[0]["start"] == 10.22
    assert merged[1]["start"] == 10.62 and merged[1]["end"] == 10.72


def test_merged_pipeline_uses_segment_word_clamping_helper():
    source = Path(__file__).resolve().parents[1] / "services" / "render_service.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    fn = next(
        node for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "render_merged_batch_clips"
    )
    assert "_append_segment_words" in ast.unparse(fn)
