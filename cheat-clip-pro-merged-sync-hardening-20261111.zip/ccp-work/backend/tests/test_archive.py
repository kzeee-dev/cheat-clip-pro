import tempfile
import unittest
import zipfile
import importlib.util
from unittest.mock import patch
from unittest.mock import patch
from pathlib import Path

# Load this dependency-free helper directly; backend.utils.__init__ imports
# optional video/transcript integrations that are not needed by these tests.
_helper_path = Path(__file__).parents[1] / "utils" / "archive.py"
_spec = importlib.util.spec_from_file_location("archive_helper_under_test", _helper_path)
_archive_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_archive_module)
create_nonempty_zip = _archive_module.create_nonempty_zip


class NonEmptyZipTests(unittest.TestCase):
    def test_creates_archive_with_existing_files_and_unique_names(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = root / "first.mp4"
            second = root / "second.mp4"
            missing = root / "missing.mp4"
            destination = root / "clips.zip"
            first.write_bytes(b"first-video")
            second.write_bytes(b"second-video")

            created = create_nonempty_zip(destination, [
                (first, "Highlight.mp4"),
                (second, "Highlight (1).mp4"),
                (missing, "Missing.mp4"),
            ])

            self.assertTrue(created)
            with zipfile.ZipFile(destination) as archive:
                self.assertEqual(archive.namelist(), ["Highlight.mp4", "Highlight (1).mp4"])
                self.assertEqual(archive.read("Highlight.mp4"), b"first-video")

    def test_empty_entries_do_not_leave_an_empty_or_stale_zip(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / "clips.zip"
            destination.write_bytes(b"old-archive")
            empty = root / "empty.mp4"
            empty.write_bytes(b"")
            missing = root / "missing.mp4"

            created = create_nonempty_zip(destination, [
                (empty, "Empty.mp4"),
                (missing, "Missing.mp4"),
            ])

            self.assertFalse(created)
            self.assertFalse(destination.exists())
            self.assertEqual(list(root.glob("*.tmp")), [])

    def test_failed_write_preserves_previous_archive(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / "clips.zip"
            destination.write_bytes(b"previous-valid-archive")
            source = root / "source.mp4"
            source.write_bytes(b"video")

            with patch("zipfile.ZipFile.write", side_effect=OSError("simulated disk failure")):
                with self.assertRaises(OSError):
                    create_nonempty_zip(destination, [(source, "clip.mp4")])

            self.assertEqual(destination.read_bytes(), b"previous-valid-archive")
            self.assertEqual(list(root.glob(".*.tmp")), [])


if __name__ == "__main__":
    unittest.main()
