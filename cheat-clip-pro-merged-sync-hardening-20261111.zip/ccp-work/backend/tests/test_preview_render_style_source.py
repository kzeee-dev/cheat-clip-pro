"""Source-level parity checks for subtitle preview and ASS render presets."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = (ROOT / "src/components/ClipStudioSection.tsx").read_text(encoding="utf-8")
BACKEND = (ROOT / "backend/video_engine.py").read_text(encoding="utf-8")


def _ass_bgr_to_rgb(value: str) -> str:
    """Convert ASS &HAABBGGRR (opaque presets only) into CSS #RRGGBB."""
    match = re.fullmatch(r"&H00([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})", value)
    assert match, value
    blue, green, red = match.groups()
    return f"#{red}{green}{blue}".upper()


def test_frontend_highlights_match_backend_ass_highlights():
    expected = {
        "viral_pop": "#FFE600",
        "beast_punch": "#00FF66",
        "cyber_violet": "#D946EF",
        "fire_red": "#FF2E2E",
        "electric_cyan": "#00F0FF",
        "golden_aura": "#FFB800",
        "clean_minimal": "#38BDF8",
    }
    for preset, css_color in expected.items():
        frontend_match = re.search(rf"{preset}: \{{ highlight: '([^']+)'", FRONTEND)
        assert frontend_match, preset
        assert frontend_match.group(1).upper() == css_color
        backend_block = re.search(
            rf'(?:if|elif) style_preset == "{preset}":(.*?)(?=\n    elif style_preset ==|\n    else:  # clean_minimal)',
            BACKEND,
            re.S,
        )
        if preset == "clean_minimal":
            backend_block = re.search(r"else:  # clean_minimal or none(.*?)(?=\n\s*# Title styling)", BACKEND, re.S)
        assert backend_block, preset
        ass_color = re.search(r'highlight_color = "([^\"]+)"', backend_block.group(1))
        assert ass_color, preset
        assert _ass_bgr_to_rgb(ass_color.group(1)) == css_color.upper()


def test_preview_scales_outline_and_shadow_to_render_canvas():
    assert "currentStyle.outlineWidth * scale" in FRONTEND
    assert "currentStyle.shadowWidth * scale" in FRONTEND
    assert "WebkitTextStroke" in FRONTEND
    assert "paintOrder: 'stroke fill'" in FRONTEND
    # ASS renderer intentionally keeps word metrics unchanged; preview must not enlarge active words.
    assert "scale(1.08)" not in FRONTEND
    assert "highlight_color = \"&H00F8BD38\"" in BACKEND


def test_title_preview_matches_ass_font_scale_outline_and_shadow():
    assert "titleFontSizePx * 1.30 * scale" in FRONTEND
    assert "(4.4 * (isLandscape ? (320 / 1920) : (320 / 1080)))" in FRONTEND
    assert "const shadow = (2.0 * (isLandscape ? (320 / 1920) : (320 / 1080)))" in FRONTEND
    assert "int(title_font_size_px) * 1.30" in BACKEND
    assert "TitleStyle,{title_font_name or font_name},{title_font_size}" in BACKEND
