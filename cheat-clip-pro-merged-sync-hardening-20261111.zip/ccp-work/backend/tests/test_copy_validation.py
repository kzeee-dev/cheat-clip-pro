import importlib.util
import unittest
from pathlib import Path

# Load the dependency-light validator directly so tests also run in minimal
# environments where backend.utils.__init__ optional integrations are absent.
_MODULE_PATH = Path(__file__).resolve().parents[1] / "utils" / "copy_validation.py"
_SPEC = importlib.util.spec_from_file_location("ccp_copy_validation", _MODULE_PATH)
_VALIDATORS = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_VALIDATORS)

_bounded_score = _VALIDATORS._bounded_score
_calibrate_viral_score = _VALIDATORS._calibrate_viral_score
_normalized_title_identity = _VALIDATORS._normalized_title_identity
_validated_caption = _VALIDATORS._validated_caption
_fully_contained_transcript_text = _VALIDATORS._fully_contained_transcript_text
_validated_hashtags = _VALIDATORS._validated_hashtags
_validated_key_quotes = _VALIDATORS._validated_key_quotes
_validated_score_reason = _VALIDATORS._validated_score_reason
_validated_title = _VALIDATORS._validated_title


class CopyValidationTests(unittest.TestCase):
    def test_title_is_limited_to_eight_words(self):
        title = _validated_title("One two three four five six seven eight nine")
        self.assertEqual(len(title.split()), 8)

    def test_title_rejects_generic_placeholder(self):
        self.assertEqual(_validated_title("Interesting Moment"), "")

    def test_title_rejects_non_string(self):
        self.assertEqual(_validated_title(123), "")

    def test_title_removes_control_characters(self):
        self.assertNotIn("\x00", _validated_title("Clean\x00 Title"))

    def test_alternative_title_identity_ignores_punctuation_and_case(self):
        self.assertEqual(
            _normalized_title_identity("Same title!"),
            _normalized_title_identity("same-title"),
        )

    def test_caption_is_bounded_and_type_safe(self):
        self.assertEqual(len(_validated_caption("x" * 700)), 500)
        self.assertEqual(_validated_caption({"text": "not a string"}), "")

    def test_score_reason_is_bounded(self):
        self.assertEqual(len(_validated_score_reason("x" * 500)), 300)

    def test_hashtags_are_deduplicated_case_insensitively(self):
        self.assertEqual(_validated_hashtags("#Topic #topic #AI #ai"), "#topic #ai")

    def test_hashtags_are_limited_to_six(self):
        raw = " ".join(f"#tag{i}" for i in range(10))
        self.assertEqual(len(_validated_hashtags(raw).split()), 6)

    def test_invalid_hashtag_values_are_ignored(self):
        self.assertEqual(_validated_hashtags(["#nope"]), "")

    def test_quote_source_uses_only_fully_contained_transcript_lines(self):
        lines = [
            {"start": 0, "end": 2, "text": "outside opening"},
            {"start": 2, "end": 4, "text": "inside complete line"},
            {"start": 4, "end": 6, "text": "crosses clip boundary"},
        ]
        self.assertEqual(
            _fully_contained_transcript_text(lines, 1, 5),
            "inside complete line",
        )

    def test_quote_source_rejects_invalid_ranges(self):
        self.assertEqual(_fully_contained_transcript_text([], float("nan"), 5), "")

    def test_quotes_must_be_present_in_clip_transcript(self):
        self.assertEqual(
            _validated_key_quotes(["This quote is missing"], "This is actual transcript text.", True),
            [],
        )

    def test_verbatim_quote_is_retained(self):
        self.assertEqual(
            _validated_key_quotes(["actual transcript text"], "This is the actual transcript text.", True),
            ["actual transcript text"],
        )

    def test_quotes_are_disabled_without_transcript(self):
        self.assertEqual(_validated_key_quotes(["actual transcript text"], "actual transcript text", False), [])

    def test_quotes_are_deduplicated_and_limited_to_two(self):
        quotes = ["one two three", "one two three", "four five six", "seven eight nine"]
        result = _validated_key_quotes(quotes, "one two three four five six seven eight nine", True)
        self.assertEqual(result, ["one two three", "four five six"])

    def test_scores_handle_infinity_and_bounds(self):
        self.assertEqual(_bounded_score(float("inf")), 0)
        self.assertEqual(_bounded_score(150), 100)
        self.assertEqual(_bounded_score(-10), 0)

    def test_weighted_score_is_calibrated(self):
        values = {key: 100 for key in (
            "hook_strength", "emotional_impact", "standalone_value", "clarity", "shareability"
        )}
        self.assertEqual(_calibrate_viral_score(values), 100)


if __name__ == "__main__":
    unittest.main()
