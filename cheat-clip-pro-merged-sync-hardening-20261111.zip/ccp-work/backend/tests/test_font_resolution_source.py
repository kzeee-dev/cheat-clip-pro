"""Regression tests for backend font-family resolution without importing optional app integrations."""
import ast
import logging
import os
from pathlib import Path
from typing import Optional

from PIL import ImageFont


def _load_font_helpers(fonts_dir: Path):
    source = Path(__file__).resolve().parents[1].joinpath("video_engine.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    wanted = {"_resolve_font_file", "get_font", "get_ffmpeg_safe_font_path"}
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    namespace = {
        "Path": Path,
        "Optional": Optional,
        "ImageFont": ImageFont,
        "FONTS_DIR": fonts_dir,
        "os": os,
        "logger": logging.getLogger("font-resolution-test"),
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "font_helpers", "exec"), namespace)
    return namespace


def test_custom_font_resolves_by_embedded_family_name(tmp_path):
    source_font = Path(__file__).resolve().parents[1] / "fonts" / "Outfit.ttf"
    family = ImageFont.truetype(str(source_font), 16).getname()[0]
    uploaded_filename = tmp_path / "random_uploaded_filename.ttf"
    uploaded_filename.write_bytes(source_font.read_bytes())

    helpers = _load_font_helpers(tmp_path)
    resolved = helpers["_resolve_font_file"](family)

    assert resolved == uploaded_filename
    assert helpers["get_font"](family, 32).getbbox("Cheat Clip Pro")
    assert Path(helpers["get_ffmpeg_safe_font_path"](family).replace("\\:", ":")) == uploaded_filename.resolve()


def test_missing_font_uses_montserrat_fallback(tmp_path):
    fonts_dir = tmp_path / "fonts"
    fonts_dir.mkdir()
    montserrat = Path(__file__).resolve().parents[1] / "fonts" / "Montserrat.ttf"
    (fonts_dir / "Montserrat.ttf").write_bytes(montserrat.read_bytes())
    helpers = _load_font_helpers(fonts_dir)

    assert helpers["_resolve_font_file"]("not-installed-font") is None
    assert helpers["get_font"]("not-installed-font", 24).getbbox("fallback")
    assert Path(helpers["get_ffmpeg_safe_font_path"]("not-installed-font").replace("\\:", ":")) == (fonts_dir / "Montserrat.ttf").resolve()
