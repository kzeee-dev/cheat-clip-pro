"""Source-level regression checks for renderer watermark input normalization."""
import ast
import math
from pathlib import Path


def _load_clamp():
    source = Path(__file__).parents[1] / "video_engine.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    render_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "render_clip_to_mp4")
    clamp_fn = next(n for n in render_fn.body if isinstance(n, ast.FunctionDef) and n.name == "_finite_clamp")
    module = ast.Module(body=[clamp_fn], type_ignores=[])
    namespace = {"Any": object, "math": math}
    exec(compile(module, str(source), "exec"), namespace)
    return namespace["_finite_clamp"]


def test_watermark_clamp_handles_normal_and_out_of_range_values():
    clamp = _load_clamp()
    assert clamp(45, 90, 0, 100) == 45
    assert clamp(-20, 90, 0, 100) == 0
    assert clamp(180, 90, 0, 100) == 100


def test_watermark_clamp_handles_nan_infinity_and_invalid_input():
    clamp = _load_clamp()
    assert clamp(float("nan"), 90, 0, 100) == 90
    assert clamp(float("inf"), 0.8, 0, 1) == 0.8
    assert clamp("not-a-number", 20, 0, 500) == 20


def test_watermark_opacity_and_size_ranges():
    clamp = _load_clamp()
    assert clamp(150, 0.8, 0, 1) == 1
    assert clamp(-1, 0.8, 0, 1) == 0
    assert clamp(900, 20, 0, 500) == 500
