import os
import sys
import re
import json
import time
import shutil
import logging
import subprocess
import signal
import unicodedata
import math
import urllib.parse
import urllib.request
import contextlib
import tempfile
import threading
import queue
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union, Callable
from types import SimpleNamespace
from PIL import Image, ImageDraw, ImageFont
from backend.utils.text import is_twitch_url, extract_twitch_info, get_twitch_canonical_url, canonical_video_url

logger = logging.getLogger("cheat-clip-pro.video-engine")

BASE_DIR = Path(__file__).resolve().parent
TEMP_DIR = BASE_DIR / "temp_clips"
EXPORTS_DIR = BASE_DIR / "exports"
FONTS_DIR = BASE_DIR / "fonts"
COOKIES_PATH = BASE_DIR / "cookies.txt"
ROOT_COOKIES_PATH = BASE_DIR.parent / "cookies.txt"


def normalize_to_netscape(raw_content: str) -> str:
    """Cleans raw cookie input, strips UTF BOMs and null bytes, and auto-converts
    JSON cookies, HTTP Cookie headers, or misaligned columns to valid Netscape format for yt-dlp.
    """
    if not raw_content:
        return ""

    text = (
        raw_content.replace("\ufeff", "")
        .replace("\ufffe", "")
        .replace("\x00", "")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
        .strip()
    )

    if not text:
        return ""

    # 1. Check for JSON format (Cookie-Editor, EditThisCookie, etc.)
    if text.startswith("[") or text.startswith("{"):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict) and "cookies" in parsed and isinstance(parsed["cookies"], list):
                parsed = parsed["cookies"]
            elif isinstance(parsed, dict):
                parsed = [parsed]
            if isinstance(parsed, list) and len(parsed) > 0 and isinstance(parsed[0], dict):
                lines = [
                    "# Netscape HTTP Cookie File",
                    "# http://curl.haxx.se/rfc/cookie_spec.html",
                    "# Converted automatically from JSON format by CheatClip Pro",
                    "",
                ]
                count = 0
                for item in parsed:
                    domain = str(item.get("domain") or item.get("host") or "").strip()
                    if not domain:
                        domain = ".youtube.com"
                    flag = "TRUE" if domain.startswith(".") else "FALSE"
                    path = str(item.get("path") or "/").strip()
                    secure = "TRUE" if item.get("secure") else "FALSE"
                    exp = item.get("expirationDate") or item.get("expires") or item.get("expiry") or 0
                    try:
                        exp_int = int(float(exp))
                    except Exception:
                        exp_int = 0
                    if exp_int <= 0:
                        exp_int = 2147483647

                    name = str(item.get("name") or "").strip()
                    val = str(item.get("value") or "").strip()
                    if name:
                        lines.append(f"{domain}\t{flag}\t{path}\t{secure}\t{exp_int}\t{name}\t{val}")
                        count += 1

                if count > 0:
                    return "\n".join(lines) + "\n"
        except Exception:
            pass

    # 2. Check for HTTP Cookie header format (e.g. from browser DevTools Network tab or curl: "Cookie: SID=...; HSID=...")
    clean_header = text
    if clean_header.lower().startswith("cookie:"):
        clean_header = clean_header[7:].strip()
    if ";" in clean_header and "=" in clean_header and "\t" not in clean_header:
        pairs = clean_header.split(";")
        header_lines = [
            "# Netscape HTTP Cookie File",
            "# http://curl.haxx.se/rfc/cookie_spec.html",
            "# Converted automatically from HTTP Cookie header by CheatClip Pro",
            "",
        ]
        cookie_count = 0
        for pair in pairs:
            pair = pair.strip()
            if not pair or "=" not in pair:
                continue
            k, v = pair.split("=", 1)
            name = k.strip()
            val = v.strip()
            if name:
                header_lines.append(f".youtube.com\tTRUE\t/\tTRUE\t2147483647\t{name}\t{val}")
                cookie_count += 1
        if cookie_count > 0:
            return "\n".join(header_lines) + "\n"

    # 3. Handle standard Netscape text and space-to-tab repair
    lines = text.split("\n")
    cleaned_lines = []
    has_header = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if "# Netscape HTTP Cookie File" in stripped:
            has_header = True
            cleaned_lines.append(stripped)
            continue
        if stripped.startswith("#") and not stripped.startswith("#HttpOnly_"):
            cleaned_lines.append(stripped)
            continue

        # If line has spaces instead of tabs, convert 2+ spaces to tabs
        if "\t" not in stripped:
            parts = re.split(r'\s{2,}|\t', stripped)
            if len(parts) >= 6:
                stripped = "\t".join(parts)

        cleaned_lines.append(stripped)

    if not has_header:
        cleaned_lines.insert(0, "# Netscape HTTP Cookie File")
        cleaned_lines.insert(1, "# http://curl.haxx.se/rfc/cookie_spec.html")
        cleaned_lines.insert(2, "")

    return "\n".join(cleaned_lines) + "\n"


@contextlib.contextmanager
def ephemeral_cookies_file(cookies_content: Optional[str]):
    """Creates a temporary Netscape cookies file for a single task and ensures it is deleted immediately."""
    if not cookies_content or len(str(cookies_content).strip()) < 10:
        yield None
        return

    normalized = normalize_to_netscape(str(cookies_content))
    if not normalized or len(normalized.strip()) < 10:
        yield None
        return

    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    temp_file = tempfile.NamedTemporaryFile(
        mode="w",
        prefix="yt_cookie_",
        suffix=".txt",
        dir=str(TEMP_DIR),
        delete=False,
        encoding="utf-8"
    )
    temp_path = Path(temp_file.name)
    try:
        temp_file.write(normalized)
        temp_file.flush()
        temp_file.close()
        yield temp_path
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except Exception:
            pass


def get_effective_cookies_path() -> Optional[Path]:
    """Returns valid cookies file path if persistent file exists on disk (fallback)."""
    if COOKIES_PATH.exists() and COOKIES_PATH.stat().st_size > 0:
        return COOKIES_PATH
    if ROOT_COOKIES_PATH.exists() and ROOT_COOKIES_PATH.stat().st_size > 0:
        return ROOT_COOKIES_PATH
    return None

CASCADE_PATH = BASE_DIR / "haarcascade_frontalface_default.xml"
CASCADES_DIR = BASE_DIR / "cascades"
YUNET_MODEL_PATH = CASCADES_DIR / "face_detection_yunet.onnx"
TEMP_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
FONTS_DIR.mkdir(parents=True, exist_ok=True)
CASCADES_DIR.mkdir(parents=True, exist_ok=True)
UPLOADS_DIR = TEMP_DIR / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

def _ffmpeg_has_filter(executable: str, filter_name: str) -> bool:
    """Returns whether an FFmpeg binary exposes the requested filter."""
    try:
        result = subprocess.run(
            [executable, "-hide_banner", "-filters"],
            capture_output=True,
            text=True,
            timeout=8,
        )
        return result.returncode == 0 and re.search(
            rf"(?m)^\s*\S+\s+{re.escape(filter_name)}\s+", result.stdout or ""
        ) is not None
    except (OSError, subprocess.SubprocessError):
        return False


def ensure_ffmpeg_in_path():
    """Auto-detect FFmpeg if it was installed via winget, scoop, or local paths but not in PATH."""
    current_path = os.environ.get("PATH") or os.environ.get("Path") or ""
    path_parts = current_path.split(os.pathsep) if current_path else []

    # Ensure Python runtime directories and Scripts are in PATH
    try:
        py_dir = Path(sys.executable).parent
        for p in [py_dir, py_dir / "Scripts", py_dir / "bin"]:
            if p.exists():
                p_str = str(p.resolve())
                if p_str not in path_parts:
                    path_parts.insert(0, p_str)
    except Exception:
        pass

    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path or not _ffmpeg_has_filter(ffmpeg_path, "subtitles"):
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        user_profile = os.environ.get("USERPROFILE", "")
        prog_files = os.environ.get("ProgramFiles", "C:\\Program Files")
        prog_files_x86 = os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")

        candidate_roots = [
            Path(local_app_data) / "Microsoft" / "WinGet" / "Packages" if local_app_data else None,
            Path(local_app_data) / "Programs" / "ffmpeg" / "bin" if local_app_data else None,
            Path(user_profile) / "scoop" / "apps" / "ffmpeg" / "current" / "bin" if user_profile else None,
            Path(user_profile) / "scoop" / "shims" if user_profile else None,
            Path(prog_files) / "ffmpeg" / "bin",
            Path(prog_files_x86) / "ffmpeg" / "bin",
            Path("C:/ffmpeg/bin"),
            Path("C:/Program Files/ffmpeg/bin"),
        ]

        # Homebrew's standard formula omits libass; ffmpeg-full is keg-only.
        if sys.platform == "darwin":
            candidate_roots.extend([
                Path("/opt/homebrew/opt/ffmpeg-full/bin"),
                Path("/usr/local/opt/ffmpeg-full/bin"),
            ])

        for root in candidate_roots:
            if root and root.exists():
                executable = root / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
                if executable.exists() and _ffmpeg_has_filter(str(executable), "subtitles"):
                    r_str = str(root.resolve())
                    if r_str not in path_parts:
                        path_parts.insert(0, r_str)
                    logger.info(f"Auto-added subtitle-capable FFmpeg to PATH: {r_str}")
                    break
                for exe in root.glob("**/ffmpeg.exe" if os.name == "nt" else "**/ffmpeg"):
                    if not _ffmpeg_has_filter(str(exe), "subtitles"):
                        continue
                    bin_dir = str(exe.parent.resolve())
                    if bin_dir not in path_parts:
                        path_parts.insert(0, bin_dir)
                    logger.info(f"Auto-added subtitle-capable FFmpeg to PATH: {bin_dir}")
                    break

    # Re-assign unified PATH
    new_path = os.pathsep.join(path_parts)
    os.environ["PATH"] = new_path
    os.environ["Path"] = new_path


ensure_ffmpeg_in_path()

# Global lazy-loaded whisper model and thread lock for PyTorch attention safety
_WHISPER_MODEL = None
_WHISPER_LOCK = threading.Lock()


def get_whisper_model():
    global _WHISPER_MODEL
    with _WHISPER_LOCK:
        if _WHISPER_MODEL is None:
            try:
                import whisper
                # Prefer 'small' model (better vocabulary & multi-lingual accuracy, esp. Indonesian speech)
                # Falls back to 'base' if 'small' cannot be loaded
                try:
                    logger.info("Loading Whisper 'small' model for high-accuracy word-level timestamps...")
                    _WHISPER_MODEL = whisper.load_model("small")
                except Exception as e_small:
                    logger.warning(f"Could not load Whisper 'small' model ({e_small}). Falling back to 'base'...")
                    _WHISPER_MODEL = whisper.load_model("base")
            except Exception as e:
                logger.warning(f"Could not load Whisper model: {e}")
                _WHISPER_MODEL = False
    return _WHISPER_MODEL if _WHISPER_MODEL is not False else None


def release_whisper_model():
    """Explicitly frees Whisper PyTorch model from RAM to preserve memory on low-spec servers."""
    global _WHISPER_MODEL
    with _WHISPER_LOCK:
        if _WHISPER_MODEL is not None and _WHISPER_MODEL is not False:
            try:
                del _WHISPER_MODEL
                _WHISPER_MODEL = None
                import gc
                gc.collect()
                logger.info("Whisper model unloaded from memory to free server RAM.")
            except Exception:
                pass


def check_encoder_support(encoder_name: str) -> bool:
    """Check if a specific FFmpeg video encoder is operational on this system."""
    try:
        cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-f", "lavfi", "-i", "color=c=black:s=1080x1920:d=0.2",
            "-c:v", encoder_name, "-f", "null", "-"
        ]
        res = subprocess.run(cmd, capture_output=True, timeout=5)
        return res.returncode == 0
    except Exception:
        return False


ENCODER_CONFIGS: Dict[str, Tuple[str, List[str]]] = {
    # Android MediaCodec can use the phone's dedicated video encoder instead of
    # consuming CPU cores. It is selected only after a real FFmpeg probe passes.
    "mediacodec": ("h264_mediacodec", ["-c:v", "h264_mediacodec", "-b:v", "6M"]),
    "nvenc": ("h264_nvenc", ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "23"]),
    "amf": ("h264_amf", ["-c:v", "h264_amf", "-quality", "speed", "-rc", "cbr", "-b:v", "6M"]),
    "qsv": ("h264_qsv", ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "23", "-look_ahead", "0"]),
    "cpu": ("libx264", ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-threads", "2"]),
}

_DETECTED_SUPPORT: Optional[Dict[str, Any]] = None


def get_system_gpu_name() -> Optional[str]:
    """Detects the physical GPU model name on the host system."""
    # Try nvidia-smi query first
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                universal_newlines=True,
                timeout=3,
                stderr=subprocess.DEVNULL
            ).strip()
            if out:
                return out.split("\n")[0].strip()
        except Exception:
            pass

    # On Windows, query CIM VideoController
    if sys.platform.startswith("win"):
        try:
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name"],
                universal_newlines=True,
                timeout=4,
                stderr=subprocess.DEVNULL
            ).strip()
            lines = [l.strip() for l in out.split("\n") if l.strip()]
            for l in lines:
                if any(k in l.lower() for k in ["nvidia", "geforce", "rtx", "gtx", "radeon", "intel arc", "arc"]):
                    return l
            if lines:
                return lines[0]
        except Exception:
            pass

    return None


def detect_hardware_support() -> Dict[str, Any]:
    """Detects host GPU/CPU hardware acceleration support and caches the result."""
    global _DETECTED_SUPPORT
    if _DETECTED_SUPPORT is not None:
        return _DETECTED_SUPPORT

    # MediaCodec is Android-only and must pass an actual encode probe before use.
    is_android = sys.platform.startswith("linux") and bool(
        os.environ.get("ANDROID_ROOT") or os.environ.get("ANDROID_DATA")
    )
    has_mediacodec = (
        check_encoder_support("h264_mediacodec") if is_android else False
    )
    has_nvenc = check_encoder_support("h264_nvenc")
    has_amf = check_encoder_support("h264_amf")
    has_qsv = check_encoder_support("h264_qsv")

    if has_mediacodec:
        recommended = "mediacodec"
    elif has_nvenc:
        recommended = "nvenc"
    elif has_amf:
        recommended = "amf"
    elif has_qsv:
        recommended = "qsv"
    else:
        recommended = "cpu"

    gpu_name = get_system_gpu_name()

    _DETECTED_SUPPORT = {
        "mediacodec": has_mediacodec,
        "nvenc": has_nvenc,
        "amf": has_amf,
        "qsv": has_qsv,
        "cpu": True,
        "recommended": recommended,
        "gpu_name": gpu_name,
    }
    return _DETECTED_SUPPORT


def get_preferred_video_encoder() -> Tuple[str, List[str]]:
    """
    Auto-detects a working hardware encoder, preferring Android MediaCodec
    on supported phones, then NVIDIA/AMD/Intel hardware, then CPU fallback.
    """
    support = detect_hardware_support()
    rec = support.get("recommended", "cpu")
    if rec in ENCODER_CONFIGS:
        codec, args = ENCODER_CONFIGS[rec]
        logger.info(f"Hardware acceleration auto-select: {codec} (rec: {rec}) enabled.")
        return codec, args

    return ENCODER_CONFIGS["cpu"]


def resolve_encoder(user_selection: Optional[str] = "auto") -> Tuple[str, List[str]]:
    """
    Resolves user selection ('auto', 'nvenc', 'amf', 'qsv', 'cpu') to (codec_name, ffmpeg_args).
    """
    sel = (user_selection or "auto").lower().strip()
    if sel == "auto":
        return get_preferred_video_encoder()

    if sel in ENCODER_CONFIGS:
        return ENCODER_CONFIGS[sel]

    # Check direct codec names
    for key, (codec, args) in ENCODER_CONFIGS.items():
        if sel == codec or sel == key:
            return codec, args

    return ENCODER_CONFIGS["cpu"]


ACTIVE_ENCODER_NAME, ACTIVE_ENCODER_ARGS = get_preferred_video_encoder()
USE_NVENC = (ACTIVE_ENCODER_NAME == "h264_nvenc")


def format_section_time(seconds: float) -> str:
    """Format seconds into HH:MM:SS.cs for yt-dlp section cutting."""
    total_seconds = max(0.0, seconds)
    h = int(total_seconds // 3600)
    m = int((total_seconds % 3600) // 60)
    s = int(total_seconds % 60)
    cs = int(round((total_seconds - int(total_seconds)) * 100))
    if cs >= 100:
        cs = 99
    return f"{h:02d}:{m:02d}:{s:02d}.{cs:02d}"


def get_yt_dlp_cookies_args() -> List[str]:
    """Returns yt-dlp cookies arguments if cookies.txt exists and is non-empty."""
    eff = get_effective_cookies_path()
    if eff:
        return ["--cookies", str(eff)]
    return []


def get_yt_dlp_base_cmd(
    include_cookies: bool = True,
    cookies_path: Optional[Union[str, Path]] = None,
) -> List[str]:
    """
    Returns base command for yt-dlp with JavaScript runtime, player extractor args, and cookies.
    Tries standalone 'yt-dlp' executable first, then falls back to python module:
    [sys.executable, "-m", "yt_dlp"] which works 100% of the time if installed via pip.
    """
    if shutil.which("yt-dlp"):
        cmd = ["yt-dlp"]
    else:
        try:
            import yt_dlp
            cmd = [sys.executable, "-m", "yt_dlp"]
        except ImportError:
            raise RuntimeError(
                "yt-dlp is not installed in this Python environment. "
                "Please run 'pip install yt-dlp' or 'pip install -r backend/requirements.txt'."
            )

    # Prefer deno (fast challenge solver for modern YouTube player), then node
    if shutil.which("deno"):
        cmd.extend(["--js-runtimes", "deno"])
    elif shutil.which("node"):
        cmd.extend(["--js-runtimes", "node"])

    # Enable the official yt-dlp EJS challenge solver components.
    cmd.extend(["--remote-components", "ejs:github"])

    if cookies_path and Path(cookies_path).exists() and Path(cookies_path).stat().st_size > 0:
        has_active_cookies = True
        logger.info(f"Using ephemeral YouTube cookies from: {cookies_path}")
        cmd.extend(["--cookies", str(cookies_path)])
    elif include_cookies:
        eff = get_effective_cookies_path()
        if eff and eff.exists() and eff.stat().st_size > 0:
            has_active_cookies = True
            logger.info(f"Using YouTube cookies from: {eff}")
            cmd.extend(["--cookies", str(eff)])

    cmd.append("--force-ipv4")
    return cmd


def is_valid_mp4(file_path: Union[str, Path], decode_check: bool = False) -> bool:
    """
    Validate MP4 metadata and optionally fully decode video/audio streams.
    """
    p = Path(file_path)

    if not p.exists():
        return False

    try:
        if p.stat().st_size < 10000:
            return False

        probe_cmd = [
            "ffprobe", "-v", "error",
            "-show_entries", "stream=codec_type:format=duration",
            "-of", "json",
            str(p),
        ]
        res = subprocess.run(
            probe_cmd, capture_output=True, text=True, timeout=15
        )

        if res.returncode != 0:
            return False

        data = json.loads(res.stdout or "{}")
        streams = data.get("streams", [])
        duration = float(data.get("format", {}).get("duration", 0) or 0)

        has_video = any(
            stream.get("codec_type") == "video"
            for stream in streams
        )

        if not (has_video and duration > 0.05):
            return False

        if not decode_check:
            return True

        decode_cmd = [
            "ffmpeg", "-nostdin", "-hide_banner",
            "-v", "error", "-xerror",
            "-i", str(p),
            "-map", "0:v:0",
            "-map", "0:a?",
            "-f", "null", "-"
        ]

        decode_timeout = max(90, min(900, int(duration * 4) + 30))
        decode_res = subprocess.run(
            decode_cmd,
            capture_output=True,
            text=True,
            timeout=decode_timeout
        )

        if decode_res.returncode != 0:
            logger.warning(
                f"MP4 decode validation failed for {p.name}: "
                f"{decode_res.stderr[-1000:]!r}"
            )
            return False

        return True

    except subprocess.TimeoutExpired:
        logger.warning(f"MP4 validation timed out for {p.name}")
        return False
    except Exception as exc:
        logger.debug(f"MP4 validation failed for {p.name}: {exc}")
        return False

def get_video_file_metadata(file_path: Union[str, Path]) -> Dict[str, Any]:
    """
    Extracts duration, dimensions, FPS, and stream metadata for a local video file.
    """
    p = Path(file_path)
    if not p.exists():
        raise FileNotFoundError(f"Video file not found: {p}")
    
    title = p.stem
    duration = 0.0
    width = 1920
    height = 1080
    fps = 30.0
    has_audio = True

    # Try ffprobe first
    try:
        cmd = [
            "ffprobe", "-v", "error",
            "-show_entries", "format=duration:stream=width,height,r_frame_rate,codec_type",
            "-of", "json",
            str(p)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if res.returncode == 0 and res.stdout:
            data = json.loads(res.stdout)
            format_info = data.get("format", {})
            if "duration" in format_info:
                duration = float(format_info["duration"])
            
            streams = data.get("streams", [])
            audio_streams = [s for s in streams if s.get("codec_type") == "audio"]
            has_audio = len(audio_streams) > 0

            video_streams = [s for s in streams if s.get("codec_type") == "video"]
            if video_streams:
                v = video_streams[0]
                width = int(v.get("width", 1920))
                height = int(v.get("height", 1080))
                r_fps = str(v.get("r_frame_rate", "30/1"))
                if "/" in r_fps:
                    num, den = r_fps.split("/")
                    fps = float(num) / max(1.0, float(den))
                else:
                    fps = float(r_fps)
    except Exception as e:
        logger.warning(f"ffprobe metadata extraction failed for {p}: {e}")

    # Fallback to OpenCV if duration or dimensions not found
    if duration <= 0 or width <= 0 or height <= 0:
        try:
            import cv2
            cap = cv2.VideoCapture(str(p))
            if cap.isOpened():
                frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT)
                cap_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
                if cap_fps > 0:
                    fps = cap_fps
                    duration = frame_count / cap_fps
                width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or width)
                height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or height)
                cap.release()
        except Exception as e:
            logger.warning(f"OpenCV metadata fallback failed: {e}")

    return {
        "title": title,
        "duration": round(duration, 2),
        "width": width,
        "height": height,
        "fps": round(fps, 2),
        "has_audio": has_audio,
        "file_path": str(p),
        "size_bytes": p.stat().st_size
    }


def compute_audio_energy_heatmap(file_path: Union[str, Path], duration: float, num_points: int = 100) -> List[Dict[str, float]]:
    """
    Analyzes audio RMS energy / amplitude across the video timeline to generate realistic
    heatmap engagement telemetry matching YouTube's replay heatmap format (0.0 to 1.0).
    """
    p = Path(file_path)
    if duration <= 0:
        duration = 60.0
    
    seg_dur = duration / max(1, num_points)
    raw_scores = [0.2] * num_points
    
    try:
        temp_wav = TEMP_DIR / f"temp_heat_{p.stem}_{int(time.time())}.wav"
        cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(p),
            "-vn", "-ac", "1", "-ar", "8000",
            "-f", "wav",
            str(temp_wav)
        ]
        res = subprocess.run(cmd, capture_output=True, timeout=30)
        if res.returncode == 0 and temp_wav.exists() and temp_wav.stat().st_size > 100:
            import wave
            import numpy as np
            with wave.open(str(temp_wav), "rb") as wf:
                n_frames = wf.getnframes()
                audio_bytes = wf.readframes(n_frames)
                audio_data = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32)
                
                if len(audio_data) > 0:
                    samples_per_seg = int(len(audio_data) / num_points)
                    if samples_per_seg > 0:
                        for i in range(num_points):
                            chunk = audio_data[i * samples_per_seg : (i + 1) * samples_per_seg]
                            if len(chunk) > 0:
                                rms = float(np.sqrt(np.mean(chunk**2)))
                                raw_scores[i] = rms
            try:
                temp_wav.unlink()
            except Exception:
                pass
    except Exception as e:
        logger.warning(f"Audio energy heatmap calculation fallback used: {e}")

    min_v = min(raw_scores)
    max_v = max(raw_scores)
    diff = max_v - min_v
    
    heatmap = []
    for i in range(num_points):
        st = round(i * seg_dur, 2)
        et = round(min(duration, (i + 1) * seg_dur), 2)
        if diff > 0.0001:
            val = round(0.1 + 0.9 * ((raw_scores[i] - min_v) / diff), 3)
        else:
            val = round(0.3 + 0.4 * (0.5 + 0.5 * math.sin(i * 0.2)), 3)
        heatmap.append({
            "start_time": st,
            "end_time": et,
            "value": max(0.05, min(1.0, val))
        })
    return heatmap


def transcribe_local_video_file(
    file_path: Union[str, Path],
    progress_callback=None,
    target_language: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Transcribes speech from a local video or audio file using OpenAI Whisper.
    Strictly focuses on Bahasa Indonesia or English.
    Returns standard transcript segments formatted as:
    [{"text": "...", "start": 0.0, "duration": 3.5}, ...]
    """
    p = Path(file_path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")

    whisper_model = get_whisper_model()
    if whisper_model is None:
        raise RuntimeError(
            "Whisper speech recognition model could not be loaded on this system. "
            "Please ensure `openai-whisper` is installed and FFmpeg is in PATH."
        )

    if progress_callback:
        progress_callback("Running Whisper AI", f"Extracting dialogue from {p.name} with Whisper...", 30)

    logger.info(f"Transcribing local file with Whisper: {p} (target_language={target_language})")
    whisper_prompt = (
        "Transkrip video percakapan dalam Bahasa Indonesia." if target_language == "id"
        else "Video dialogue transcript in English." if target_language == "en"
        else "Transkrip video percakapan dalam Bahasa Indonesia atau English."
    )
    transcribe_kwargs: Dict[str, Any] = {
        "word_timestamps": False,  # Dialogue segment detection does not need word timestamps; avoids find_alignment DTW tensor shape mismatch
        "fp16": False,
        "verbose": False,
        "condition_on_previous_text": False,
        "initial_prompt": whisper_prompt,
    }
    if target_language in ("id", "en"):
        transcribe_kwargs["language"] = target_language

    result = None
    with _WHISPER_LOCK:
        try:
            result = whisper_model.transcribe(str(p), **transcribe_kwargs)
        except RuntimeError as e:
            err_str = str(e).lower()
            if "dimension" in err_str or "tensor" in err_str or "size" in err_str:
                logger.warning(f"Whisper attention tensor mismatch ({e}), retrying without prompt/condition...")
                minimal_kwargs: Dict[str, Any] = {
                    "word_timestamps": False,
                    "fp16": False,
                    "verbose": False,
                    "condition_on_previous_text": False,
                }
                if target_language in ("id", "en"):
                    minimal_kwargs["language"] = target_language
                result = whisper_model.transcribe(str(p), **minimal_kwargs)
            else:
                raise

    if not result:
        return []

    segments = result.get("segments", [])
    transcript_lines = []

    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue
        start = round(float(seg.get("start", 0.0)), 2)
        end = round(float(seg.get("end", start + 2.0)), 2)
        dur = round(max(0.4, end - start), 2)
        transcript_lines.append({
            "text": text,
            "start": start,
            "duration": dur
        })

    logger.info(f"Whisper transcribed {len(transcript_lines)} dialogue segments from {p.name}")
    return transcript_lines


def _terminate_process_tree(process, grace_seconds=5):
    """Terminate yt-dlp and every FFmpeg child in its isolated process group."""
    if process is None:
        return

    # yt-dlp's section downloader launches FFmpeg, which inherits the output
    # pipe. Killing only yt-dlp can leave FFmpeg orphaned and the reader blocked.
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        except Exception:
            logger.debug("Could not send SIGTERM to yt-dlp process group", exc_info=True)
    elif process.poll() is None:
        try:
            process.terminate()
        except Exception:
            pass

    try:
        process.wait(timeout=grace_seconds)
    except Exception:
        pass

    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except Exception:
            logger.debug("Could not send SIGKILL to yt-dlp process group", exc_info=True)
    elif process.poll() is None:
        try:
            process.kill()
        except Exception:
            pass

    try:
        process.wait(timeout=2)
    except Exception:
        pass


def _run_ytdlp_with_progress(cmd, timeout, progress_callback=None):
    """Run yt-dlp while streaming byte, speed, ETA and percentage updates to the UI."""
    progress_cmd = list(cmd) + [
        "--newline",
        "--progress-template",
        "download:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
    ]
    process = subprocess.Popen(
        progress_cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        # Isolate yt-dlp and its FFmpeg child so timeout cleanup cannot leave
        # network downloads running after the parent process has exited.
        start_new_session=(os.name == "posix"),
    )
    output_queue = queue.Queue()

    def _reader():
        try:
            if process.stdout is not None:
                for output_line in iter(process.stdout.readline, ""):
                    output_queue.put(output_line)
        finally:
            output_queue.put(None)

    reader = threading.Thread(target=_reader, name="yt-dlp-progress-reader", daemon=True)
    reader.start()
    started = time.monotonic()
    last_progress_at = started
    last_heartbeat_at = started
    last_progress_payload = {
        "percent": 0.0, "downloaded": "", "total": "", "speed": "", "eta": ""
    }
    # yt-dlp can spend a long time downloading selected media without emitting
    # progress-template lines (notably while fetching fragmented/HLS streams).
    # Watch its .part file as a fallback so the UI still receives real byte
    # movement and measured throughput instead of a permanent "waiting" label.
    output_path = None
    for output_flag in ("-o", "--output"):
        try:
            output_index = cmd.index(output_flag)
            output_path = Path(cmd[output_index + 1])
            break
        except (ValueError, IndexError):
            continue
    last_file_bytes = 0
    last_file_sample_at = started
    output_lines = []
    finished = False
    while not finished:
        elapsed = time.monotonic() - started
        if elapsed >= timeout:
            _terminate_process_tree(process)
            raise subprocess.TimeoutExpired(progress_cmd, timeout, output="".join(output_lines))
        try:
            line = output_queue.get(timeout=min(0.75, max(0.05, timeout - elapsed)))
        except queue.Empty:
            if process.poll() is not None and not reader.is_alive():
                break
            # Publish honest activity heartbeats while yt-dlp is waiting for
            # YouTube/network data. Keep the last real percentage unchanged.
            now = time.monotonic()
            if progress_callback and now - last_heartbeat_at >= 2.0:
                wait_seconds = int(now - last_progress_at)
                current_file_bytes = 0
                if output_path is not None:
                    # yt-dlp normally writes <output>.part; some downloaders
                    # expose the final path directly before the process exits.
                    for candidate in (Path(str(output_path) + ".part"), output_path):
                        try:
                            if candidate.is_file():
                                current_file_bytes = max(current_file_bytes, candidate.stat().st_size)
                        except OSError:
                            pass
                sample_elapsed = max(0.001, now - last_file_sample_at)
                if current_file_bytes > last_file_bytes:
                    bytes_per_second = (current_file_bytes - last_file_bytes) / sample_elapsed
                    if bytes_per_second >= 1024 * 1024:
                        measured_speed = f"{bytes_per_second / (1024 * 1024):.2f} MiB/s"
                    else:
                        measured_speed = f"{bytes_per_second / 1024:.0f} KiB/s"
                    downloaded_label = f"{current_file_bytes / (1024 * 1024):.1f} MiB"
                    heartbeat_payload = {
                        **last_progress_payload,
                        "downloaded": downloaded_label,
                        "speed": measured_speed,
                        "heartbeat": True,
                        "source": "file_size_fallback",
                    }
                    last_file_bytes = current_file_bytes
                    last_file_sample_at = now
                else:
                    heartbeat_payload = {
                        **last_progress_payload,
                        "speed": f"Menunggu respons jaringan ({wait_seconds} dtk)",
                        "heartbeat": True,
                    }
                progress_callback(heartbeat_payload)
                last_heartbeat_at = now
            continue
        if line is None:
            finished = True
            continue
        output_lines.append(line)
        clean = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', line.strip())
        if progress_callback and clean.startswith("download:"):
            parts = clean[len("download:"):].strip().split("|")
            if len(parts) >= 5:
                pct, downloaded, total, speed, eta = [part.strip() for part in parts[:5]]
                try:
                    percent = float(re.sub(r"[^0-9.]", "", pct) or 0)
                except ValueError:
                    percent = 0.0
                last_progress_payload = {
                    "percent": percent,
                    "downloaded": downloaded if downloaded != "NA" else "",
                    "total": total if total != "NA" else "",
                    "speed": speed if speed != "NA" else "",
                    "eta": eta if eta != "NA" else "",
                }
                last_progress_at = time.monotonic()
                last_heartbeat_at = last_progress_at
                progress_callback(last_progress_payload)
    try:
        process.wait(timeout=2)
    except Exception:
        pass
    finally:
        # Also reap any FFmpeg descendants if yt-dlp exited unexpectedly while
        # a child still held stdout open. This prevents orphaned .part writers.
        _terminate_process_tree(process)
        if process.stdout is not None:
            try:
                process.stdout.close()
            except Exception:
                pass
    output = "".join(output_lines)
    return SimpleNamespace(returncode=process.returncode, stdout=output, stderr=output)


def download_clip_segment(
    video_url: str,
    start_time: float,
    end_time: float,
    output_filename: str,
    cookies_content: Optional[str] = None,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None
) -> str:
    """
    Downloads or slices the requested time slice in high definition (1080p).
    If video_url is a local file (uploaded video), uses direct FFmpeg slicing.
    Otherwise downloads using yt-dlp.
    """
    output_path = TEMP_DIR / output_filename
    if output_path.exists():
        try:
            output_path.unlink()
        except Exception:
            pass

    # Check if video_url points to a local file (e.g. uploaded or Google Drive cached video)
    clean_raw = urllib.parse.unquote(video_url.strip())
    clean_base = os.path.basename(clean_raw.split("?")[0])
    local_source = None

    if os.path.exists(clean_raw):
        local_source = Path(clean_raw)
    elif os.path.exists(video_url):
        local_source = Path(video_url)
    elif clean_raw.startswith("/api/video/"):
        candidate = UPLOADS_DIR / clean_base
        if candidate.exists():
            local_source = candidate
    elif (UPLOADS_DIR / clean_base).exists():
        local_source = UPLOADS_DIR / clean_base
    elif (TEMP_DIR / clean_base).exists():
        local_source = TEMP_DIR / clean_base
    elif (EXPORTS_DIR / clean_base).exists():
        local_source = EXPORTS_DIR / clean_base

    if not local_source:
        all_local_files: List[Path] = []
        for d in [UPLOADS_DIR, TEMP_DIR, EXPORTS_DIR]:
            if d.exists():
                all_local_files.extend([
                    f for f in d.iterdir()
                    if f.is_file() and f.suffix.lower() in [".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"] and "_clip_" not in f.name
                ])

        clean_lower = clean_base.lower()
        # 1. Exact case-insensitive or stem match
        for f in all_local_files:
            if f.name.lower() == clean_lower or f.stem.lower() == clean_lower or clean_lower in f.name.lower() or f.stem.lower() in clean_lower:
                local_source = f
                break

        if not local_source:
            # 2. Drive ID or Upload ID match
            match_id = re.search(r'(gdrive_[a-zA-Z0-9_-]+|upload_[a-zA-Z0-9_-]+)', clean_raw)
            if match_id:
                raw_id = match_id.group(1).replace("gdrive_", "").replace("upload_", "")
                for f in all_local_files:
                    if raw_id in f.name:
                        local_source = f
                        break

    clip_duration = max(1.0, end_time - start_time)

    if local_source and local_source.exists():
        # If user provided cookies and this local_source was a low-res guest-mode file (< 720p), skip it to download genuine 1080p
        is_direct_upload = "upload_" in clean_raw.lower() or "gdrive_" in clean_raw.lower()
        if not is_direct_upload and (cookies_content or get_effective_cookies_path()):
            try:
                probe = subprocess.run(
                    ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=height", "-of", "csv=p=0", str(local_source)],
                    capture_output=True, text=True, timeout=5
                )
                h = int(probe.stdout.strip()) if probe.stdout.strip().isdigit() else 0
                if h > 0 and h < 720:
                    logger.info(f"Local source {local_source.name} is low resolution ({h}p < 720p) and cookies are active. Skipping cache to download genuine 1080p.")
                    local_source = None
            except Exception:
                pass

    if local_source and local_source.exists():
        logger.info(f"Slicing local/gdrive video: {local_source} [{start_time:.2f}s -> {end_time:.2f}s] to {output_path}")
        slice_timeout = max(300, min(1200, int(clip_duration * 6) + 90))
        slice_cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-ss", str(start_time),
            "-to", str(end_time),
            "-i", str(local_source),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-c:a", "aac", "-b:a", "192k",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            str(output_path)
        ]
        def _on_local_slice_progress(info):
            if not progress_callback:
                return
            try:
                current_size = output_path.stat().st_size if output_path.exists() else 0
                downloaded_label = f"{current_size / (1024 * 1024):.1f} MB"
            except OSError:
                downloaded_label = ""
            progress_callback({
                "percent": info.get("percent", 0.0),
                "downloaded": downloaded_label,
                "total": "ukuran hasil akhir belum diketahui",
                "speed": f"{info.get('speed', '0x')} proses FFmpeg",
                "eta": "",
            })

        res = _run_ffmpeg_with_progress(
            slice_cmd, slice_timeout, _on_local_slice_progress, clip_duration
        )
        if output_path.exists() and is_valid_mp4(output_path):
            return str(output_path)
        if output_path.exists():
            try:
                output_path.unlink()
            except Exception:
                pass
        raise RuntimeError(f"Failed to slice video clip from source '{local_source.name}': {res.stderr or 'Corrupted video stream'}")

    # Guard: if it was a Google Drive or Upload request, never send to YouTube
    # Exception: if it was a YouTube audio cache file (e.g. /api/video/yt_audio_iLijjSEI_40.mp4), resolve back to original YouTube video
    yt_audio_match = re.search(r'yt_audio_([a-zA-Z0-9_-]{11})', clean_raw)
    tw_audio_match = re.search(r'twitch_audio_(twitch_\d+|twitch_clip_[a-zA-Z0-9_-]+|\d+|[a-zA-Z0-9_-]+)', clean_raw)
    if yt_audio_match:
        yt_id = yt_audio_match.group(1)
        clean_url = f"https://www.youtube.com/watch?v={yt_id}"
        logger.info(f"Resolved cached audio reference '{clean_raw}' back to genuine YouTube stream: {clean_url}")
    elif tw_audio_match or is_twitch_url(clean_raw):
        tw_info = extract_twitch_info(clean_raw)
        clean_url = get_twitch_canonical_url(tw_info) if tw_info else clean_raw
        logger.info(f"Resolved Twitch reference '{clean_raw}' back to genuine Twitch stream: {clean_url}")
    elif "gdrive" in clean_raw.lower() or "upload_" in clean_raw.lower() or clean_raw.startswith("/api/video/"):
        raise RuntimeError(f"Source video file not found on disk for '{clean_raw}'. Please re-analyze the video.")
    else:
        # Sanitize video URL
        if is_twitch_url(video_url):
            tw_info = extract_twitch_info(video_url)
            clean_url = get_twitch_canonical_url(tw_info) if tw_info else video_url.strip()
        else:
            clean_url = video_url.strip()
            if not clean_url.startswith("http"):
                clean_url = f"https://www.youtube.com/watch?v={clean_url}"

    t_start_fmt = format_section_time(start_time)
    t_end_fmt = format_section_time(end_time)

    # Dynamic timeout: Base 300s, plus 5s per second of clip duration (max 1200s / 20 min).
    # Ensures clips > 1 minute (e.g. 70s, 90s, 120s, 180s) have ample time to download and merge without timing out.
    timeout_sec = max(300, min(1200, int(clip_duration * 5) + 90))

    # Bound the entire fallback chain, not just each individual subprocess.
    # A short clip must not spend 10-30 minutes cycling through identical network failures.
    overall_timeout = max(720, min(1800, int(clip_duration * 8) + 600))
    overall_deadline = time.monotonic() + overall_timeout

    with ephemeral_cookies_file(cookies_content) as temp_cookies:
        has_cookies = temp_cookies is not None or get_effective_cookies_path() is not None
        # Guest mode is useful for auth/session rejection, not for a stalled network.
        attempts = [True, False] if has_cookies else [False]
        last_err_snippet = "unknown"

        for use_cookies in attempts:
            remaining = int(overall_deadline - time.monotonic())
            if remaining <= 0:
                last_err_snippet = f"overall download timeout: budget exhausted after {overall_timeout}s"
                break

            mode_label = "with cookies" if use_cookies else "guest mode (without cookies)"
            base_cmd = get_yt_dlp_base_cmd(include_cookies=use_cookies, cookies_path=temp_cookies if use_cookies else None)
            logger.info(f"Downloading HD section ({clip_duration:.1f}s) {t_start_fmt} -> {t_end_fmt} for {clean_url} ({mode_label}, timeout: {timeout_sec}s)")

            # Method 1: yt-dlp --download-sections with multi-fragment acceleration, socket timeout, & retries
            cmd = [
                *base_cmd,
                "--download-sections", f"*{t_start_fmt}-{t_end_fmt}",
                "--force-keyframes-at-cuts",
                "-f", "bestvideo[height<=1080]+bestaudio/best[height<=1080]/bestvideo+bestaudio/best",
                "-N", "4",
                "--socket-timeout", "20",
                "--fragment-retries", "5",
                "--retries", "5",
                "--file-access-retries", "3",
                "-o", str(output_path),
                "--merge-output-format", "mp4",
                "--no-warnings",
                clean_url
            ]
            try:
                res = _run_ytdlp_with_progress(cmd, timeout=min(timeout_sec, max(1, int(overall_deadline - time.monotonic()))), progress_callback=progress_callback)
                if res.returncode == 0 and is_valid_mp4(output_path):
                    logger.info(f"Successfully downloaded section ({mode_label}): {output_path} ({output_path.stat().st_size} bytes)")
                    return str(output_path)
                # If not valid or returncode != 0, clean up any incomplete/corrupt partial file immediately
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = res.stderr[:300] if (res and res.stderr) else "empty output or invalid file (moov atom missing)"
            except subprocess.TimeoutExpired:
                logger.warning(f"yt-dlp download-sections timed out after {timeout_sec}s for {clean_url} ({mode_label}).")
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = f"download-sections timed out after {timeout_sec}s due to network lag"
            except Exception as e:
                logger.warning(f"yt-dlp download-sections failed ({e}) ({mode_label}).")
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = str(e)

            # Stop the fallback chain as soon as its shared budget is exhausted.
            remaining_budget = int(overall_deadline - time.monotonic())
            if remaining_budget <= 0:
                last_err_snippet = f"overall download timeout: budget exhausted after {overall_timeout}s"
                break

            # Method 2: Fallback - Extract direct stream URLs with yt-dlp and slice using FFmpeg with network reconnect
            logger.info(f"Direct section download fallback ({last_err_snippet}), trying stream URL trimming with auto-reconnect ({mode_label})...")
            try:
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                url_cmd = [
                    *base_cmd,
                    "--socket-timeout", "20",
                    "-g",
                    "-f", "bestvideo[ext=mp4][vcodec^=avc1][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4][vcodec^=avc1][height<=1080]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/bestvideo+bestaudio/best",
                    clean_url
                ]
                url_res = subprocess.run(url_cmd, capture_output=True, text=True, timeout=min(30, max(1, int(overall_deadline - time.monotonic()))))
                if url_res.returncode == 0 and url_res.stdout.strip():
                    urls = url_res.stdout.strip().split("\n")
                    video_stream = urls[0]
                    audio_stream = urls[1] if len(urls) > 1 else urls[0]

                    # YouTube HLS manifest streams have already stalled for minutes on the
                    # direct FFmpeg path. Skip that expensive retry and let yt-dlp try
                    # its lower-resolution section-download fallbacks instead.
                    if "manifest.googlevideo.com/api/manifest/hls_playlist/" in video_stream:
                        last_err_snippet = "direct FFmpeg fallback skipped for stalled YouTube HLS stream"
                        logger.warning(
                            "Skipping direct FFmpeg stream trimming for YouTube HLS; "
                            "continuing with yt-dlp 720p/480p fallbacks."
                        )
                    else:
                        trim_timeout = max(240, min(900, int(clip_duration * 4.5) + 60))
                        trim_cmd = [
                            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                            "-reconnect", "1",
                            "-reconnect_at_eof", "1",
                            "-reconnect_streamed", "1",
                            "-reconnect_delay_max", "5",
                            "-ss", str(start_time),
                            "-i", video_stream,
                            "-ss", str(start_time),
                            "-i", audio_stream,
                            "-t", str(clip_duration),
                            "-map", "0:v:0", "-map", "1:a:0?",
                            *ACTIVE_ENCODER_ARGS,
                            "-c:a", "aac",
                            "-b:a", "192k",
                            "-avoid_negative_ts", "make_zero",
                            "-movflags", "+faststart",
                            str(output_path)
                        ]
                        def _on_direct_stream_progress(info):
                            if not progress_callback:
                                return
                            try:
                                current_size = output_path.stat().st_size if output_path.exists() else 0
                                downloaded_label = f"{current_size / (1024 * 1024):.1f} MB"
                            except OSError:
                                downloaded_label = ""
                            heartbeat = bool(info.get("heartbeat"))
                            speed_label = (
                                info.get("speed", "Menunggu data jaringan")
                                if heartbeat
                                else f"{info.get('speed', '0x')} proses FFmpeg"
                            )
                            progress_callback({
                                "percent": info.get("percent", 0.0),
                                "downloaded": downloaded_label,
                                "total": "ukuran hasil akhir belum diketahui",
                                "speed": speed_label,
                                "eta": "",
                                "phase": "stream_trim",
                            })

                        trim_res = _run_ffmpeg_with_progress(
                            trim_cmd,
                            min(trim_timeout, max(1, int(overall_deadline - time.monotonic()))),
                            _on_direct_stream_progress,
                            clip_duration
                        )
                        if trim_res.returncode == 0 and is_valid_mp4(output_path):
                            logger.info(f"Successfully trimmed stream URLs with FFmpeg ({mode_label}): {output_path} ({output_path.stat().st_size} bytes)")
                            return str(output_path)
                        else:
                            if output_path.exists():
                                try:
                                    output_path.unlink()
                                except Exception:
                                    pass
                            last_err_snippet = trim_res.stderr[:300] if (trim_res and trim_res.stderr) else "stream trimming failed"
            except Exception as e:
                logger.error(f"Fallback stream trimming failed ({mode_label}): {e}")
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = str(e)

            remaining_budget = int(overall_deadline - time.monotonic())
            if remaining_budget <= 0:
                last_err_snippet = f"overall download timeout: budget exhausted after {overall_timeout}s"
                break

            # Method 3: Fallback - Download at 720p (vastly lower bandwidth, skips SABR/1080p throttling)
            logger.info(f"Method 3: Attempting fast 720p fallback section download for {clean_url} ({mode_label})...")
            try:
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                cmd_720p = [
                    *base_cmd,
                    "--download-sections", f"*{t_start_fmt}-{t_end_fmt}",
                    "--force-keyframes-at-cuts",
                    "-f", "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
                    "-N", "4",
                    "--socket-timeout", "20",
                    "--fragment-retries", "5",
                    "--retries", "5",
                    "-o", str(output_path),
                    "--merge-output-format", "mp4",
                    "--no-warnings",
                    clean_url
                ]
                timeout_720p = max(200, min(600, int(clip_duration * 4) + 60))
                res_720p = _run_ytdlp_with_progress(cmd_720p, timeout=min(timeout_720p, max(1, int(overall_deadline - time.monotonic()))), progress_callback=progress_callback)
                if res_720p.returncode == 0 and is_valid_mp4(output_path):
                    logger.info(f"Successfully downloaded 720p fallback section ({mode_label}): {output_path} ({output_path.stat().st_size} bytes)")
                    return str(output_path)
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                if res_720p and res_720p.stderr:
                    last_err_snippet = res_720p.stderr[:300]
            except Exception as e:
                logger.warning(f"720p fallback failed ({mode_label}): {e}")
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = str(e)

            remaining_budget = int(overall_deadline - time.monotonic())
            if remaining_budget <= 0:
                last_err_snippet = f"overall download timeout: budget exhausted after {overall_timeout}s"
                break

            # Method 4: Fallback - Download at 480p / lowest bandwidth (guaranteed to succeed on high lag)
            logger.info(f"Method 4: Attempting low-bandwidth 480p fallback section download for {clean_url} ({mode_label})...")
            try:
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                cmd_480p = [
                    *base_cmd,
                    "--download-sections", f"*{t_start_fmt}-{t_end_fmt}",
                    "--force-keyframes-at-cuts",
                    "-f", "bestvideo[height<=480]+bestaudio/best[height<=480]/18/best",
                    "-N", "2",
                    "--socket-timeout", "20",
                    "--fragment-retries", "3",
                    "--retries", "3",
                    "-o", str(output_path),
                    "--merge-output-format", "mp4",
                    "--no-warnings",
                    clean_url
                ]
                timeout_480p = max(150, min(450, int(clip_duration * 3) + 45))
                res_480p = _run_ytdlp_with_progress(cmd_480p, timeout=min(timeout_480p, max(1, int(overall_deadline - time.monotonic()))), progress_callback=progress_callback)
                if res_480p.returncode == 0 and is_valid_mp4(output_path):
                    logger.info(f"Successfully downloaded 480p fallback section ({mode_label}): {output_path} ({output_path.stat().st_size} bytes)")
                    return str(output_path)
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                if res_480p and res_480p.stderr:
                    last_err_snippet = res_480p.stderr[:300]
            except Exception as e:
                logger.warning(f"480p fallback failed ({mode_label}): {e}")
                if output_path.exists():
                    try:
                        output_path.unlink()
                    except Exception:
                        pass
                last_err_snippet = str(e)

            # Only retry without cookies when the failure looks like an auth/session rejection.
            # Network timeouts are shared across all methods and should not be repeated in guest mode.
            if use_cookies:
                auth_error_terms = (
                    "reloaded", "reload", "confirm you're not a bot",
                    "sign in", "login", "authentication", "cookie",
                    "403", "429"
                )
                if not any(term in last_err_snippet.lower() for term in auth_error_terms):
                    logger.info(
                        "Skipping guest-mode retry because the cookie attempt failed "
                        "for a non-auth reason; avoiding duplicate network retries."
                    )
                    break
                logger.warning(
                    f"Download with cookies failed due to a likely auth/session issue "
                    f"({last_err_snippet}). Attempting guest mode once..."
                )

    # Ensure any corrupt partial file is unlinked
    if output_path.exists():
        try:
            output_path.unlink()
        except Exception:
            pass

    err_lower = last_err_snippet.lower()
    if "reloaded" in err_lower or "reload" in err_lower:
        raise RuntimeError("YouTube rejected the session cookies ('The page needs to be reloaded'). Your cookies.txt may have expired or need refreshing. Please re-export fresh cookies from an active YouTube tab using the 🍪 Cookies Manager button in the top navbar.")
    if "confirm you're not a bot" in err_lower or "sign in" in err_lower or "login" in err_lower:
        raise RuntimeError("YouTube blocked video download (Bot verification). Please import/save fresh YouTube cookies using the 🍪 Cookies Manager button in the top navbar.")
    if "timed out" in err_lower or "timeout" in err_lower:
        raise RuntimeError("Video download timed out due to slow internet connection or lag. You can retry this clip anytime.")
    raise RuntimeError(f"Failed to download video clip segment from YouTube ({last_err_snippet}). Check your internet connection or cookies.")


def download_full_raw_video(
    video_url: str,
    output_path: Union[str, Path],
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    cookies_content: Optional[str] = None
) -> str:
    """
    Downloads the full raw video from YouTube in maximum quality (up to 1080p),
    or copies the local uploaded / Google Drive video file directly.
    """
    local_source = None
    if os.path.exists(video_url):
        local_source = Path(video_url)
    elif video_url.startswith("/api/video/"):
        candidate = UPLOADS_DIR / os.path.basename(video_url.split("?")[0])
        if candidate.exists():
            local_source = candidate
    if not local_source or not local_source.exists():
        clean_name = os.path.basename(video_url.split("?")[0]).strip()
        from backend.routers.media import _find_video_file_on_disk
        local_source = _find_video_file_on_disk(clean_name)

    if local_source and local_source.exists():
        logger.info(f"Copying local source video to raw output: {local_source} -> {output_path}")
        if not is_valid_mp4(local_source):
            raise RuntimeError(
                f"Local source video is invalid or incomplete: {local_source.name}. "
                "Please re-upload or re-analyze the source video."
            )
        shutil.copyfile(str(local_source), str(output_path))
        if not is_valid_mp4(output_path):
            try:
                os.unlink(output_path)
            except OSError:
                pass
            raise RuntimeError(
                "Copied local video failed MP4 validation. Please retry or re-upload the source."
            )
        if progress_callback:
            progress_callback({"percent": 100.0, "downloaded": "Complete", "total": "Complete", "speed": "", "eta": ""})
        return str(output_path)

    clean_url = video_url.strip()
    if is_twitch_url(clean_url):
        tw_info = extract_twitch_info(clean_url)
        clean_url = get_twitch_canonical_url(tw_info) if tw_info else clean_url
    elif not clean_url.startswith("http"):
        clean_url = f"https://www.youtube.com/watch?v={clean_url}"

    with ephemeral_cookies_file(cookies_content) as temp_cookies:
        has_cookies = temp_cookies is not None or get_effective_cookies_path() is not None
        attempts = [True, False] if has_cookies else [False]

        for use_cookies in attempts:
            base_cmd = get_yt_dlp_base_cmd(include_cookies=use_cookies, cookies_path=temp_cookies if use_cookies else None)
            mode_label = "with cookies" if use_cookies else "guest mode (without cookies)"
            cmd = [
                *base_cmd,
                "--no-colors",
                "-f", "bestvideo[height<=1080]+bestaudio/best[height<=1080]/bestvideo+bestaudio/best",
                "-o", str(output_path),
                "--merge-output-format", "mp4",
                "--socket-timeout", "20",
                "--retries", "5",
                "--fragment-retries", "5",
                "--file-access-retries", "3",
                "-N", "4",
                "--newline",
                "--progress-template", "download:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
                clean_url
            ]
            logger.info(f"Downloading full raw video ({mode_label}) from {clean_url} to {output_path}...")

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=(os.name == "posix"),
            )

            # Drain stdout on a dedicated thread so a stalled network request
            # cannot block the event loop worker forever inside readline().
            output_queue: queue.Queue = queue.Queue()

            def _read_download_output():
                try:
                    if process.stdout is not None:
                        for output_line in iter(process.stdout.readline, ""):
                            output_queue.put(output_line)
                finally:
                    output_queue.put(None)

            reader = threading.Thread(
                target=_read_download_output,
                name=f"yt-dlp-log-{Path(output_path).name}",
                daemon=True,
            )
            reader.start()

            try:
                total_timeout = max(
                    300,
                    int(os.environ.get("CHEAT_CLIP_RAW_DOWNLOAD_TIMEOUT", "21600")),
                )
            except (TypeError, ValueError):
                total_timeout = 21600
            try:
                idle_timeout = max(
                    60,
                    int(os.environ.get("CHEAT_CLIP_DOWNLOAD_IDLE_TIMEOUT", "300")),
                )
            except (TypeError, ValueError):
                idle_timeout = 300
            started_at = time.monotonic()
            last_output_at = started_at
            last_progress_at = started_at
            last_heartbeat_at = started_at
            last_progress_payload = {
                "percent": 0.0, "downloaded": "", "total": "", "speed": "", "eta": ""
            }
            reader_finished = False
            timeout_reason = None

            while not reader_finished:
                elapsed = time.monotonic() - started_at
                if elapsed >= total_timeout:
                    timeout_reason = f"total download timeout ({total_timeout}s)"
                    break

                try:
                    line = output_queue.get(timeout=min(1.0, total_timeout - elapsed))
                except queue.Empty:
                    now = time.monotonic()
                    if progress_callback and now - last_heartbeat_at >= 2.0:
                        wait_seconds = int(now - last_progress_at)
                        progress_callback({
                            **last_progress_payload,
                            "speed": f"Menunggu respons jaringan ({wait_seconds} dtk)",
                            "heartbeat": True,
                        })
                        last_heartbeat_at = now
                    if now - last_output_at >= idle_timeout:
                        timeout_reason = f"no yt-dlp output for {idle_timeout}s"
                        break
                    continue

                if line is None:
                    reader_finished = True
                    break

                last_output_at = time.monotonic()
                raw_line = line.strip()
                if not raw_line:
                    continue
                clean_line = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', raw_line).strip()

                if clean_line.startswith("download:") and progress_callback:
                    raw_data = clean_line[len("download:"):].strip()
                    parts = raw_data.split("|")
                    if len(parts) >= 5:
                        pct_str, dl_str, tot_str, spd_str, eta_str = parts[0], parts[1], parts[2], parts[3], parts[4]
                        try:
                            clean_pct = re.sub(r'[^0-9.]', '', pct_str)
                            pct_val = float(clean_pct) if clean_pct else 0.0
                        except Exception:
                            pct_val = 0.0
                        last_progress_payload = {
                            "percent": pct_val,
                            "downloaded": dl_str.strip() if dl_str and dl_str != "NA" else f"{pct_val:.1f}%",
                            "total": tot_str.strip() if tot_str and tot_str != "NA" else "",
                            "speed": spd_str.strip() if spd_str and spd_str != "NA" else "",
                            "eta": eta_str.strip() if eta_str and eta_str != "NA" else ""
                        }
                        last_progress_at = time.monotonic()
                        last_heartbeat_at = last_progress_at
                        progress_callback(last_progress_payload)
                elif "[download]" in clean_line and progress_callback:
                    match = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*%', clean_line)
                    if match:
                        try:
                            pct_val = float(match.group(1))
                        except Exception:
                            pct_val = 0.0
                        spd_match = re.search(r'at\s+([0-9.]+\s*[a-zA-Z]+/s)', clean_line)
                        eta_match = re.search(r'ETA\s+([0-9:]+)', clean_line)
                        tot_match = re.search(r'of\s+~?([0-9.]+\s*[a-zA-Z]+)', clean_line)
                        last_progress_payload = {
                            "percent": pct_val,
                            "downloaded": f"{pct_val:.1f}%",
                            "total": tot_match.group(1) if tot_match else "",
                            "speed": spd_match.group(1) if spd_match else "",
                            "eta": eta_match.group(1) if eta_match else ""
                        }
                        last_progress_at = time.monotonic()
                        last_heartbeat_at = last_progress_at
                        progress_callback(last_progress_payload)

            if timeout_reason:
                logger.warning(
                    f"Full raw video download stopped for {clean_url} ({mode_label}): {timeout_reason}"
                )
                _terminate_process_tree(process)
                if process.stdout:
                    try:
                        process.stdout.close()
                    except Exception:
                        pass
                reader.join(timeout=1)
                if os.path.exists(output_path):
                    try:
                        os.unlink(output_path)
                    except Exception:
                        pass
                if "idle" in timeout_reason:
                    raise RuntimeError(
                        f"Video download timed out after {idle_timeout} seconds without receiving data. "
                        "Check the internet connection and retry."
                    )
                raise RuntimeError(
                    f"Video download exceeded the maximum allowed time ({total_timeout} seconds)."
                )

            try:
                returncode = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                if os.path.exists(output_path):
                    try:
                        os.unlink(output_path)
                    except Exception:
                        pass
                raise RuntimeError("Video download process did not exit after closing its output stream.")

            reader.join(timeout=1)
            if process.stdout:
                process.stdout.close()

            if (
                returncode == 0
                and os.path.exists(output_path)
                and os.path.getsize(output_path) > 10000
                and is_valid_mp4(output_path)
            ):
                logger.info(
                    f"Full raw video downloaded successfully ({mode_label}, "
                    f"{os.path.getsize(output_path)} bytes)"
                )
                return str(output_path)

            if os.path.exists(output_path):
                try:
                    os.unlink(output_path)
                except Exception:
                    pass

            if use_cookies:
                logger.warning(
                    f"Full raw video download with cookies exited with code {returncode} "
                    "or produced an invalid MP4. Retrying in guest mode..."
                )

    raise RuntimeError("Failed to download raw video. Please check your cookies or network connection.")


def clean_caption_text(text: str) -> str:
    """
    Cleans transcripted subtitle/caption text by:
    1. Removing sound/action tags like [LAUGHTER], [APPLAUSE], [MUSIC], (laughter), *cheering*.
    2. Removing common sound effect words if present.
    3. Stripping all symbols EXCEPT '.', ',', '%', '&', '$', '?' (keeping alphanumeric characters and spaces).
    4. Normalizing whitespace.
    """
    if not text:
        return ""
    # 1. Remove bracketed, parenthesized, or asterisk tags (e.g. [LAUGHTER], (music), *cheering*)
    t = re.sub(r'\[.*?\]|\(.*?\)|[\*].*?[\*]', ' ', text)
    # 2. Remove common unbracketed sound tags
    t = re.sub(r'\b(laughter|applause|music|cheering|snickering|giggle|cough)\b', ' ', t, flags=re.IGNORECASE)
    # 3. Strip leading and trailing ellipses / periods (e.g. "...Stroavirus..." -> "Stroavirus")
    t = re.sub(r'^\s*[\.\,\…\:\;]+\s*', '', t)
    t = re.sub(r'\s*[\.\,\…\:\;]+\s*$', '', t)
    # 4. Remove all symbols except . , % & $ ? (keep letters, digits, whitespace, . , % & $ ?)
    # Note: in Python regex \w includes '_', so we explicitly eliminate '_'
    t = re.sub(r'[^\w\s.,%&$?]|_', '', t)
    # 5. Collapse multiple spaces and trim
    t = re.sub(r'\s+', ' ', t).strip()
    # If the string consists purely of punctuation, clear it
    if re.fullmatch(r'[\.\,\%\&\$\? ]+', t):
        return ""
    return t


def transcribe_clip_words(
    video_path: str,
    fallback_transcript: Optional[List[Dict[str, Any]]] = None,
    clip_start_time: float = 0.0,
    clip_end_time: float = 0.0,
    target_language: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Transcribes word-level timestamps directly from the sliced clip audio using Whisper AI.
    Listens directly to the audio waveform of the sliced clip (0.0s = start of clip) for 100% acoustic accuracy.
    Applies explicit language constraints, custom Indonesian/English initial prompt context,
    condition_on_previous_text=False, and hallucination suppression to eliminate phantom/corrupted words.
    Falls back to transcript distribution only if Whisper AI is not available.
    """
    # Normalize requested source bounds once; transcript timestamps are source-absolute,
    # while Whisper timestamps from the downloaded segment are clip-relative.
    try:
        source_clip_start = float(clip_start_time)
        source_clip_end = float(clip_end_time)
    except (TypeError, ValueError, OverflowError):
        source_clip_start, source_clip_end = 0.0, 0.0
    if not math.isfinite(source_clip_start):
        source_clip_start = 0.0
    if not math.isfinite(source_clip_end):
        source_clip_end = 0.0
    has_clip_bounds = source_clip_end > source_clip_start
    clip_duration = source_clip_end - source_clip_start if has_clip_bounds else None

    # Auto-detect language from fallback transcript if not explicitly provided
    if not target_language and fallback_transcript:
        try:
            from backend.utils.text import detect_transcript_language
            detected = detect_transcript_language(fallback_transcript[:50])
            if detected and detected.get("code") in ("id", "en"):
                target_language = detected["code"]
        except Exception:
            pass

    # 1. Primary: Run Whisper directly on sliced clip audio for exact acoustic timestamps
    whisper_model = get_whisper_model()
    if whisper_model is not None and os.path.exists(video_path):
        try:
            logger.info(f"Running Whisper acoustic word transcription on: {os.path.basename(video_path)} (target_language={target_language})...")

            # Extract dialogue context from fallback transcript for this time window to guide Whisper decoding
            context_hint = ""
            if fallback_transcript and has_clip_bounds:
                matching_lines = []
                for line in fallback_transcript:
                    if not isinstance(line, dict):
                        continue
                    try:
                        line_start = float(line.get("start", 0.0))
                        line_end = float(line.get("end", line_start + float(line.get("duration", 2.0))))
                    except (TypeError, ValueError, OverflowError):
                        continue
                    if not math.isfinite(line_start) or not math.isfinite(line_end):
                        continue
                    if line_start <= source_clip_end + 1.0 and line_end >= source_clip_start - 1.0:
                        text_hint = str(line.get("text", "")).strip()
                        if text_hint:
                            matching_lines.append(text_hint)
                if matching_lines:
                    context_hint = " ".join(matching_lines[:6])[:200]

            if target_language == "id":
                base_prompt = "Transkrip percakapan video dalam Bahasa Indonesia. Kosakata percakapan, gaming, dan santai."
            elif target_language == "en":
                base_prompt = "Video dialogue transcript in English. Conversational, gaming, and clear speech."
            else:
                base_prompt = "Transkrip video percakapan Bahasa Indonesia atau English."

            initial_prompt = f"{base_prompt} {context_hint}".strip() if context_hint else base_prompt

            transcribe_kwargs: Dict[str, Any] = {
                "word_timestamps": True,
                "fp16": False,
                "verbose": False,
                "condition_on_previous_text": False,  # Prevents repetition loops and hallucinations across silence
                "hallucination_silence_threshold": 1.5,
                "initial_prompt": initial_prompt,
            }
            if target_language in ("id", "en"):
                transcribe_kwargs["language"] = target_language

            result = None
            with _WHISPER_LOCK:
                try:
                    result = whisper_model.transcribe(
                        video_path,
                        **transcribe_kwargs
                    )
                except RuntimeError as re_err:
                    logger.warning(f"Whisper word_timestamps failed ({re_err}). Retrying with standard segment timestamps...")
                    transcribe_kwargs["word_timestamps"] = False
                    result = whisper_model.transcribe(
                        video_path,
                        **transcribe_kwargs
                    )

            words = []
            if result:
                for segment in result.get("segments", []):
                    seg_words = segment.get("words", [])
                    if seg_words:
                        for w in seg_words:
                            word_clean = clean_caption_text(w.get("word", "").strip())
                            # Skip ellipses, single punctuation, or empty tokens
                            if word_clean and word_clean not in (".", "..", "...", ",", "?"):
                                try:
                                    raw_start = float(w.get("start", 0.0))
                                    raw_end = float(w.get("end", raw_start + 0.25))
                                except (TypeError, ValueError, OverflowError):
                                    continue
                                if not math.isfinite(raw_start) or not math.isfinite(raw_end) or raw_end <= raw_start:
                                    continue
                                st = max(0.0, raw_start)
                                et = max(st + 0.12, raw_end)
                                words.append({
                                    "word": word_clean,
                                    "start": round(st, 2),
                                    "end": round(et, 2)
                                })
                    else:
                        # Segment timestamps fallback: interpolate words across start and end
                        seg_text = clean_caption_text(segment.get("text", "").strip())
                        seg_st = max(0.0, float(segment.get("start", 0.0)))
                        seg_et = max(seg_st + 0.5, float(segment.get("end", seg_st + 2.0)))
                        tokens = seg_text.split()
                        if tokens:
                            step_dur = (seg_et - seg_st) / len(tokens)
                            for idx, tok in enumerate(tokens):
                                w_st = seg_st + (idx * step_dur)
                                w_et = w_st + max(0.15, step_dur * 0.95)
                                words.append({
                                    "word": tok,
                                    "start": round(w_st, 2),
                                    "end": round(w_et, 2)
                                })

            if words:
                if clip_duration is not None:
                    words = _normalize_subtitle_word_times(words, clip_duration)
                else:
                    words = _normalize_subtitle_word_times(words, 24.0 * 60.0 * 60.0)
                if words:
                    logger.info(f"Whisper successfully transcribed {len(words)} acoustic words for clip.")
                    return words
        except Exception as e:
            logger.warning(f"Whisper acoustic transcription error: {e}")

    # 2. Secondary fallback: Use fallback_transcript if Whisper model is unavailable
    if fallback_transcript:
        words = []
        for line in fallback_transcript:
            if not isinstance(line, dict):
                continue
            line_text = str(line.get("text", "")).strip()
            if not line_text:
                continue

            cleaned_line = clean_caption_text(line_text)
            if not cleaned_line:
                continue

            try:
                l_start = float(line.get("start", 0.0))
            except (TypeError, ValueError, OverflowError):
                continue
            if not math.isfinite(l_start):
                continue
            try:
                explicit_end = float(line.get("end", 0.0))
            except (TypeError, ValueError, OverflowError):
                explicit_end = 0.0
            try:
                line_duration = float(line.get("duration", 0.0))
            except (TypeError, ValueError, OverflowError):
                line_duration = 0.0
            if not math.isfinite(explicit_end):
                explicit_end = 0.0
            if not math.isfinite(line_duration):
                line_duration = 0.0
            if explicit_end > l_start:
                l_end = explicit_end
            elif line_duration > 0:
                l_end = l_start + line_duration
            else:
                words_cnt = max(1, len(cleaned_line.split()))
                l_end = l_start + max(1.8, words_cnt * 0.38)
            if not math.isfinite(l_end) or l_end <= l_start:
                continue

            if has_clip_bounds:
                if l_end < source_clip_start - 0.2 or l_start > source_clip_end + 0.2:
                    continue
                rel_start = max(0.0, l_start - source_clip_start)
                rel_end = max(rel_start + 0.15, l_end - source_clip_start)
                rel_end = min(clip_duration, rel_end)
                if rel_end <= rel_start:
                    continue
            else:
                rel_start = max(0.0, l_start)
                rel_end = max(rel_start + 0.15, l_end)

            line_words = cleaned_line.split()
            if not line_words:
                continue
            # Natural speech timing calibration: respect line duration unless trailing silence is detected
            raw_line_dur = max(0.4, rel_end - rel_start)
            max_plausible_dur = len(line_words) * 0.52 + 0.25
            spoken_dur = min(raw_line_dur, max_plausible_dur)
            weights = [max(2, len(re.sub(r'[^a-zA-Z0-9]', '', w)) or len(w)) for w in line_words]
            total_w = sum(weights) or 1
            cur_s = rel_start
            for i, w in enumerate(line_words):
                w_dur = max(0.14, min(0.60, spoken_dur * (weights[i] / total_w)))
                w_e = cur_s + w_dur
                words.append({
                    "word": w,
                    "start": round(cur_s, 2),
                    "end": round(w_e, 2)
                })
                cur_s = w_e
        if words:
            bound = clip_duration if clip_duration is not None else 24.0 * 60.0 * 60.0
            words = _normalize_subtitle_word_times(words, bound)
            if words:
                logger.info(f"Fallback: using transcript words for clip range [{source_clip_start:.1f}s -> {source_clip_end:.1f}s].")
                return words

    return []


def format_ass_timestamp(seconds: float) -> str:
    """Format finite seconds as ASS H:MM:SS.cs, carrying rounded centiseconds."""
    try:
        value = float(seconds)
    except (TypeError, ValueError, OverflowError):
        value = 0.0
    if not math.isfinite(value) or value < 0:
        value = 0.0
    total_cs = int(round(value * 100))
    total_seconds, cs = divmod(total_cs, 100)
    h, remainder = divmod(total_seconds, 3600)
    m, sec = divmod(remainder, 60)
    return f"{h}:{m:02d}:{sec:02d}.{cs:02d}"


def _normalize_subtitle_word_times(
    words: List[Dict[str, Any]],
    duration_seconds: float,
    subtitle_offset_seconds: float = 0.0,
) -> List[Dict[str, Any]]:
    """Return finite, clip-bounded word intervals after applying subtitle sync offset."""
    try:
        duration = float(duration_seconds)
    except (TypeError, ValueError, OverflowError):
        duration = 60.0
    if not math.isfinite(duration) or duration <= 0:
        duration = 60.0
    duration = min(duration, 24.0 * 60.0 * 60.0)

    try:
        offset = float(subtitle_offset_seconds or 0.0)
    except (TypeError, ValueError, OverflowError):
        offset = 0.0
    if not math.isfinite(offset):
        offset = 0.0
    offset = max(-30.0, min(30.0, offset))

    normalized: List[Dict[str, Any]] = []
    for item in words or []:
        if not isinstance(item, dict):
            continue
        try:
            start = float(item.get("start", 0.0)) + offset
            end = float(item.get("end", item.get("start", 0.0))) + offset
        except (TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(start) or not math.isfinite(end):
            continue
        start = max(0.0, min(duration, start))
        end = max(0.0, min(duration, end))
        if end <= start:
            continue
        normalized.append({**item, "start": start, "end": end})
    normalized.sort(key=lambda item: (item["start"], item["end"]))
    return normalized


def apply_text_case(text: str, mode: str) -> str:
    """Applies uppercase, capitalize (Title Case), or lowercase to text."""
    clean = text.strip()
    if mode == "uppercase":
        return clean.upper()
    elif mode == "lowercase":
        return clean.lower()
    elif mode == "capitalize":
        return clean.title()
    return clean


def wrap_title_smart(text: str, max_single_len: int = 22) -> Tuple[str, int]:
    """
    Wraps title cleanly into 1, 2, 3 or more balanced lines separated by \\N.
    Preserves manual newlines if present, otherwise balances words across lines.
    Returns (formatted_title, line_count).
    """
    raw = text.strip()
    if not raw:
        return "", 1

    # Preserve manual newlines if the user specifically broke lines
    if "\n" in raw:
        lines = [l.strip() for l in raw.split("\n") if l.strip()]
        return "\\N".join(lines), len(lines)

    words = raw.split()
    if len(words) <= 1:
        return raw, 1

    total_len = len(raw)
    if total_len <= max_single_len:
        return raw, 1

    # Determine target line count dynamically based on character count and max_single_len
    target_lines = min(4, max(2, math.ceil(total_len / max_single_len)))

    target_per_line = total_len / target_lines
    lines = []
    current_line = []
    current_len = 0

    for i, w in enumerate(words):
        remaining_words = len(words) - i
        remaining_lines = target_lines - len(lines)
        if remaining_lines > 1 and len(current_line) > 0 and (current_len + len(w) > target_per_line * 1.15 or remaining_words <= remaining_lines - 1):
            lines.append(" ".join(current_line))
            current_line = [w]
            current_len = len(w)
        else:
            current_line.append(w)
            current_len += len(w) + 1

    if current_line:
        lines.append(" ".join(current_line))

    return "\\N".join(lines), len(lines)


def is_emoji_char(ch: str) -> bool:
    """Checks if a character is an emoji, symbol, or emoji presentation modifier."""
    code = ord(ch)
    if (0x1F000 <= code <= 0x1FAFF or
        0x2600 <= code <= 0x27BF or
        0x2300 <= code <= 0x23FF or
        0x2B50 <= code <= 0x2B55 or
        code == 0x200D or
        0xFE00 <= code <= 0xFE0F or
        code == 0x20E3):
        return True
    cat = unicodedata.category(ch)
    return cat in ('So', 'Sk')


def has_emoji(text: Optional[str]) -> bool:
    """Returns True if the string contains one or more emoji characters."""
    if not text:
        return False
    return any(is_emoji_char(ch) for ch in text)


def split_text_and_emojis(text: str) -> List[Tuple[str, str]]:
    """Splits text into contiguous runs of ('emoji', text) and ('text', text)."""
    segments = []
    if not text:
        return segments
    current_type = None
    current_buf = []
    for ch in text:
        t = 'emoji' if is_emoji_char(ch) else 'text'
        if current_type is None:
            current_type = t
            current_buf.append(ch)
        elif t == current_type:
            current_buf.append(ch)
        else:
            segments.append((current_type, "".join(current_buf)))
            current_type = t
            current_buf = [ch]
    if current_buf:
        segments.append((current_type, "".join(current_buf)))
    return segments


def _resolve_font_file(font_name: str = "Montserrat") -> Optional[Path]:
    """Resolve a font by filename OR embedded family name (custom uploads included)."""
    fonts_dir = Path(FONTS_DIR)
    requested = str(font_name or "Montserrat").strip()
    if not requested:
        requested = "Montserrat"

    # Fast path: the selected value is already a filename/stem.
    for candidate in (fonts_dir / requested, fonts_dir / f"{requested}.ttf", fonts_dir / f"{requested}.otf"):
        if candidate.is_file() and candidate.suffix.lower() in {".ttf", ".otf"}:
            return candidate

    # Uploaded fonts are saved by their original filename, while the UI stores
    # the embedded family name. Match that family name instead of silently
    # falling back to Montserrat.
    if fonts_dir.is_dir():
        try:
            from PIL import ImageFont
            for candidate in sorted(fonts_dir.iterdir(), key=lambda item: item.name.casefold()):
                if not candidate.is_file() or candidate.suffix.lower() not in {".ttf", ".otf"}:
                    continue
                try:
                    family = ImageFont.truetype(str(candidate), 16).getname()[0]
                    if str(family).strip().casefold() == requested.casefold():
                        return candidate
                except Exception:
                    continue
        except Exception as exc:
            logger.debug("Could not scan font family names: %s", exc)
    return None


def get_font(font_name: str, size: int) -> ImageFont.FreeTypeFont:
    """Loads the selected bundled/custom font, with a deterministic fallback."""
    selected = _resolve_font_file(font_name)
    fallback = selected or _resolve_font_file("Montserrat")
    if fallback:
        try:
            return ImageFont.truetype(str(fallback), max(1, int(size)))
        except Exception as exc:
            logger.warning("Could not load font '%s': %s", fallback.name, exc)
    return ImageFont.load_default()


def get_emoji_font(size: int) -> Optional[ImageFont.FreeTypeFont]:
    """Finds and loads a color emoji font (seguiemj.ttf, NotoColorEmoji.ttf, etc.)."""
    env_emoji = os.environ.get("EMOJI_FONT_PATH", "").strip()
    candidates = [
        env_emoji if env_emoji else None,
        str(FONTS_DIR / "seguiemj.ttf"),
        str(FONTS_DIR / "NotoColorEmoji.ttf"),
        "C:/Windows/Fonts/seguiemj.ttf",
        "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf",
        "/usr/share/fonts/google-noto-color-emoji/NotoColorEmoji.ttf",
        "/usr/share/fonts/opentype/noto/NotoColorEmoji.otf",
        "/usr/share/fonts/truetype/ancient-scripts/Symbola_hint.ttf",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            try:
                return ImageFont.truetype(c, size)
            except Exception as e:
                logger.debug(f"Could not load emoji font {c}: {e}")
    return None


def get_ffmpeg_safe_font_path(font_name: str = "Montserrat") -> str:
    """Returns an escaped font file path safe for FFmpeg drawtext filter to avoid Fontconfig errors on Windows."""
    fonts_dir = Path(FONTS_DIR)
    selected = _resolve_font_file(font_name)
    fallback = selected or _resolve_font_file("Montserrat") or _resolve_font_file("Inter")
    if fallback and fallback.is_file():
        clean = str(fallback.resolve()).replace("\\", "/")
        return clean.replace(":", "\\:")
    win_font = Path("C:/Windows/Fonts/arial.ttf")
    if win_font.exists():
        clean = str(win_font.resolve()).replace("\\", "/")
        return clean.replace(":", "\\:")
    return ""


def render_text_watermark_png(
    text: str,
    output_png_path: str,
    font_name: str = "Montserrat",
    font_size: int = 48,
    font_color: Tuple[int, int, int] = (255, 255, 255),
    border_color: Tuple[int, int, int] = (0, 0, 0),
    border_width: int = 2
) -> Optional[str]:
    """
    Renders text watermark (handles, usernames, hashtags, emojis) to a transparent PNG.
    Guarantees 100% immune to Fontconfig errors on Windows/Linux/Docker and supports color emojis.
    """
    clean_text = str(text or "").strip()
    if not clean_text:
        return None

    # Resolve fonts
    text_font = get_font(font_name, font_size)
    emoji_font = get_emoji_font(int(font_size * 0.90))

    # Measure segments
    segments = split_text_and_emojis(clean_text)
    if not segments:
        segments = [('text', clean_text)]

    temp_img = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    temp_draw = ImageDraw.Draw(temp_img)

    seg_widths = []
    max_h = 0
    for kind, chunk in segments:
        f = emoji_font if (kind == 'emoji' and emoji_font) else text_font
        bbox = temp_draw.textbbox((0, 0), chunk, font=f)
        w = max(1, bbox[2] - bbox[0])
        h = max(1, bbox[3] - bbox[1])
        seg_widths.append(w)
        max_h = max(max_h, h)

    total_w = sum(seg_widths)
    pad = max(6, int(font_size * 0.20))
    canvas_w = total_w + (pad * 2) + (border_width * 4)
    canvas_h = max_h + (pad * 2) + (border_width * 4)

    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    cur_x = pad + border_width
    y_pos = pad + border_width

    # Draw text outline and fills
    for (kind, chunk), w in zip(segments, seg_widths):
        if kind == 'emoji' and emoji_font:
            draw.text((cur_x, y_pos), chunk, font=emoji_font, embedded_color=True)
        else:
            draw.text(
                (cur_x, y_pos),
                chunk,
                font=text_font,
                fill=(*font_color, 255),
                stroke_width=max(1, border_width),
                stroke_fill=(*border_color, 230)
            )
        cur_x += w

    os.makedirs(os.path.dirname(os.path.abspath(output_png_path)), exist_ok=True)
    img.save(output_png_path, "PNG")
    return output_png_path


def render_title_overlay_png(
    title_text: str,
    output_png_path: str,
    font_name: str = "Montserrat",
    target_aspect_ratio: str = "9:16",
    font_size_preset: str = "medium",
    text_case: str = "uppercase",
    title_position: str = "auto",
    title_y_percent: Optional[float] = None,
    canvas_w: int = 1080,
    canvas_h: int = 1920,
    title_font_size_preset: Optional[str] = None,
    streamer_preset: Optional[str] = "none",
    title_font_name: Optional[str] = None,
    title_font_size_px: Optional[int] = None,
    title_text_case: Optional[str] = None,
    title_x_percent: Optional[float] = 50.0
) -> Optional[str]:
    """
    Renders the title with full-color emojis and bold styled typography into a transparent
    1080x1920 PNG overlay for seamless FFmpeg compositing.
    """
    if not title_text or title_position == "none":
        return None

    effective_title_font = title_font_name or font_name or "Montserrat"
    effective_title_case = title_text_case or text_case or "uppercase"
    effective_title_preset = (title_font_size_preset or font_size_preset or "medium").lower()

    if effective_title_preset == "small":
        max_wrap_len = 24
    elif effective_title_preset == "big":
        max_wrap_len = 13
    else:  # medium
        max_wrap_len = 19

    # Format Title & Determine Line Count
    formatted_title, title_line_count = wrap_title_smart(
        apply_text_case(title_text, effective_title_case),
        max_single_len=max_wrap_len
    )

    if not formatted_title:
        return None

    # Distinct, calibrated title font sizes based on preset or explicit px
    # Scaled by 1.30x so export perfectly matches the live framing preview (WYSIWYG)
    if title_font_size_px and int(title_font_size_px) > 0:
        if target_aspect_ratio == "16:9_landscape":
            title_font_size = max(24, int(round(int(title_font_size_px) * 1.30 * (1080 / 1920))))
        else:
            title_font_size = max(24, int(round(int(title_font_size_px) * 1.30)))
    elif effective_title_preset == "small":
        title_font_size = 58 if title_line_count >= 3 else 68
    elif effective_title_preset == "big":
        title_font_size = 106 if title_line_count >= 3 else 124
    else:  # medium
        title_font_size = 82 if title_line_count >= 3 else 94

    # Create dummy draw to measure line widths and prevent edge overflow
    temp_draw = ImageDraw.Draw(Image.new("RGBA", (canvas_w, canvas_h)))
    text_font = get_font(effective_title_font, title_font_size)
    emoji_font = get_emoji_font(int(title_font_size * 0.90))

    lines = [l.strip() for l in formatted_title.split("\\N") if l.strip()]
    if not lines:
        lines = [formatted_title]

    # Measure maximum line width to prevent clipping off screen edges
    max_line_w = 0
    for line in lines:
        seg_w = 0
        for kind, chunk in split_text_and_emojis(line):
            f = emoji_font if (kind == 'emoji' and emoji_font) else text_font
            bbox = temp_draw.textbbox((0, 0), chunk, font=f)
            seg_w += (bbox[2] - bbox[0])
        max_line_w = max(max_line_w, seg_w)

    max_allowed_w = canvas_w - 70  # 1010px safe width
    if max_line_w > max_allowed_w and max_line_w > 0:
        scale_factor = max_allowed_w / max_line_w
        title_font_size = max(40, int(title_font_size * scale_factor))
        text_font = get_font(font_name, title_font_size)
        emoji_font = get_emoji_font(int(title_font_size * 0.90))

    # Content boundaries for aspect ratios
    if target_aspect_ratio == "16:9_landscape":
        content_top = 0
        content_bot = 1080
    elif streamer_preset == "split_top_cam":
        if target_aspect_ratio == "16:9":
            content_top = 352
            content_bot = 1568
        elif target_aspect_ratio == "4:3":
            content_top = 150
            content_bot = 1770
        else:  # 1:1 and 9:16
            content_top = 0
            content_bot = 1920
    else:
        if target_aspect_ratio == "1:1":
            content_top = 420
            content_bot = 1500
        elif target_aspect_ratio == "4:3":
            content_top = 555
            content_bot = 1365
        elif target_aspect_ratio == "16:9":
            content_top = 656
            content_bot = 1264
        else:  # 9:16
            content_top = 0
            content_bot = 1920

    line_step = int(title_font_size * 1.08)
    est_title_h = int(title_line_count * line_step)

    # Title Positioning (100% WYSIWYG matching framing preview):
    if target_aspect_ratio == "16:9_landscape":
        effective_title_y_pct = float(title_y_percent) if title_y_percent is not None else (5.5 if title_line_count >= 3 else (6.5 if title_line_count == 2 else 8.0))
        title_y = max(10, min(1000, int(round(1080 * (effective_title_y_pct / 100.0)))))
    elif title_y_percent is not None:
        effective_title_y_pct = float(title_y_percent)
        title_y = max(10, min(1800, int(round(1920 * (effective_title_y_pct / 100.0)))))
    else:
        if streamer_preset == "split_top_cam":
            effective_title_y_pct = 3.5 if title_line_count >= 3 else 4.5
        elif target_aspect_ratio == "1:1":
            effective_title_y_pct = 11.5 if title_line_count >= 3 else (13.5 if title_line_count == 2 else 17.0)
        elif target_aspect_ratio == "4:3":
            effective_title_y_pct = 17.3 if title_line_count >= 3 else (19.3 if title_line_count == 2 else 23.6)
        elif target_aspect_ratio == "16:9":
            effective_title_y_pct = 22.6 if title_line_count >= 3 else (24.5 if title_line_count == 2 else 28.8)
        else:  # 9:16
            effective_title_y_pct = 12.0 if title_line_count >= 3 else (14.5 if title_line_count == 2 else 17.0)
        title_y = max(10, min(1800, int(round(1920 * (effective_title_y_pct / 100.0)))))

    # Create transparent canvas
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    stroke_width = max(3, int(title_font_size * 0.055))
    shadow_offset = max(2, int(title_font_size * 0.025))

    # Reference baseline height for uppercase text
    t_ref_bbox = draw.textbbox((0, 0), "HGY", font=text_font)
    t_ref_mid = (t_ref_bbox[1] + t_ref_bbox[3]) / 2.0

    for line_idx, line in enumerate(lines):
        line_top = title_y + (line_idx * line_step)
        segments = split_text_and_emojis(line)

        # 1. Measure total width
        segment_widths = []
        for kind, chunk in segments:
            f = emoji_font if (kind == 'emoji' and emoji_font) else text_font
            bbox = draw.textbbox((0, 0), chunk, font=f)
            w = bbox[2] - bbox[0]
            segment_widths.append(w)

        total_line_w = sum(segment_widths)
        t_x_pct = 50.0 if title_x_percent is None else float(title_x_percent)
        target_center_x = canvas_w * (t_x_pct / 100.0)
        start_x = max(16.0, min(canvas_w - total_line_w - 16.0, target_center_x - (total_line_w / 2.0)))

        # 2. Draw shadow first (for text segments)
        cur_x = start_x
        for (kind, chunk), w in zip(segments, segment_widths):
            if kind != 'emoji':
                draw.text(
                    (cur_x + shadow_offset, line_top + shadow_offset),
                    chunk,
                    font=text_font,
                    fill=(0, 0, 0, 160),
                    stroke_width=stroke_width,
                    stroke_fill=(0, 0, 0, 160)
                )
            cur_x += w

        # 3. Draw outline / stroke and color emojis
        cur_x = start_x
        for (kind, chunk), w in zip(segments, segment_widths):
            if kind == 'emoji' and emoji_font:
                e_bbox = draw.textbbox((0, 0), chunk, font=emoji_font)
                e_mid = (e_bbox[1] + e_bbox[3]) / 2.0
                offset_y = t_ref_mid - e_mid

                draw.text(
                    (cur_x, line_top + offset_y),
                    chunk,
                    font=emoji_font,
                    embedded_color=True
                )
            else:
                draw.text(
                    (cur_x, line_top),
                    chunk,
                    font=text_font,
                    fill=(255, 255, 255, 255),
                    stroke_width=stroke_width,
                    stroke_fill=(0, 0, 0, 255)
                )
            cur_x += w

    os.makedirs(os.path.dirname(output_png_path), exist_ok=True)
    img.save(output_png_path, "PNG")
    return output_png_path


def escape_ass_text(text: str) -> str:
    """Escapes special ASS subtitle control characters (curly braces, backslashes) to prevent tag injection."""
    if not text:
        return ""
    return str(text).replace("{", "｛").replace("}", "｝").replace("\\", "＼")


def generate_ass_file(
    words: List[Dict[str, Any]],
    style_preset: str,
    font_name: str,
    output_ass_path: str,
    target_aspect_ratio: str = "9:16",
    font_size_preset: str = "medium",
    text_case: str = "uppercase",
    title_text: Optional[str] = None,
    title_position: str = "auto",
    title_duration: str = "entire",
    duration_seconds: float = 60.0,
    title_y_percent: Optional[float] = None,
    subtitle_y_percent: Optional[float] = None,
    subtitle_position_mode: str = "bottom",
    subtitle_center_y_percent: float = 50.0,
    skip_title: bool = False,
    title_font_size_preset: Optional[str] = None,
    streamer_preset: Optional[str] = "none",
    title_font_name: Optional[str] = None,
    font_size_px: Optional[int] = None,
    title_font_size_px: Optional[int] = None,
    title_text_case: Optional[str] = None,
    title_x_percent: Optional[float] = 50.0,
    subtitle_offset_seconds: Optional[float] = 0.0
) -> str:
    """
    Generates an Advanced SubStation Alpha (.ass) subtitle and title file with karaoke / word-level animation.
    Enforces WrapStyle: 2 and short 1-to-3 word chunks so subtitles are ALWAYS strictly 1 line.
    Uses \\an2\\pos(540, Y) for bottom or \\an5\\pos(540, Y) for center to permanently freeze subtitle in place.
    Keeps title and subtitle snug and close to video content (top & bottom) without touching.
    Supports subtitle_position_mode ('bottom' | 'center') with custom center Y position.
    """
    def _safe_percent(value: Any, default: float) -> float:
        try:
            parsed = float(value)
        except (TypeError, ValueError, OverflowError):
            return default
        if not math.isfinite(parsed):
            return default
        return max(0.0, min(100.0, parsed))

    # Render settings may come from older clients or hand-crafted API requests.
    # Clamp positioning values here so malformed values cannot push text off-canvas.
    title_y_percent = _safe_percent(title_y_percent, 17.0) if title_y_percent is not None else None
    title_x_percent = _safe_percent(title_x_percent, 50.0)
    subtitle_y_percent = _safe_percent(subtitle_y_percent, 10.0) if subtitle_y_percent is not None else None
    subtitle_center_y_percent = _safe_percent(subtitle_center_y_percent, 50.0)
    subtitle_position_mode = subtitle_position_mode if subtitle_position_mode in ("bottom", "center") else "bottom"
    try:
        subtitle_offset_seconds = float(subtitle_offset_seconds or 0.0)
    except (TypeError, ValueError, OverflowError):
        subtitle_offset_seconds = 0.0
    if not math.isfinite(subtitle_offset_seconds):
        subtitle_offset_seconds = 0.0
    subtitle_offset_seconds = max(-30.0, min(30.0, subtitle_offset_seconds))

    effective_title_preset = (title_font_size_preset or font_size_preset or "medium").lower()
    effective_title_case = title_text_case or text_case or "uppercase"

    if effective_title_preset == "small":
        max_wrap_len = 24
    elif effective_title_preset == "big":
        max_wrap_len = 13
    else:  # medium
        max_wrap_len = 19

    # 1. Format Title & Determine Line Count
    if title_text and title_position != "none":
        sanitized_title = escape_ass_text(apply_text_case(title_text, effective_title_case))
        formatted_title, title_line_count = wrap_title_smart(
            sanitized_title,
            max_single_len=max_wrap_len
        )
    else:
        formatted_title, title_line_count = "", 1

    is_landscape = (target_aspect_ratio == "16:9_landscape")
    canvas_w = 1920 if is_landscape else 1080
    canvas_h = 1080 if is_landscape else 1920
    center_x = 960 if is_landscape else 540

    # 2. Font Sizes based on preset, with automatic scale-down for 3+ line titles
    if is_landscape:
        if font_size_preset == "small":
            sub_font_size = 40
        elif font_size_preset == "big":
            sub_font_size = 58
        else:
            sub_font_size = 48

        if effective_title_preset == "small":
            title_font_size = 38 if title_line_count >= 3 else 44
        elif effective_title_preset == "big":
            title_font_size = 64 if title_line_count >= 3 else 74
        else:
            title_font_size = 50 if title_line_count >= 3 else 58
    else:
        if font_size_preset == "small":
            sub_font_size = 65
        elif font_size_preset == "big":
            sub_font_size = 94
        else:  # medium
            sub_font_size = 78

        if effective_title_preset == "small":
            title_font_size = 65 if title_line_count >= 3 else 68
        elif effective_title_preset == "big":
            title_font_size = 106 if title_line_count >= 3 else 124
        else:  # medium
            title_font_size = 85 if title_line_count >= 3 else 94

    if font_size_px and int(font_size_px) > 0:
        sub_font_size = int(font_size_px)
    if title_font_size_px and int(title_font_size_px) > 0:
        if is_landscape:
            title_font_size = max(24, int(round(int(title_font_size_px) * 1.30 * (1080 / 1920))))
        else:
            title_font_size = max(24, int(round(int(title_font_size_px) * 1.30)))

    # 3. Content boundaries for aspect ratios
    if is_landscape:
        content_top = 0
        content_bot = 1080
    elif streamer_preset == "split_top_cam":
        if target_aspect_ratio == "16:9":
            content_top = 352
            content_bot = 1568
        elif target_aspect_ratio == "4:3":
            content_top = 150
            content_bot = 1770
        else:  # 1:1 and 9:16
            content_top = 0
            content_bot = 1920
    else:
        if target_aspect_ratio == "1:1":
            content_top = 420
            content_bot = 1500
        elif target_aspect_ratio == "4:3":
            content_top = 555
            content_bot = 1365
        elif target_aspect_ratio == "16:9":
            content_top = 656
            content_bot = 1264
        else:  # 9:16
            content_top = 0
            content_bot = 1920

    # Title line step matching 1.08x line height of live preview CSS box model
    line_step = int(title_font_size * 1.08)
    est_title_h = int(title_line_count * line_step)
    est_sub_h = int(sub_font_size * 1.08)
    sub_align = 5 if subtitle_position_mode == "center" else 2

    # Ensure title line width does not overflow screen edges in ASS
    title_lines_check = [l.strip() for l in formatted_title.split("\\N") if l.strip()]
    if title_lines_check:
        max_allowed_w = canvas_w - 70
        test_font = get_font(title_font_name or font_name, title_font_size)
        temp_draw = ImageDraw.Draw(Image.new("RGBA", (canvas_w, canvas_h)))
        max_w = 0
        for tl in title_lines_check:
            bbox = temp_draw.textbbox((0, 0), tl, font=test_font)
            max_w = max(max_w, bbox[2] - bbox[0])
        if max_w > max_allowed_w and max_w > 0:
            scale_factor = max_allowed_w / max_w
            title_font_size = max(30, int(title_font_size * scale_factor))
            line_step = int(title_font_size * 1.08)
            est_title_h = int(title_line_count * line_step)

    # Title Positioning (100% WYSIWYG matching framing preview):
    if is_landscape:
        effective_title_y_pct = float(title_y_percent) if title_y_percent is not None else (5.5 if title_line_count >= 3 else (6.5 if title_line_count == 2 else 8.0))
        title_y = max(10, min(1000, int(round(1080 * (effective_title_y_pct / 100.0)))))
    elif title_y_percent is not None:
        effective_title_y_pct = float(title_y_percent)
        title_y = max(10, min(1800, int(round(1920 * (effective_title_y_pct / 100.0)))))
    else:
        if streamer_preset == "split_top_cam":
            effective_title_y_pct = 3.5 if title_line_count >= 3 else 4.5
        elif target_aspect_ratio == "1:1":
            effective_title_y_pct = 11.5 if title_line_count >= 3 else (13.5 if title_line_count == 2 else 17.0)
        elif target_aspect_ratio == "4:3":
            effective_title_y_pct = 17.3 if title_line_count >= 3 else (19.3 if title_line_count == 2 else 23.6)
        elif target_aspect_ratio == "16:9":
            effective_title_y_pct = 22.6 if title_line_count >= 3 else (24.5 if title_line_count == 2 else 28.8)
        else:  # 9:16
            effective_title_y_pct = 12.0 if title_line_count >= 3 else (14.5 if title_line_count == 2 else 17.0)
        title_y = max(10, min(1800, int(round(1920 * (effective_title_y_pct / 100.0)))))

    # Subtitle Positioning:
    if is_landscape:
        if subtitle_position_mode == "center":
            sub_y = int(round(1080 * (subtitle_center_y_percent / 100.0)))
            sub_y = max(40, min(1040, sub_y))
        else:
            effective_sub_pct = float(subtitle_y_percent) if subtitle_y_percent is not None else 10.0
            sub_y = int(round(1080 * (1.0 - (effective_sub_pct / 100.0))))
            sub_y = max(40, min(1040, sub_y))
    elif subtitle_position_mode == "center":
        sub_y = int(round(1920 * (subtitle_center_y_percent / 100.0)))
        sub_y = max(content_top + 40, min(content_bot - 40, sub_y))
    else:
        # Bottom subtitle
        if subtitle_y_percent is not None:
            sub_y = int(round(1920 * (1.0 - (float(subtitle_y_percent) / 100.0))))
        else:
            if streamer_preset == "split_top_cam":
                default_sub_pct = 18.0 if (target_aspect_ratio in ["9:16", "1:1"]) else (10.0 if target_aspect_ratio == "4:3" else 18.0)
                sub_y = int(round(1920 * (1.0 - (default_sub_pct / 100.0))))
            else:
                default_sub_y = content_bot + est_sub_h + 12
                sub_y = default_sub_y

        if streamer_preset == "split_top_cam" or target_aspect_ratio == "9:16":
            sub_y = max(60, min(1880, sub_y))
        else:
            min_safe_sub_y = content_bot + est_sub_h + 8
            sub_y = max(sub_y, min_safe_sub_y)

    # Preset color schemes (ASS uses &HAABBGGRR in hex)
    if style_preset == "viral_pop":
        primary_color = "&H00FFFFFF"
        outline_color = "&H00000000"
        back_color = "&H80000000"
        highlight_color = "&H0000E6FF"  # #FFE600 Lemon Yellow
        outline_w = 4.8
        shadow_w = 2.0
    elif style_preset == "beast_punch":
        primary_color = "&H00FFFFFF"
        outline_color = "&H00111111"
        back_color = "&HA0000000"
        highlight_color = "&H0066FF00"  # #00FF66 High-voltage Neon Green
        outline_w = 5.0
        shadow_w = 2.2
    elif style_preset == "cyber_violet":
        primary_color = "&H00FFFFFF"
        outline_color = "&H00330033"
        back_color = "&H80500050"
        highlight_color = "&H00EF46D9"  # #D946EF Vivid Magenta
        outline_w = 4.8
        shadow_w = 2.0
    elif style_preset == "fire_red":
        primary_color = "&H00FFFFFF"
        outline_color = "&H00000020"
        back_color = "&H90000060"
        highlight_color = "&H002E2EFF"  # #FF2E2E Blazing Fire Red
        outline_w = 4.8
        shadow_w = 2.0
    elif style_preset == "electric_cyan":
        primary_color = "&H00FFFFFF"
        outline_color = "&H00102020"
        back_color = "&H90002030"
        highlight_color = "&H00FFF000"  # #00F0FF Electric Cyan
        outline_w = 4.8
        shadow_w = 2.0
    elif style_preset == "golden_aura":
        primary_color = "&H00FFFFFF"
        outline_color = "&H000a1220"
        back_color = "&HA0001830"
        highlight_color = "&H0000B8FF"  # #FFB800 Warm Gold
        outline_w = 4.8
        shadow_w = 2.0
    else:  # clean_minimal or none
        primary_color = "&H00FFFFFF"
        outline_color = "&H00111111"
        back_color = "&HB0000000"
        highlight_color = "&H00F8BD38"  # #38BDF8 Clean Minimal blue
        outline_w = 3.6
        shadow_w = 1.8

    # Title styling: clean transparent background across ALL formats (no black box border)
    title_box_back = "&H00000000"
    title_border_style = 1

    ass_header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {canvas_w}
PlayResY: {canvas_h}
ScaledBorderAndShadow: yes
WrapStyle: 2
Collisions: Reverse

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: TitleStyle,{title_font_name or font_name},{title_font_size},&H00FFFFFF,&H000000FF,&H00000000,{title_box_back},-1,0,0,0,100,100,0,0,{title_border_style},4.4,2.0,8,40,40,0,1
Style: SubStyle,{font_name},{sub_font_size},{primary_color},&H000000FF,{outline_color},{back_color},-1,0,0,0,100,100,0,0,1,{outline_w},{shadow_w},2,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    events = []

    # 3. Add Title Event with selectable visibility duration (5s, 10s, or entire clip)
    # If skip_title is True or title contains emojis, title is composited via PNG overlay with full color
    if formatted_title and title_position != "none" and not skip_title and not has_emoji(title_text):
        if title_duration == "5s":
            t_end_sec = min(5.0, duration_seconds)
        elif title_duration == "10s":
            t_end_sec = min(10.0, duration_seconds)
        else:
            t_end_sec = max(1.0, duration_seconds)

        end_time_str = format_ass_timestamp(t_end_sec)
        title_lines = [l.strip() for l in formatted_title.split("\\N") if l.strip()]
        base_ass_y = max(10, title_y - int(title_font_size * 0.15))
        for line_idx, t_line in enumerate(title_lines):
            line_y = base_ass_y + (line_idx * line_step)
            events.append(
                f"Dialogue: 1,0:00:00.00,{end_time_str},TitleStyle,,0,0,0,,{{\\q2\\an8\\pos({center_x},{line_y})}}{t_line}"
            )

    # 4. Add Subtitle Events if captions are enabled (guaranteed ZERO vertical glitch / jumping)
    if words and style_preset != "none":
        # Step A: Sanitize text and clamp every interval to the actual clip duration.
        valid_words = []
        bounded_words = _normalize_subtitle_word_times(words, duration_seconds, subtitle_offset_seconds)
        for w in bounded_words:
            raw_text = clean_caption_text(str(w.get("word", "")).strip())
            if not raw_text:
                continue
            w_text = escape_ass_text(apply_text_case(raw_text, text_case))
            valid_words.append({"word_text": w_text, "start": w["start"], "end": w["end"], "raw": w})

        # Step B: Pack into compact chunks (1 to 3 words, max 22 chars) to strictly guarantee 1 single line
        # Split on natural speech pauses (>= 0.38s) or sentence-ending punctuation so words don't hang over silences
        chunks = []
        current_chunk = []
        current_chars = 0
        for item in valid_words:
            w_len = len(item["word_text"])
            has_pause = bool(current_chunk and (item["start"] - current_chunk[-1]["end"] >= 0.38))
            ends_sentence = bool(current_chunk and any(current_chunk[-1]["word_text"].endswith(p) for p in [".", "?", "!"]))
            if len(current_chunk) >= 3 or has_pause or ends_sentence or (current_chunk and (current_chars + w_len > 22)):
                chunks.append(current_chunk)
                current_chunk = [item]
                current_chars = w_len
            else:
                current_chunk.append(item)
                current_chars += w_len + 1
        if current_chunk:
            chunks.append(current_chunk)

        # Step C: Enforce strictly non-overlapping, monotonically increasing chunk boundaries
        chunk_bounds = []
        try:
            clip_duration = float(duration_seconds)
        except (TypeError, ValueError, OverflowError):
            clip_duration = 60.0
        if not math.isfinite(clip_duration) or clip_duration <= 0:
            clip_duration = 60.0
        clip_duration = min(clip_duration, 24.0 * 60.0 * 60.0)
        for chunk in chunks:
            c_start = max(0.0, min(clip_duration, chunk[0]["start"]))
            c_end = min(clip_duration, max(c_start + min(0.35, clip_duration), chunk[-1]["end"] + 0.12))
            if chunk_bounds:
                prev_end = chunk_bounds[-1][1]
                if c_start < prev_end:
                    c_start = prev_end
                if c_end <= c_start:
                    c_end = min(clip_duration, c_start + 0.28)
            if c_end > c_start:
                chunk_bounds.append((c_start, c_end))
            else:
                chunk_bounds.append((c_start, c_start))

        # Clamp against subsequent chunk start times to eliminate any inter-chunk overlaps
        for i in range(len(chunk_bounds) - 1):
            cur_s, cur_e = chunk_bounds[i]
            nxt_s, nxt_e = chunk_bounds[i + 1]
            if cur_e > nxt_s:
                split_pt = max(cur_s + 0.28, nxt_s)
                chunk_bounds[i] = (cur_s, split_pt)
                if nxt_s < split_pt:
                    chunk_bounds[i + 1] = (split_pt, max(split_pt + 0.28, nxt_e))

        # Re-clamp after overlap repair: pushing a boundary forward must never
        # extend the final subtitle event beyond the clip's actual duration.
        bounded_chunk_bounds = []
        for c_start, c_end in chunk_bounds:
            c_start = max(0.0, min(clip_duration, c_start))
            c_end = max(c_start, min(clip_duration, c_end))
            bounded_chunk_bounds.append((c_start, c_end))
        chunk_bounds = bounded_chunk_bounds

        # Step D: Partition each chunk into strictly contiguous active-word time slices
        for chunk_idx, chunk in enumerate(chunks):
            c_start, c_end = chunk_bounds[chunk_idx]
            if c_end <= c_start:
                c_end = c_start + 0.25
            num_words = len(chunk)

            if num_words == 1:
                time_slices = [(c_start, c_end)]
            else:
                points = [c_start]
                for w_i in range(1, num_words):
                    raw_st = chunk[w_i]["start"]
                    # Enforce minimum 0.16s per word to eliminate micro-flickering while preserving acoustic sync
                    min_allowed = points[-1] + 0.16
                    max_allowed = c_end - 0.16 * (num_words - w_i)
                    if min_allowed > max_allowed:
                        pt = points[-1] + (c_end - points[-1]) / (num_words - w_i + 1)
                    else:
                        pt = max(min_allowed, min(max_allowed, raw_st))
                    points.append(pt)
                points.append(c_end)
                time_slices = [(points[k], points[k + 1]) for k in range(num_words)]

            for active_idx, (w_start, w_end) in enumerate(time_slices):
                if w_end <= w_start:
                    continue

                line_parts = []
                for idx, item in enumerate(chunk):
                    w_txt = item["word_text"]
                    if idx == active_idx:
                        # Highlight active word with color only (no font scale or bold toggle so metrics stay 100% identical)
                        line_parts.append(r"{\c" + highlight_color + r"\3c" + outline_color + r"}" + w_txt + r"{\c" + primary_color + r"\3c" + outline_color + r"}")
                    else:
                        line_parts.append(w_txt)

                styled_line = " ".join(line_parts)
                # Lock position to sub_y with \q2\an{sub_align}\pos(center_x, sub_y)
                events.append(
                    f"Dialogue: 0,{format_ass_timestamp(w_start)},{format_ass_timestamp(w_end)},SubStyle,,0,0,0,,{{\\q2\\an{sub_align}\\pos({center_x},{sub_y})}}{styled_line}"
                )

    ass_content = ass_header + "\n".join(events) + "\n"
    os.makedirs(os.path.dirname(os.path.abspath(output_ass_path)), exist_ok=True)
    with open(output_ass_path, "w", encoding="utf-8") as f:
        f.write(ass_content)

    return output_ass_path


def detect_image_saliency_center(frame) -> Tuple[float, float]:
    """
    Computes visual saliency center of mass for a non-facecam image frame.
    Finds the primary visual focal point / subject of attention.
    """
    try:
        import cv2
        import numpy as np
        small = cv2.resize(frame, (320, 180))
        saliency = cv2.saliency.StaticSaliencySpectralResidual_create()
        success, sal_map = saliency.computeSaliency(small)
        if success and sal_map is not None:
            thresh = np.percentile(sal_map, 80)
            filtered = np.where(sal_map >= thresh, sal_map, 0.0)
            stotal = filtered.sum()
            if stotal > 1e-4:
                norm = filtered / stotal
                y_idx, x_idx = np.indices(norm.shape)
                sal_cx = float((x_idx * norm).sum()) / 320.0
                sal_cy = float((y_idx * norm).sum()) / 180.0
                # Snap to center if close to middle
                if 0.44 <= sal_cx <= 0.56:
                    sal_cx = 0.50
                sal_cx = max(0.26, min(0.74, sal_cx))
                return sal_cx, sal_cy
    except Exception as e:
        logger.debug(f"Image saliency fallback: {e}")
    return 0.50, 0.35


def detect_video_saliency_and_motion_center(sampled_small_frames: List[Any]) -> Tuple[float, float]:
    """
    Computes combined visual saliency + inter-frame motion center for non-facecam videos
    (gameplay, tutorials, product unboxing, sports, animations, nature, etc.).
    Guarantees the camera tracks actual action/objects and never stares at an empty wall.
    """
    if not sampled_small_frames:
        return 0.50, 0.35

    try:
        import cv2
        import numpy as np
        saliency = cv2.saliency.StaticSaliencySpectralResidual_create()
        centers = []

        for i in range(len(sampled_small_frames)):
            small = sampled_small_frames[i]
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)

            # 1. Motion energy if consecutive frame exists
            motion_weight = 0.0
            motion_cx, motion_cy = 0.5, 0.5
            if i > 0:
                prev_gray = cv2.cvtColor(sampled_small_frames[i - 1], cv2.COLOR_BGR2GRAY)
                diff = cv2.absdiff(gray, prev_gray)
                _, m_thresh = cv2.threshold(diff, 20, 255, cv2.THRESH_BINARY)
                moments = cv2.moments(m_thresh)
                if moments["m00"] > 50:
                    motion_cx = (moments["m10"] / moments["m00"]) / 320.0
                    motion_cy = (moments["m01"] / moments["m00"]) / 180.0
                    motion_weight = min(2.0, float(moments["m00"]) / 2000.0)

            # 2. Static Visual Saliency
            success, sal_map = saliency.computeSaliency(small)
            sal_cx, sal_cy, sal_weight = 0.5, 0.5, 0.0
            if success and sal_map is not None:
                thresh = np.percentile(sal_map, 80)
                filtered = np.where(sal_map >= thresh, sal_map, 0.0)
                stotal = filtered.sum()
                if stotal > 1e-4:
                    norm = filtered / stotal
                    y_idx, x_idx = np.indices(norm.shape)
                    sal_cx = float((x_idx * norm).sum()) / 320.0
                    sal_cy = float((y_idx * norm).sum()) / 180.0
                    sal_weight = 1.0

            # Fuse motion & visual saliency
            if motion_weight > 0 and sal_weight > 0:
                fcx = (sal_cx * 1.0 + motion_cx * motion_weight) / (1.0 + motion_weight)
                fcy = (sal_cy * 1.0 + motion_cy * motion_weight) / (1.0 + motion_weight)
                wgt = 1.0 + motion_weight
            elif motion_weight > 0:
                fcx, fcy, wgt = motion_cx, motion_cy, motion_weight
            elif sal_weight > 0:
                fcx, fcy, wgt = sal_cx, sal_cy, sal_weight
            else:
                fcx, fcy, wgt = 0.5, 0.35, 0.1

            centers.append((fcx, fcy, wgt))

        if centers:
            total_w = sum(c[2] for c in centers)
            avg_cx = sum(c[0] * c[2] for c in centers) / total_w
            avg_cy = sum(c[1] * c[2] for c in centers) / total_w

            # Deadzone center snapping
            if 0.44 <= avg_cx <= 0.56:
                avg_cx = 0.50
            # Safe bounds clamp
            avg_cx = max(0.26, min(0.74, avg_cx))
            return avg_cx, avg_cy
    except Exception as e:
        logger.debug(f"Video saliency fallback: {e}")

    return 0.50, 0.35


def detect_speaker_face_box(
    source_path: str,
    facecam_position: str = "auto",
    streamer_preset: str = "none"
) -> Dict[str, Any]:
    """
    Detects speaker face or non-facecam salient action/object bounding box.
    Uses OpenCV YuNet Deep Neural Network + Saliency/Motion Object detection.
    Prevents false alarms on walls, backgrounds, and empty textures.
    Returns normalized coordinates:
    {
        "found": bool,
        "cx": float,  # horizontal center (0.0 to 1.0)
        "cy": float,  # vertical center (0.0 to 1.0)
        "w": float,   # face width ratio (0.0 to 1.0)
        "h": float    # face height ratio (0.0 to 1.0)
    }
    """
    pos = (facecam_position or "auto").lower().strip()
    if pos == "bottom_right":
        return {"found": True, "cx": 0.85, "cy": 0.78, "w": 0.22, "h": 0.25}
    elif pos == "top_right":
        return {"found": True, "cx": 0.85, "cy": 0.22, "w": 0.22, "h": 0.25}
    elif pos == "bottom_left":
        return {"found": True, "cx": 0.15, "cy": 0.78, "w": 0.22, "h": 0.25}
    elif pos == "top_left":
        return {"found": True, "cx": 0.15, "cy": 0.22, "w": 0.22, "h": 0.25}
    elif pos == "center":
        return {"found": True, "cx": 0.50, "cy": 0.35, "w": 0.25, "h": 0.25}
    elif pos == "left":
        return {"found": True, "cx": 0.35, "cy": 0.35, "w": 0.25, "h": 0.25}
    elif pos == "right":
        return {"found": True, "cx": 0.65, "cy": 0.35, "w": 0.25, "h": 0.25}

    is_streamer = streamer_preset in ["split_top_cam", "pip_corner"]
    default_cx = 0.85 if is_streamer else 0.50
    default_cy = 0.78 if is_streamer else 0.35
    default_res = {"found": False, "cx": default_cx, "cy": default_cy, "w": 0.22, "h": 0.25}

    if not source_path or not os.path.exists(source_path):
        return default_res

    try:
        import cv2

        # Check if source is image
        ext = os.path.splitext(source_path)[1].lower()
        is_image = ext in [".jpg", ".jpeg", ".png", ".webp", ".bmp"]

        # 1. Initialize YuNet Deep Neural Network detector if model file is available
        yunet_detector = None
        target_model = None
        for cand in [YUNET_MODEL_PATH, BASE_DIR / "face_detection_yunet.onnx", BASE_DIR / "cascades" / "face_detection_yunet.onnx"]:
            if cand.exists():
                target_model = cand
                break
        if target_model:
            try:
                yunet_detector = cv2.FaceDetectorYN.create(
                    str(target_model),
                    "",
                    (320, 320),
                    0.65,  # score_threshold: strict enough to reject walls and noise
                    0.3,   # nms_threshold
                    5000
                )
            except Exception as e:
                logger.warning(f"YuNet initialization failed: {e}")
                yunet_detector = None

        # 2. Prepare Haar Cascades fallback ensemble
        cascades = []
        cascade_names = [
            "haarcascade_frontalface_alt2.xml",
            "haarcascade_frontalface_alt.xml",
            "haarcascade_profileface.xml",
            "haarcascade_upperbody.xml",
            "haarcascade_frontalface_default.xml"
        ]
        opencv_data_dir = getattr(cv2, "data", None)
        haarcascades_dir = getattr(opencv_data_dir, "haarcascades", None) if opencv_data_dir else None

        for c_name in cascade_names:
            candidates = [
                CASCADES_DIR / c_name,
                BASE_DIR / c_name,
                os.path.join(haarcascades_dir, c_name) if haarcascades_dir else ""
            ]
            for p in candidates:
                if p and os.path.exists(str(p)):
                    try:
                        c = cv2.CascadeClassifier(str(p))
                        if not c.empty():
                            cascades.append(c)
                            break
                    except Exception:
                        pass

        # Helper: detect faces in a single frame
        def detect_frame_faces(frame) -> List[Dict[str, Any]]:
            fh, fw = frame.shape[:2]
            found_faces = []

            # Stage A: Deep Learning YuNet
            if yunet_detector is not None:
                try:
                    yunet_detector.setInputSize((fw, fh))
                    res = yunet_detector.detect(frame)
                    if res[1] is not None and len(res[1]) > 0:
                        for f in res[1]:
                            box = f[0:4]
                            conf = float(f[-1])
                            fcx = float(box[0] + box[2] / 2.0) / fw
                            fcy = float(box[1] + box[3] / 2.0) / fh
                            bw = float(box[2]) / fw
                            bh = float(box[3]) / fh
                            if bw >= 0.025 and bh >= 0.025:
                                found_faces.append({
                                    "cx": fcx, "cy": fcy, "w": bw, "h": bh,
                                    "conf": conf, "source": "yunet"
                                })
                        if found_faces:
                            return found_faces
                except Exception:
                    pass

            # Stage B: Haar Cascade Ensemble with strict false-positive suppression
            if cascades:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                min_sz = max(48, int(fh * 0.08))  # Minimum 8% of frame height (reject wall specks)
                for cascade in cascades:
                    haar_faces = cascade.detectMultiScale(
                        gray,
                        scaleFactor=1.1,
                        minNeighbors=6,
                        minSize=(min_sz, min_sz)
                    )
                    if len(haar_faces) > 0:
                        for (fx, fy, bw, bh) in haar_faces:
                            aspect = float(bw) / float(bh)
                            if 0.65 <= aspect <= 1.35:
                                fcx = float(fx + bw / 2.0) / fw
                                fcy = float(fy + bh / 2.0) / fh
                                found_faces.append({
                                    "cx": fcx, "cy": fcy,
                                    "w": float(bw) / fw, "h": float(bh) / fh,
                                    "conf": 0.70, "source": "haar"
                                })
                        if found_faces:
                            break

            return found_faces

        # Case 1: Image source
        if is_image:
            frame = cv2.imread(source_path)
            if frame is None:
                return default_res
            img_faces = detect_frame_faces(frame)
            if not img_faces:
                # Non-facecam image: detect salient focal point
                if not is_streamer:
                    sal_cx, sal_cy = detect_image_saliency_center(frame)
                    logger.info(f"Non-facecam image detected: smart visual saliency centered at ({sal_cx:.3f}, {sal_cy:.3f})")
                    return {
                        "found": True,
                        "type": "salient_object",
                        "cx": float(round(sal_cx, 3)),
                        "cy": float(round(sal_cy, 3)),
                        "w": 0.25,
                        "h": 0.25
                    }
                return default_res

            if is_streamer:
                corner_faces = [f for f in img_faces if ((f["cx"] - 0.5)**2 + (f["cy"] - 0.5)**2) > 0.06]
                chosen = max(corner_faces or img_faces, key=lambda f: f["w"] * f["h"])
            else:
                fg_faces = [f for f in img_faces if f["w"] >= 0.06 or abs(f["cx"] - 0.5) <= 0.28]
                if not fg_faces:
                    # Tiny corner webcam in image: center on non-facecam main content
                    sal_cx, sal_cy = detect_image_saliency_center(frame)
                    return {"found": True, "type": "salient_object", "cx": float(round(sal_cx, 3)), "cy": float(round(sal_cy, 3)), "w": 0.25, "h": 0.25}
                chosen = max(fg_faces, key=lambda f: (f["w"] * f["h"]) * (1.0 - 0.35 * abs(f["cx"] - 0.5)))

            final_cx = float(chosen["cx"])
            if not is_streamer:
                if 0.45 <= final_cx <= 0.55:
                    final_cx = 0.50
                final_cx = max(0.24, min(0.76, final_cx))

            return {
                "found": True,
                "cx": float(round(final_cx, 3)),
                "cy": float(round(chosen["cy"], 3)),
                "w": float(round(chosen["w"], 3)),
                "h": float(round(chosen["h"], 3))
            }

        # Case 2: Video source
        cap = cv2.VideoCapture(source_path)
        if not cap.isOpened():
            return default_res

        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        # Low-CPU keyframe sampling: 10 frames are sufficient for spatial clustering without loading server CPU
        step = max(1, total_frames // 10) if total_frames > 10 else max(1, int(fps * 1.5))

        detections = []
        sampled_small_frames = []
        frame_idx = 0
        checked = 0
        while cap.isOpened() and frame_idx < total_frames and checked < 10:
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            ret, frame = cap.read()
            frame_idx += step
            checked += 1
            if not ret or frame is None:
                continue
            sampled_small_frames.append(cv2.resize(frame, (320, 180)))
            f_faces = detect_frame_faces(frame)
            if f_faces:
                detections.extend(f_faces)

        cap.release()

        # If no face detections, run non-facecam visual saliency & motion object tracking!
        if not detections:
            if not is_streamer and sampled_small_frames:
                sal_cx, sal_cy = detect_video_saliency_and_motion_center(sampled_small_frames)
                logger.info(f"Non-facecam video detected: smart saliency/motion centered at ({sal_cx:.3f}, {sal_cy:.3f})")
                return {
                    "found": True,
                    "type": "salient_object",
                    "cx": float(round(sal_cx, 3)),
                    "cy": float(round(sal_cy, 3)),
                    "w": 0.25,
                    "h": 0.25
                }
            return default_res

        # Spatial clustering across sampled frames
        clusters = []
        for d in detections:
            matched = False
            for c in clusters:
                dist = ((c["cx"] - d["cx"])**2 + (c["cy"] - d["cy"])**2)**0.5
                if dist < 0.12:
                    c["pts"].append(d)
                    c["cx"] = sum(p["cx"] for p in c["pts"]) / len(c["pts"])
                    c["cy"] = sum(p["cy"] for p in c["pts"]) / len(c["pts"])
                    matched = True
                    break
            if not matched:
                clusters.append({"cx": d["cx"], "cy": d["cy"], "pts": [d]})

        # Temporal multi-frame persistence gating
        valid_clusters = [
            c for c in clusters
            if len(c["pts"]) >= 2 or (c["pts"][0]["conf"] >= 0.85 and c["pts"][0]["w"] >= 0.08)
        ]
        if not valid_clusters:
            # Low confidence / isolated noise blips -> fallback to saliency/motion
            if not is_streamer and sampled_small_frames:
                sal_cx, sal_cy = detect_video_saliency_and_motion_center(sampled_small_frames)
                logger.info(f"Non-facecam video (weak face noise): smart saliency/motion centered at ({sal_cx:.3f}, {sal_cy:.3f})")
                return {
                    "found": True,
                    "type": "salient_object",
                    "cx": float(round(sal_cx, 3)),
                    "cy": float(round(sal_cy, 3)),
                    "w": 0.25,
                    "h": 0.25
                }
            return default_res

        if is_streamer:
            corner_clusters = [c for c in valid_clusters if ((c["cx"] - 0.5)**2 + (c["cy"] - 0.5)**2) > 0.06]
            chosen = max(corner_clusters or valid_clusters, key=lambda c: len(c["pts"]))
        else:
            foreground_clusters = [
                c for c in valid_clusters
                if (sum(p["w"] for p in c["pts"]) / len(c["pts"])) >= 0.06 or abs(c["cx"] - 0.5) <= 0.28
            ]
            if not foreground_clusters:
                # All detections are corner webcams; in standard 9:16, analyze saliency/motion of main content
                if sampled_small_frames:
                    sal_cx, sal_cy = detect_video_saliency_and_motion_center(sampled_small_frames)
                    logger.info(f"Corner webcam with non-facecam main content: centered at ({sal_cx:.3f}, {sal_cy:.3f})")
                    return {
                        "found": True,
                        "type": "salient_object",
                        "cx": float(round(sal_cx, 3)),
                        "cy": float(round(sal_cy, 3)),
                        "w": 0.25,
                        "h": 0.25
                    }
                return {"found": True, "is_corner_cam": True, "cx": 0.50, "cy": 0.35, "w": 0.22, "h": 0.25}

            # Check for dual speakers on opposite sides (interviews, podcasts, co-hosts)
            left_speakers = [c for c in foreground_clusters if c["cx"] < 0.40 and len(c["pts"]) >= 3]
            right_speakers = [c for c in foreground_clusters if c["cx"] > 0.60 and len(c["pts"]) >= 3]
            if left_speakers and right_speakers:
                mid_cx = (max(left_speakers, key=lambda c: len(c["pts"]))["cx"] + max(right_speakers, key=lambda c: len(c["pts"]))["cx"]) / 2.0
                return {"found": True, "cx": float(round(mid_cx, 3)), "cy": 0.35, "w": 0.25, "h": 0.25, "dual_speakers": True}

            # Rank foreground candidates by: consistency * size * confidence * center prior
            def score_cluster(c):
                avg_w = sum(p["w"] for p in c["pts"]) / len(c["pts"])
                avg_conf = sum(p["conf"] for p in c["pts"]) / len(c["pts"])
                center_prior = 1.0 - 0.35 * abs(c["cx"] - 0.5)
                return len(c["pts"]) * (avg_w ** 0.5) * avg_conf * center_prior

            chosen = max(foreground_clusters, key=score_cluster)

        avg_w = sum(p["w"] for p in chosen["pts"]) / len(chosen["pts"])
        avg_h = sum(p["h"] for p in chosen["pts"]) / len(chosen["pts"])
        final_cx = float(chosen["cx"])

        if not is_streamer:
            # Snap to exact center if the host is already close to middle (eliminates micro-jitters)
            if 0.45 <= final_cx <= 0.55:
                final_cx = 0.50
            # Safe crop bounds: never push the crop into extreme edges/walls
            final_cx = max(0.24, min(0.76, final_cx))

        logger.info(
            f"Smart face tracking selected speaker: center=({final_cx:.3f}, {chosen['cy']:.3f}), "
            f"size=({avg_w:.3f}x{avg_h:.3f}) across {len(chosen['pts'])} frames"
        )
        return {
            "found": True,
            "cx": float(round(final_cx, 3)),
            "cy": float(round(chosen["cy"], 3)),
            "w": float(round(avg_w, 3)),
            "h": float(round(avg_h, 3))
        }
    except Exception as e:
        logger.warning(f"Face/object detection encountered error: {e}, safely falling back to center.")

    return default_res


def detect_speaker_center_ratio(video_path: str, facecam_position: str = "auto", streamer_preset: str = "none") -> float:
    """
    Detects speaker faces across sample frames and returns the smoothed horizontal center ratio (0.0 to 1.0).
    Defaults to 0.5 (center) if no face is detected.
    """
    box = detect_speaker_face_box(video_path, facecam_position=facecam_position, streamer_preset=streamer_preset)
    return float(box.get("cx", 0.5))


def build_ffmpeg_filtergraph(
    aspect_ratio: str,
    background_style: str,
    face_center_ratio: float = 0.5,
    streamer_preset: str = "none",
    title_text: Optional[str] = None,
    title_position: str = "auto",
    ass_subtitles_path: Optional[str] = None,
    face_box: Optional[Dict[str, Any]] = None,
    title_y_percent: Optional[float] = None,
    crop_x_percent: Optional[float] = None
) -> Tuple[str, str]:
    """
    Constructs the FFmpeg -filter_complex chain with proper aspect ratio center-cropping.
    Canvas is always 1080x1920 (9:16).
    """
    filters = []

    face_cx = float(face_box.get("cx", face_center_ratio)) if face_box else face_center_ratio
    face_cy = float(face_box.get("cy", 0.78 if streamer_preset in ["split_top_cam", "pip_corner"] else 0.35)) if face_box else 0.35

    # 1. Base Layout & Scaling
    if streamer_preset == "split_top_cam":
        if aspect_ratio == "16:9":
            # 16:9 split: top cam 1080x608 (16:9) tightly cropped around face, bottom feed 1080x608 (16:9)
            cam_h = "min(ih, max(240, ih*0.38))"
            cam_w = f"min(iw, ({cam_h})*16/9)"
            cam_x = f"max(0, min(iw-ow, iw*{face_cx:.3f}-ow/2))"
            cam_y = f"max(0, min(ih-oh, ih*{face_cy:.3f}-oh/2))"
            filters.append(
                f"[0:v]split=2[cam_raw][game_raw];"
                f"[cam_raw]crop='{cam_w}':'{cam_h}':'{cam_x}':'{cam_y}',scale=1080:608[cam_box];"
                f"[game_raw]crop='min(iw,ih*16/9)':'min(ih,iw*9/16)':'(iw-min(iw,ih*16/9))/2':'(ih-min(ih,iw*9/16))/2',scale=1080:608[game_box];"
                f"[cam_box][game_box]vstack=inputs=2[both_split]"
            )
            if background_style == "blurred":
                filters.append(
                    f"[0:v]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[bg_blurred][both_split]overlay=0:352[layout_base]"
                )
            else:
                filters.append(f"[both_split]pad=1080:1920:0:352:black[layout_base]")

        elif aspect_ratio == "1:1":
            # 1:1 split: top cam 960x960 (1:1) tightly cropped around face, bottom feed 960x960 (1:1)
            cam_h = "min(ih, max(280, ih*0.38))"
            cam_w = f"min(iw, {cam_h})"
            cam_x = f"max(0, min(iw-ow, iw*{face_cx:.3f}-ow/2))"
            cam_y = f"max(0, min(ih-oh, ih*{face_cy:.3f}-oh/2))"
            filters.append(
                f"[0:v]split=2[cam_raw][game_raw];"
                f"[cam_raw]crop='{cam_w}':'{cam_h}':'{cam_x}':'{cam_y}',scale=960:960[cam_box];"
                f"[game_raw]crop='min(iw,ih)':'min(iw,ih)':'(iw-min(iw,ih))/2':'(ih-min(ih,iw))/2',scale=960:960[game_box];"
                f"[cam_box][game_box]vstack=inputs=2[both_split]"
            )
            if background_style == "blurred":
                filters.append(
                    f"[0:v]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[bg_blurred][both_split]overlay=60:0[layout_base]"
                )
            else:
                filters.append(f"[both_split]pad=1080:1920:60:0:black[layout_base]")

        elif aspect_ratio == "4:3":
            # 4:3 split: top cam 1080x810 (4:3) tightly cropped around face, bottom feed 1080x810 (4:3)
            cam_h = "min(ih, max(280, ih*0.38))"
            cam_w = f"min(iw, ({cam_h})*4/3)"
            cam_x = f"max(0, min(iw-ow, iw*{face_cx:.3f}-ow/2))"
            cam_y = f"max(0, min(ih-oh, ih*{face_cy:.3f}-oh/2))"
            filters.append(
                f"[0:v]split=2[cam_raw][game_raw];"
                f"[cam_raw]crop='{cam_w}':'{cam_h}':'{cam_x}':'{cam_y}',scale=1080:810[cam_box];"
                f"[game_raw]crop='min(iw,ih*4/3)':'min(ih,iw*3/4)':'(iw-min(iw,ih*4/3))/2':'(ih-min(ih,iw*3/4))/2',scale=1080:810[game_box];"
                f"[cam_box][game_box]vstack=inputs=2[both_split]"
            )
            if background_style == "blurred":
                filters.append(
                    f"[0:v]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[bg_blurred][both_split]overlay=0:150[layout_base]"
                )
            else:
                filters.append(f"[both_split]pad=1080:1920:0:150:black[layout_base]")

        else:  # 9:16
            # 9:16 Split: full bleed 1080x1920 with crisp facecam on top and centered gameplay on bottom
            cam_h = "min(ih, max(280, ih*0.38))"
            cam_w = f"min(iw, ({cam_h})*4/3)"
            cam_x = f"max(0, min(iw-ow, iw*{face_cx:.3f}-ow/2))"
            cam_y = f"max(0, min(ih-oh, ih*{face_cy:.3f}-oh/2))"

            game_w = "min(iw, ih*1080/1110)"
            game_h = "ih"
            game_x = "(iw-ow)/2"
            game_y = "(ih-oh)/2"

            filters.append(
                f"[0:v]split=2[cam_raw][game_raw];"
                f"[cam_raw]crop='{cam_w}':'{cam_h}':'{cam_x}':'{cam_y}',scale=1080:810[cam_box];"
                f"[game_raw]crop='{game_w}':'{game_h}':'{game_x}':'{game_y}',scale=1080:1110[game_box];"
                f"[cam_box][game_box]vstack=inputs=2[layout_base]"
            )

        current_v = "[layout_base]"

    elif streamer_preset == "pip_corner":
        # PIP Box tightly cropped on face (320x240)
        pip_cam_h = "min(ih, max(220, ih*0.35))"
        pip_cam_w = f"min(iw, ({pip_cam_h})*4/3)"
        pip_cam_x = f"max(0, min(iw-ow, iw*{face_cx:.3f}-ow/2))"
        pip_cam_y = f"max(0, min(ih-oh, ih*{face_cy:.3f}-oh/2))"
        pip_crop = f"[pip_raw]crop='{pip_cam_w}':'{pip_cam_h}':'{pip_cam_x}':'{pip_cam_y}',scale=320:240[pip_box];"

        if aspect_ratio == "1:1":
            crop_main = "crop='min(iw,ih)':'min(iw,ih)':'(iw-min(iw,ih))/2':'(ih-min(iw,ih))/2',scale=1080:1080"
            pip_x, pip_y = 736, 444
            if background_style == "blurred":
                filters.append(
                    f"[0:v]split=3[bg_raw][main_raw][pip_raw];"
                    f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[main_raw]{crop_main}[fg_square];"
                    f"[bg_blurred][fg_square]overlay=0:420[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )
            else:
                filters.append(
                    f"[0:v]split=2[main_raw][pip_raw];"
                    f"[main_raw]{crop_main},pad=1080:1920:0:420:black[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )

        elif aspect_ratio == "4:3":
            crop_main = "crop='min(iw,ih*4/3)':'min(ih,iw*3/4)':'(iw-min(iw,ih*4/3))/2':'(ih-min(ih,iw*3/4))/2',scale=1080:810"
            pip_x, pip_y = 736, 579
            if background_style == "blurred":
                filters.append(
                    f"[0:v]split=3[bg_raw][main_raw][pip_raw];"
                    f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[main_raw]{crop_main}[fg_43];"
                    f"[bg_blurred][fg_43]overlay=0:555[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )
            else:
                filters.append(
                    f"[0:v]split=2[main_raw][pip_raw];"
                    f"[main_raw]{crop_main},pad=1080:1920:0:555:black[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )

        elif aspect_ratio == "16:9_landscape":
            crop_main = "crop='min(iw,ih*16/9)':'min(ih,iw*9/16)':'(iw-min(iw,ih*16/9))/2':'(ih-min(ih,iw*9/16))/2',scale=1920:1080"
            pip_x, pip_y = 1550, 780
            filters.append(
                f"[0:v]split=2[main_raw][pip_raw];"
                f"[main_raw]{crop_main}[main_base];"
                f"{pip_crop}"
                f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
            )

        elif aspect_ratio == "16:9":
            crop_main = "crop='min(iw,ih*16/9)':'min(ih,iw*9/16)':'(iw-min(iw,ih*16/9))/2':'(ih-min(ih,iw*9/16))/2',scale=1080:608"
            pip_x, pip_y = 736, 676
            if background_style == "blurred":
                filters.append(
                    f"[0:v]split=3[bg_raw][main_raw][pip_raw];"
                    f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                    f"[main_raw]{crop_main}[fg_169];"
                    f"[bg_blurred][fg_169]overlay=0:656[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )
            else:
                filters.append(
                    f"[0:v]split=2[main_raw][pip_raw];"
                    f"[main_raw]{crop_main},pad=1080:1920:0:656:black[main_base];"
                    f"{pip_crop}"
                    f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
                )

        else:  # 9:16
            if crop_x_percent is not None:
                crop_ratio_safe = max(0.0, min(1.0, float(crop_x_percent) / 100.0))
            else:
                safe_cx = float(face_cx)
                if 0.46 <= safe_cx <= 0.54:
                    safe_cx = 0.50
                safe_cx = max(0.22, min(0.78, safe_cx))
                crop_ratio_safe = max(0.0, min(1.0, (safe_cx - 0.158) / 0.684))
            pip_x, pip_y = 736, 120
            filters.append(
                f"[0:v]split=2[main_raw][pip_raw];"
                f"[main_raw]crop=ih*9/16:ih:(iw-ih*9/16)*{crop_ratio_safe:.3f}:0,scale=1080:1920[main_base];"
                f"{pip_crop}"
                f"[main_base][pip_box]overlay=x={pip_x}:y={pip_y}[layout_base]"
            )

        current_v = "[layout_base]"

    elif aspect_ratio == "9:16":
        # Full Bleed 9:16 with Face Tracking / Manual horizontal crop offset
        if crop_x_percent is not None:
            crop_ratio_safe = max(0.0, min(1.0, float(crop_x_percent) / 100.0))
        else:
            safe_cx = float(face_cx)
            if 0.46 <= safe_cx <= 0.54:
                safe_cx = 0.50
            safe_cx = max(0.22, min(0.78, safe_cx))
            crop_ratio_safe = max(0.0, min(1.0, (safe_cx - 0.158) / 0.684))
        filters.append(
            f"[0:v]crop=ih*9/16:ih:(iw-ih*9/16)*{crop_ratio_safe:.3f}:0,scale=1080:1920[layout_base]"
        )
        current_v = "[layout_base]"

    elif aspect_ratio == "1:1":
        # 1:1 Square (1080x1080) - Smart crop with speaker/object centering then scale to 1080x1080
        safe_cx = float(face_cx)
        if 0.46 <= safe_cx <= 0.54:
            safe_cx = 0.50
        safe_cx = max(0.15, min(0.85, safe_cx))
        crop_11 = f"crop='min(iw,ih)':'min(iw,ih)':'max(0,min(iw-ih,iw*{safe_cx:.3f}-ih/2))':'(ih-min(iw,ih))/2',scale=1080:1080"
        if background_style == "blurred":
            filters.append(
                f"[0:v]split=2[bg_raw][fg_raw];"
                f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                f"[fg_raw]{crop_11}[fg_square];"
                f"[bg_blurred][fg_square]overlay=0:420[layout_base]"
            )
        else:
            filters.append(
                f"[0:v]{crop_11},pad=1080:1920:0:420:black[layout_base]"
            )
        current_v = "[layout_base]"

    elif aspect_ratio == "4:3":
        # 4:3 Standard (1080x810) - Smart crop with speaker/object centering then scale to 1080x810
        safe_cx = float(face_cx)
        if 0.46 <= safe_cx <= 0.54:
            safe_cx = 0.50
        safe_cx = max(0.15, min(0.85, safe_cx))
        crop_43 = f"crop='min(iw,ih*4/3)':'min(ih,iw*3/4)':'max(0,min(iw-ih*4/3,iw*{safe_cx:.3f}-(ih*4/3)/2))':'(ih-min(ih,iw*3/4))/2',scale=1080:810"
        if background_style == "blurred":
            filters.append(
                f"[0:v]split=2[bg_raw][fg_raw];"
                f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                f"[fg_raw]{crop_43}[fg_43];"
                f"[bg_blurred][fg_43]overlay=0:555[layout_base]"
            )
        else:
            filters.append(
                f"[0:v]{crop_43},pad=1080:1920:0:555:black[layout_base]"
            )
        current_v = "[layout_base]"

    elif aspect_ratio == "16:9_landscape":
        # True 16:9 Landscape (1920x1080)
        safe_cx = float(face_cx)
        if 0.46 <= safe_cx <= 0.54:
            safe_cx = 0.50
        safe_cx = max(0.15, min(0.85, safe_cx))
        crop_169_land = f"crop='min(iw,ih*16/9)':'min(ih,iw*9/16)':'max(0,min(iw-ih*16/9,iw*{safe_cx:.3f}-(ih*16/9)/2))':'(ih-min(ih,iw*9/16))/2',scale=1920:1080"
        filters.append(
            f"[0:v]{crop_169_land}[layout_base]"
        )
        current_v = "[layout_base]"

    else:  # 16:9 Letterbox
        # 16:9 Letterbox (1080x608) - Smart crop with speaker/object centering for ultrawide sources
        safe_cx = float(face_cx)
        if 0.46 <= safe_cx <= 0.54:
            safe_cx = 0.50
        safe_cx = max(0.15, min(0.85, safe_cx))
        crop_169 = f"crop='min(iw,ih*16/9)':'min(ih,iw*9/16)':'max(0,min(iw-ih*16/9,iw*{safe_cx:.3f}-(ih*16/9)/2))':'(ih-min(ih,iw*9/16))/2',scale=1080:608"
        if background_style == "blurred":
            filters.append(
                f"[0:v]split=2[bg_raw][fg_raw];"
                f"[bg_raw]scale=360:640:force_original_aspect_ratio=increase,crop=360:640,boxblur=12:2,scale=1080:1920,eq=saturation=1.2:contrast=1.05[bg_blurred];"
                f"[fg_raw]{crop_169}[fg_169];"
                f"[bg_blurred][fg_169]overlay=0:656[layout_base]"
            )
        else:
            filters.append(
                f"[0:v]{crop_169},pad=1080:1920:0:656:black[layout_base]"
            )
        current_v = "[layout_base]"

    # 2. Subtitles & Title Burning via libass (.ass)
    # (If ass_subtitles_path is provided, it contains BOTH the title and subtitles rendered with exact matching fonts)
    if ass_subtitles_path and os.path.exists(ass_subtitles_path):
        raw_ass = str(Path(ass_subtitles_path).resolve()).replace("\\", "/")
        escaped_ass = raw_ass.replace(":", "\\:").replace("'", "'\\''")
        if FONTS_DIR.exists() and (any(FONTS_DIR.glob("*.ttf")) or any(FONTS_DIR.glob("*.otf")) or any(FONTS_DIR.glob("*.woff*"))):
            raw_fonts = str(FONTS_DIR.resolve()).replace("\\", "/")
            escaped_fonts = raw_fonts.replace("'", "'\\''").replace(":", "\\:")
            sub_filter = f"{current_v}subtitles=filename='{escaped_ass}':fontsdir='{escaped_fonts}'[v_final]"
        else:
            sub_filter = f"{current_v}subtitles=filename='{escaped_ass}'[v_final]"
        filters.append(sub_filter)
        current_v = "[v_final]"
    elif title_text and title_position != "none":
        # Fallback drawtext if no ASS was generated
        clean_title = title_text.replace("'", "").replace(":", "-").replace('"', "").strip()
        if title_y_percent is not None:
            canvas_h = 1080 if aspect_ratio == "16:9_landscape" else 1920
            y_pos = int(round(canvas_h * (float(title_y_percent) / 100.0)))
        elif streamer_preset == "split_top_cam":
            y_pos = int(round(1920 * 0.045))
        else:
            y_pos = 80 if aspect_ratio == "16:9_landscape" else (345 if aspect_ratio == "1:1" else (480 if aspect_ratio in ["4:3", "9:16"] else 581))
        box_style = "box=0"
        safe_font = get_ffmpeg_safe_font_path()
        font_arg = f":fontfile='{safe_font}'" if safe_font else ""
        title_filter = (
            f"{current_v}drawtext=text='{clean_title}'{font_arg}:fontsize=60:fontcolor=white:"
            f"x=(w-text_w)/2:y={y_pos}:borderw=2.5:bordercolor=black@0.8:{box_style}[v_with_title]"
        )
        filters.append(title_filter)
        current_v = "[v_with_title]"

    full_filter_str = ";".join(filters)
    return full_filter_str, current_v


def check_has_audio(video_path: str) -> bool:
    """Checks if the video file contains a readable audio stream."""
    try:
        cmd = [
            "ffprobe", "-v", "error",
            "-select_streams", "a",
            "-show_entries", "stream=codec_type",
            "-of", "csv=p=0",
            str(video_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=8)
        return bool(res.stdout and res.stdout.strip())
    except Exception:
        return True


def _run_ffmpeg_with_progress(cmd, timeout, progress_callback, duration):
    """Run FFmpeg and stream its real progress without blocking on stderr."""
    progress_cmd = list(cmd)
    output_index = len(progress_cmd) - 1
    progress_cmd[output_index:output_index] = [
        "-progress", "pipe:1", "-stats_period", "1", "-nostats"
    ]

    stderr_file = tempfile.TemporaryFile(mode="w+t")
    process = None
    messages = queue.Queue()
    metrics = {}

    try:
        process = subprocess.Popen(
            progress_cmd,
            stdout=subprocess.PIPE,
            stderr=stderr_file,
            text=True,
            bufsize=1
        )

        def read_stdout():
            try:
                for line in process.stdout:
                    messages.put(line.rstrip("\r\n"))
            finally:
                messages.put(None)

        reader = threading.Thread(target=read_stdout, daemon=True)
        reader.start()
        deadline = time.monotonic() + timeout
        stream_finished = False
        last_progress_at = time.monotonic()
        last_heartbeat_at = last_progress_at
        last_progress_payload = {
            "frame": 0, "fps": 0.0, "time": 0.0,
            "speed": "0x", "percent": 0.0, "status": "waiting"
        }

        while not stream_finished:
            if time.monotonic() >= deadline:
                process.kill()
                process.wait()
                raise subprocess.TimeoutExpired(progress_cmd, timeout)

            try:
                line = messages.get(timeout=0.5)
            except queue.Empty:
                if process.poll() is not None and not reader.is_alive():
                    break
                # FFmpeg's media-time percentage cannot advance while an HTTP
                # input is stalled. Send a heartbeat without faking progress.
                now = time.monotonic()
                if progress_callback and now - last_heartbeat_at >= 2.0:
                    wait_seconds = int(now - last_progress_at)
                    progress_callback({
                        **last_progress_payload,
                        "speed": f"Menunggu data jaringan ({wait_seconds} dtk)",
                        "status": "waiting",
                        "heartbeat": True,
                    })
                    last_heartbeat_at = now
                continue

            if line is None:
                stream_finished = True
                continue

            if "=" not in line:
                continue

            key, value = line.split("=", 1)
            metrics[key] = value

            if key == "progress" and progress_callback:
                try:
                    out_time = metrics.get("out_time", "00:00:00.000")
                    parts = out_time.split(":")
                    seconds = (
                        float(parts[-1])
                        + int(parts[-2]) * 60
                        + int(parts[-3]) * 3600
                    ) if len(parts) == 3 else 0.0

                    last_progress_payload = {
                        "frame": int(metrics.get("frame", 0) or 0),
                        "fps": float(metrics.get("fps", 0) or 0),
                        "time": seconds,
                        "speed": metrics.get("speed", "0x"),
                        "percent": min(100.0, max(0.0, seconds / max(duration, 0.1) * 100)),
                        "status": value,
                    }
                    last_progress_at = time.monotonic()
                    last_heartbeat_at = last_progress_at
                    progress_callback(last_progress_payload)
                except Exception:
                    logger.debug("Could not publish FFmpeg progress", exc_info=True)

        returncode = process.wait()
        stderr_file.seek(0)
        stderr_text = stderr_file.read()
        return subprocess.CompletedProcess(
            progress_cmd, returncode, stdout="", stderr=stderr_text
        )
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        stderr_file.close()


def render_clip_to_mp4(
    video_path: str,
    output_mp4_path: str,
    aspect_ratio: str = "9:16",
    background_style: str = "black",
    enable_face_tracking: bool = True,
    streamer_preset: str = "none",
    facecam_position: str = "auto",
    title_text: Optional[str] = None,
    title_position: str = "auto",
    ass_subtitles_path: Optional[str] = None,
    clip_duration: float = 30.0,
    # Title Overlay (for full-color emojis and styling)
    title_overlay_path: Optional[str] = None,
    title_duration: str = "entire",
    # Watermark options
    watermark_enabled: bool = False,
    watermark_type: str = "image",
    watermark_image_path: Optional[str] = None,
    watermark_text: Optional[str] = None,
    watermark_size: float = 20.0,
    watermark_opacity: float = 0.8,
    watermark_x_percent: float = 90.0,
    watermark_y_percent: float = 8.0,
    # Background Music options
    bgm_enabled: bool = False,
    bgm_path: Optional[str] = None,
    bgm_volume: float = 0.25,
    bgm_start_offset: float = 0.0,
    # Hook SFX options (plays at frame 0)
    hook_sfx_enabled: bool = False,
    hook_sfx_path: Optional[str] = None,
    hook_sfx_volume: float = 1.0,
    # Raw voice / original audio boost (0.0 to 2.0)
    original_audio_volume: float = 1.0,
    # Hardware acceleration selection ('auto', 'nvenc', 'amf', 'qsv', 'cpu')
    hardware_accel: Optional[str] = "auto",
    title_y_percent: Optional[float] = None,
    crop_x_percent: Optional[float] = None,
    title_x_percent: Optional[float] = 50.0,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None
) -> str:
    """
    Renders the final 1080x1920 short-form video with layout, aspect ratio, titles, subtitles,
    watermark branding, background music with start offset, and hook sound effect at frame 0.
    """
    if not os.path.exists(video_path) or os.path.getsize(video_path) < 1000:
        raise RuntimeError(f"Input video file is missing or empty: {video_path}")

    if not is_valid_mp4(video_path):
        raise RuntimeError(
            "Source video segment is incomplete or corrupted ('moov atom not found'). "
            "This usually happens when internet lags during download. Please retry rendering this clip."
        )

    # Normalize watermark controls at the renderer boundary, not only in the UI.
    # Center-anchor coordinates outside 0..100 can put the mark off-screen.
    def _finite_clamp(value: Any, default: float, low: float, high: float) -> float:
        try:
            parsed = float(value)
        except (TypeError, ValueError, OverflowError):
            return default
        if not math.isfinite(parsed):
            return default
        return max(low, min(high, parsed))

    watermark_size = _finite_clamp(watermark_size, 20.0, 0.0, 500.0)
    watermark_opacity = _finite_clamp(watermark_opacity, 0.8, 0.0, 1.0)
    watermark_x_percent = _finite_clamp(watermark_x_percent, 90.0, 0.0, 100.0)
    watermark_y_percent = _finite_clamp(watermark_y_percent, 8.0, 0.0, 100.0)

    if ass_subtitles_path and os.path.exists(ass_subtitles_path):
        ffmpeg_path = shutil.which("ffmpeg")
        if not ffmpeg_path or not _ffmpeg_has_filter(ffmpeg_path, "subtitles"):
            raise RuntimeError(
                "Subtitle rendering requires an FFmpeg build with libass (the 'subtitles' filter). "
                "On macOS, install it with 'brew install ffmpeg-full' and restart the backend."
            )

    is_streamer = streamer_preset in ["pip_corner", "split_top_cam"]
    default_cx = 0.85 if is_streamer else 0.50
    default_cy = 0.78 if is_streamer else 0.35
    face_box = {"found": False, "cx": default_cx, "cy": default_cy, "w": 0.22, "h": 0.25}
    if crop_x_percent is not None:
        face_box = {"found": True, "cx": max(0.05, min(0.95, float(crop_x_percent) / 100.0)), "cy": default_cy, "w": 0.22, "h": 0.25}
    elif enable_face_tracking or is_streamer:
        face_box = detect_speaker_face_box(
            video_path,
            facecam_position=facecam_position,
            streamer_preset=streamer_preset
        )

    filter_complex, out_video_map = build_ffmpeg_filtergraph(
        aspect_ratio=aspect_ratio,
        background_style=background_style,
        face_center_ratio=float(face_box.get("cx", 0.5)),
        streamer_preset=streamer_preset,
        title_text=title_text if not (title_overlay_path and os.path.exists(title_overlay_path)) else None,
        title_position=title_position,
        ass_subtitles_path=ass_subtitles_path,
        face_box=face_box,
        title_y_percent=title_y_percent,
        crop_x_percent=crop_x_percent
    )

    filter_chains = [filter_complex]
    extra_input_args = []
    input_idx_counter = 1
    dur = max(1.0, float(clip_duration))

    # 1. Apply Title Overlay (Full-Color Emojis & Titles)
    if title_overlay_path and os.path.exists(title_overlay_path):
        t_idx = input_idx_counter
        input_idx_counter += 1
        extra_input_args.extend(["-i", str(title_overlay_path)])

        if title_duration == "5s":
            t_end_sec = min(5.0, dur)
            enable_expr = f":enable='between(t,0,{t_end_sec:.2f})'"
        elif title_duration == "10s":
            t_end_sec = min(10.0, dur)
            enable_expr = f":enable='between(t,0,{t_end_sec:.2f})'"
        else:
            enable_expr = ""

        overlay_title_cmd = f"{out_video_map}[{t_idx}:v]overlay=0:0{enable_expr}[v_with_title_overlay]"
        filter_chains.append(overlay_title_cmd)
        out_video_map = "[v_with_title_overlay]"

    # 2. Apply Watermark Overlay
    if watermark_enabled and float(watermark_size) > 0:
        wm_opacity = watermark_opacity
        wm_x_ratio = watermark_x_percent / 100.0
        wm_y_ratio = watermark_y_percent / 100.0

        if watermark_type == "image" and watermark_image_path and os.path.exists(watermark_image_path):
            wm_idx = input_idx_counter
            input_idx_counter += 1
            extra_input_args.extend(["-i", str(watermark_image_path)])

            # Canvas width is 1920 for landscape or 1080 for vertical. Calculate watermark width based on percentage (0-500%)
            canvas_w = 1920 if aspect_ratio == "16:9_landscape" else 1080
            wm_w = max(16, min(5400, int(canvas_w * (float(watermark_size) / 100.0))))
            wm_prep = f"[{wm_idx}:v]format=rgba,colorchannelmixer=aa={wm_opacity:.2f},scale={wm_w}:-1[wm_proc]"
            filter_chains.append(wm_prep)

            # Center-based positioning: (X%, Y%) represents the center anchor point on the canvas.
            # This ensures full 100% travel range across the canvas regardless of watermark size.
            overlay_cmd = (
                f"{out_video_map}[wm_proc]overlay="
                f"x='main_w*{wm_x_ratio:.4f}-overlay_w/2':"
                f"y='main_h*{wm_y_ratio:.4f}-overlay_h/2':eval=init[v_watermarked]"
            )
            filter_chains.append(overlay_cmd)
            out_video_map = "[v_watermarked]"

        elif watermark_text and watermark_text.strip():
            # Render text watermark to a transparent PNG overlay using Pillow
            # This completely avoids FFmpeg Fontconfig bugs on Windows while adding emoji & anti-aliasing support
            wm_font_size = max(14, min(900, int(180 * (float(watermark_size) / 100.0))))
            wm_png_filename = f"wm_text_{int(time.time() * 1000)}.png"
            wm_png_path = TEMP_DIR / wm_png_filename
            rendered_wm = render_text_watermark_png(
                text=watermark_text.strip(),
                output_png_path=str(wm_png_path),
                font_name="Montserrat",
                font_size=wm_font_size,
                border_width=max(2, int(wm_font_size * 0.055))
            )

            if rendered_wm and os.path.exists(rendered_wm):
                wm_idx = input_idx_counter
                input_idx_counter += 1
                extra_input_args.extend(["-i", str(rendered_wm)])

                wm_prep = f"[{wm_idx}:v]format=rgba,colorchannelmixer=aa={wm_opacity:.2f}[wm_proc]"
                filter_chains.append(wm_prep)

                overlay_cmd = (
                    f"{out_video_map}[wm_proc]overlay="
                    f"x='main_w*{wm_x_ratio:.4f}-overlay_w/2':"
                    f"y='main_h*{wm_y_ratio:.4f}-overlay_h/2':eval=init[v_watermarked]"
                )
                filter_chains.append(overlay_cmd)
                out_video_map = "[v_watermarked]"
            else:
                # Fallback to drawtext with explicit fontfile (never relies on Fontconfig)
                safe_font = get_ffmpeg_safe_font_path()
                font_arg = f":fontfile='{safe_font}'" if safe_font else ""
                clean_text = watermark_text.replace("'", "").replace(":", "\\:").replace("%", "").strip()
                overlay_x_expr = f"w*{wm_x_ratio:.4f}-text_w/2"
                overlay_y_expr = f"h*{wm_y_ratio:.4f}-text_h/2"
                drawtext_cmd = (
                    f"{out_video_map}drawtext=text='{clean_text}'{font_arg}:fontsize={wm_font_size}:"
                    f"fontcolor=white@{wm_opacity:.2f}:borderw=2:bordercolor=black@{wm_opacity:.2f}:"
                    f"x='{overlay_x_expr}':y='{overlay_y_expr}'[v_watermarked]"
                )
                filter_chains.append(drawtext_cmd)
                out_video_map = "[v_watermarked]"

    # 2. Audio Processing (keep the audio timeline aligned to the rendered video).
    # Pad short sources with silence and trim every source to the target duration.
    # Without this, amix=duration=first (or -shortest on a lone SFX/BGM) can
    # truncate an otherwise valid video when an audio track ends early.
    audio_inputs_to_mix = []
    dur = max(1.0, float(clip_duration))
    duration_arg = f"{dur:.3f}"

    has_orig_audio = check_has_audio(video_path)
    if has_orig_audio:
        orig_vol = max(0.0, min(2.0, float(original_audio_volume)))
        filter_chains.append(
            f"[0:a:0]asetpts=PTS-STARTPTS,volume={orig_vol:.3f},"
            f"apad=whole_dur={duration_arg},atrim=duration={duration_arg}[orig_proc]"
        )
        audio_inputs_to_mix.append("[orig_proc]")

    # BGM input with start offset & looping
    if bgm_enabled and bgm_path and os.path.exists(bgm_path):
        bgm_idx = input_idx_counter
        input_idx_counter += 1
        offset_sec = max(0.0, float(bgm_start_offset))
        if offset_sec > 0.0:
            extra_input_args.extend(["-ss", f"{offset_sec:.2f}"])
        extra_input_args.extend(["-stream_loop", "-1", "-i", str(bgm_path)])

        vol = max(0.0, min(1.0, float(bgm_volume)))
        fade_st = max(0.0, dur - 1.5)
        filter_chains.append(
            f"[{bgm_idx}:a]asetpts=PTS-STARTPTS,volume={vol:.3f},"
            f"afade=t=out:st={fade_st:.2f}:d=1.5,"
            f"apad=whole_dur={duration_arg},atrim=duration={duration_arg}[bgm_proc]"
        )
        audio_inputs_to_mix.append("[bgm_proc]")

    # Hook SFX input placed at the very first frame (t=0)
    if hook_sfx_enabled and hook_sfx_path and os.path.exists(hook_sfx_path):
        sfx_idx = input_idx_counter
        input_idx_counter += 1
        extra_input_args.extend(["-i", str(hook_sfx_path)])

        sfx_vol = max(0.0, min(2.0, float(hook_sfx_volume)))
        filter_chains.append(
            f"[{sfx_idx}:a]asetpts=PTS-STARTPTS,volume={sfx_vol:.3f},"
            f"apad=whole_dur={duration_arg},atrim=duration={duration_arg}[sfx_proc]"
        )
        audio_inputs_to_mix.append("[sfx_proc]")

    # All present sources now have the same bounded duration, so mixing is
    # deterministic and a short source cannot shorten the finished video.
    if len(audio_inputs_to_mix) > 1:
        mix_inputs_str = "".join(audio_inputs_to_mix)
        filter_chains.append(
            f"{mix_inputs_str}amix=inputs={len(audio_inputs_to_mix)}:duration=longest:"
            f"dropout_transition=2:normalize=0,atrim=duration={duration_arg}[a_final]"
        )
        out_audio_map = "[a_final]"
    elif len(audio_inputs_to_mix) == 1:
        filter_chains.append(
            f"{audio_inputs_to_mix[0]}anull[a_final]"
        )
        out_audio_map = "[a_final]"
    else:
        out_audio_map = "0:a:0?"

    final_filter_complex = ";".join(filter_chains)

    # Video encoder (resolved from user choice: auto, nvenc, amf, qsv, cpu)
    chosen_encoder_name, chosen_encoder_args = resolve_encoder(hardware_accel)
    v_codec_args = chosen_encoder_args

    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-i", str(video_path),
        *extra_input_args,
        "-filter_complex", final_filter_complex,
        "-map", out_video_map,
        "-map", out_audio_map,
        *v_codec_args,
        "-c:a", "aac", "-b:a", "192k",
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        "-shortest",
        str(output_mp4_path)
    ]

    # Check if FFmpeg is installed and accessible
    if not shutil.which("ffmpeg"):
        raise RuntimeError("FFmpeg is not installed or not found in system PATH. Please install FFmpeg (e.g. 'winget install Gyan.FFmpeg') and restart your terminal.")

    dur = max(1.0, float(clip_duration))
    # Dynamic timeouts scaled to clip duration (e.g. 60s -> 600s / 10m, 120s -> 1080s / 18m, 180s -> 1560s / 26m)
    render_timeout = max(360, min(2400, int(dur * 8) + 120))
    cpu_render_timeout = max(480, min(3000, int(dur * 12) + 180))

    logger.info(f"Rendering final vertical clip to {output_mp4_path} with {chosen_encoder_name} (Duration: {dur:.1f}s, Timeout: {render_timeout}s, Selection: {hardware_accel}, BGM: {bgm_enabled}, Watermark: {watermark_enabled})...")

    res = None
    try:
        if progress_callback:
            res = _run_ffmpeg_with_progress(cmd, render_timeout, progress_callback, dur)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=render_timeout)
    except subprocess.TimeoutExpired:
        logger.warning(f"Hardware encoder ({chosen_encoder_name}) timed out after {render_timeout}s.")
        res = None

    # Some hardware encoders can exit successfully but still leave an unusable
    # container (driver/device quirks). Validate the produced MP4 before accepting
    # the fast path so the existing libx264 fallback can recover automatically.
    if (
        res is not None
        and res.returncode == 0
        and (
            not os.path.exists(output_mp4_path)
            or not is_valid_mp4(output_mp4_path)
        )
    ):
        logger.warning(
            "Encoder %s returned success but produced an invalid MP4; "
            "triggering the safe CPU fallback.",
            chosen_encoder_name,
        )
        try:
            if os.path.exists(output_mp4_path):
                os.unlink(output_mp4_path)
        except OSError:
            pass
        res = subprocess.CompletedProcess(
            args=cmd,
            returncode=1,
            stdout="",
            stderr="Encoder exited successfully but output MP4 failed validation.",
        )

    if res is None or res.returncode != 0:
        err_msg_initial = res.stderr[:250] if (res and res.stderr) else f"Timed out after {render_timeout}s"
        logger.warning(f"Hardware encoder ({chosen_encoder_name}) failed or timed out: {err_msg_initial}")
        # Automatic fallback to universal CPU encoding (libx264) if chosen hardware encoder fails
        if chosen_encoder_name != "libx264":
            logger.info(f"Retrying render with universal multi-threaded CPU encoder (libx264, timeout: {cpu_render_timeout}s)...")
            cpu_cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-i", str(video_path),
                *extra_input_args,
                "-filter_complex", final_filter_complex,
                "-map", out_video_map,
                "-map", out_audio_map,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-threads", "2",
                "-c:a", "aac", "-b:a", "192k",
                "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                "-shortest",
                str(output_mp4_path)
            ]
            res_cpu = None
            try:
                if progress_callback:
                    res_cpu = _run_ffmpeg_with_progress(cpu_cmd, cpu_render_timeout, progress_callback, dur)
                else:
                    res_cpu = subprocess.run(cpu_cmd, capture_output=True, text=True, timeout=cpu_render_timeout)
            except subprocess.TimeoutExpired:
                logger.error(f"FFmpeg CPU fallback timed out after {cpu_render_timeout}s.")
                if os.path.exists(output_mp4_path):
                    try:
                        os.unlink(output_mp4_path)
                    except Exception:
                        pass
                raise RuntimeError(f"FFmpeg rendering timed out after {cpu_render_timeout}s for clip of duration {dur:.1f}s.")

            if res_cpu.returncode == 0 and os.path.exists(output_mp4_path) and is_valid_mp4(output_mp4_path):
                logger.info(f"Successfully rendered with CPU fallback: {output_mp4_path}")
                return str(output_mp4_path)
            else:
                if os.path.exists(output_mp4_path):
                    try:
                        os.unlink(output_mp4_path)
                    except Exception:
                        pass
                err_text = res_cpu.stderr if (res_cpu and res_cpu.stderr) else (res.stderr if (res and res.stderr) else "Unknown FFmpeg error")
                if "moov atom not found" in err_text.lower():
                    raise RuntimeError("FFmpeg rendering failed: Source video segment is incomplete ('moov atom not found'). Please retry rendering this clip.")
                logger.error(f"FFmpeg CPU fallback also failed: {err_text}")
                raise RuntimeError(f"FFmpeg rendering failed: {err_text}")
        else:
            if os.path.exists(output_mp4_path):
                try:
                    os.unlink(output_mp4_path)
                except Exception:
                    pass
            if res is None:
                raise RuntimeError(f"FFmpeg rendering timed out after {render_timeout}s for clip of duration {dur:.1f}s.")
            err_text = res.stderr or "Unknown FFmpeg error"
            if "moov atom not found" in err_text.lower():
                raise RuntimeError("FFmpeg rendering failed: Source video segment is incomplete ('moov atom not found'). Please retry rendering this clip.")
            logger.error(f"FFmpeg render error: {err_text}")
            raise RuntimeError(f"FFmpeg rendering failed: {err_text}")

    return str(output_mp4_path)


def extract_clip_frame(
    video_url: str,
    video_id: str,
    timestamp: float = 0.0,
    cookies_content: Optional[str] = None,
    allow_thumbnail_fallback: bool = True,
    allow_existing_frame_fallback: bool = True,
) -> Optional[str]:
    """
    Extract a JPEG frame at a timestamp.
    Set allow_thumbnail_fallback=False and allow_existing_frame_fallback=False
    when the image is being used as evidence for video analysis.
    """
    frames_dir = TEMP_DIR / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    safe_id = re.sub(r'[^a-zA-Z0-9_-]', '_', video_id)
    strict_evidence = not allow_thumbnail_fallback and not allow_existing_frame_fallback

    # Strict visual evidence must honor timestamps, including the first second.
    # Preserve the legacy minimum timestamp for ordinary extraction.
    if strict_evidence:
        target_ts = max(0.0, timestamp)
    else:
        target_ts = max(1.0, timestamp if timestamp > 0 else 5.0)

    sec = int(round(target_ts))
    frame_path = frames_dir / f"{safe_id}_{sec}.jpg"

    if strict_evidence:
        # Never reuse a cached frame as fresh visual evidence.
        try:
            frame_path.unlink(missing_ok=True)
        except OSError as e:
            logger.warning(f"Could not clear cached evidence frame {frame_path}: {e}")
    elif frame_path.exists() and frame_path.stat().st_size > 2000:
        return str(frame_path)

    # 0. Check if this is an uploaded or gdrive local video in UPLOADS_DIR or specified by video_url
    local_source = None
    clean_vurl = urllib.parse.unquote(video_url.strip()) if video_url else ""
    clean_vbase = os.path.basename(clean_vurl.split("?")[0]) if clean_vurl else ""

    if clean_vurl and os.path.exists(clean_vurl):
        local_source = Path(clean_vurl)
    elif video_url and os.path.exists(video_url):
        local_source = Path(video_url)
    elif clean_vurl and clean_vurl.startswith("/api/video/") and (UPLOADS_DIR / clean_vbase).exists():
        local_source = UPLOADS_DIR / clean_vbase
    elif clean_vbase and (UPLOADS_DIR / clean_vbase).exists():
        local_source = UPLOADS_DIR / clean_vbase
    elif (UPLOADS_DIR / f"{safe_id}.mp4").exists():
        local_source = UPLOADS_DIR / f"{safe_id}.mp4"
    else:
        for q in [clean_vbase, safe_id, video_id, video_id.replace("gdrive_", "").replace("upload_", "")]:
            if not q or len(q) < 3:
                continue
            for candidate in UPLOADS_DIR.glob(f"*{q}*"):
                if candidate.is_file() and is_valid_mp4(candidate) and "_clip_" not in candidate.name:
                    local_source = candidate
                    break
            if local_source:
                break

    if local_source and local_source.exists():
        cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-ss", str(target_ts),
            "-i", str(local_source),
            "-vframes", "1",
            "-q:v", "2",
            "-strict", "-1",
            str(frame_path)
        ]
        subprocess.run(cmd, capture_output=True, timeout=10)
        if frame_path.exists() and frame_path.stat().st_size > 500:
            return str(frame_path)

    # 1. Check local sliced clips or exports
    local_candidates = (
        list(TEMP_DIR.glob(f"*{safe_id}*.mp4")) + list(EXPORTS_DIR.glob(f"*{safe_id}*.mp4"))
        if allow_existing_frame_fallback else []
    )
    for candidate in local_candidates:
        if candidate.exists() and candidate.stat().st_size > 10000 and "slice_" not in candidate.name and is_valid_mp4(candidate):
            cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-ss", "00:00:01.00",
                "-i", str(candidate),
                "-vframes", "1",
                "-strict", "-1",
                str(frame_path)
            ]
            subprocess.run(cmd, capture_output=True, timeout=10)
            if frame_path.exists() and frame_path.stat().st_size > 2000:
                return str(frame_path)

    # 2. Extract a tiny 1-second slice of format 18 (fast 360p mp4) using yt-dlp + ffmpeg
    try:
        if video_url and is_twitch_url(video_url):
            tw_info = extract_twitch_info(video_url)
            clean_url = get_twitch_canonical_url(tw_info) if tw_info else video_url.strip()
        elif is_twitch_url(video_id):
            tw_info = extract_twitch_info(video_id)
            clean_url = get_twitch_canonical_url(tw_info) if tw_info else video_id
        else:
            clean_url = video_url.strip() if video_url else f"https://www.youtube.com/watch?v={video_id}"
        with ephemeral_cookies_file(cookies_content) as temp_cookies:
            base_cmd = get_yt_dlp_base_cmd(include_cookies=True, cookies_path=temp_cookies)
            temp_slice = frames_dir / f"slice_{safe_id}_{sec}.mp4"

            t_start = target_ts
            t_end = target_ts + 1.0
            t_start_fmt = format_section_time(t_start)
            t_end_fmt = format_section_time(t_end)

            slice_cmd = [
                *base_cmd,
                "-f", "18/best[height<=720]/best",
                "--download-sections", f"*{t_start_fmt}-{t_end_fmt}",
                "-o", str(temp_slice),
                "--no-warnings",
                clean_url
            ]
            subprocess.run(slice_cmd, capture_output=True, text=True, timeout=75)
        if temp_slice.exists() and temp_slice.stat().st_size > 1000:
            ff_cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-ss", "00:00:00.20",
                "-i", str(temp_slice),
                "-vframes", "1",
                "-strict", "-1",
                str(frame_path)
            ]
            subprocess.run(ff_cmd, capture_output=True, timeout=5)
            try:
                temp_slice.unlink()
            except Exception:
                pass

        if frame_path.exists() and frame_path.stat().st_size > 2000:
            return str(frame_path)
    except Exception as e:
        logger.warning(f"Slice frame extraction failed for {video_id}: {e}")

    # 3. Check any existing frame for this video in frames_dir as fallback
    if allow_existing_frame_fallback:
        existing_frames = list(frames_dir.glob(f"{safe_id}_*.jpg"))
        if existing_frames:
            return str(existing_frames[0])

    # 4. Instant high-res thumbnail fallback (disabled for evidence-based analysis)
    if allow_thumbnail_fallback:
        try:
            for thumb_url in [
                f"https://i.ytimg.com/vi/{video_id}/maxresdefault.jpg",
                f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
            ]:
                try:
                    req = urllib.request.Request(thumb_url, headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=3) as resp, open(frame_path, "wb") as f_out:
                        f_out.write(resp.read())
                    if frame_path.exists() and frame_path.stat().st_size > 2000:
                        return str(frame_path)
                except Exception:
                    continue
        except Exception as e:
            logger.warning(f"Thumbnail fallback failed for {video_id}: {e}")

    return None
