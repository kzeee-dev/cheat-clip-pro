#!/usr/bin/env bash
set -euo pipefail

if ! command -v ffmpeg >/dev/null 2>&1 || ! command -v ffprobe >/dev/null 2>&1; then
  echo "SKIP: ffmpeg and ffprobe are required for this integration check" >&2
  exit 2
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

# Two-second video with deliberately short original audio.
ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i 'testsrc2=size=320x240:rate=25:duration=2' \
  -f lavfi -i 'sine=frequency=440:sample_rate=48000:duration=0.4' \
  -map 0:v:0 -map 1:a:0 -c:v libx264 -pix_fmt yuv420p -c:a aac \
  "$TMP_DIR/source.mp4"

ffmpeg -hide_banner -loglevel error -y -i "$TMP_DIR/source.mp4" \
  -filter_complex '[0:a:0]asetpts=PTS-STARTPTS,volume=1.000,apad=whole_dur=2.000,atrim=duration=2.000[orig_proc]' \
  -map 0:v:0 -map '[orig_proc]' -c:v copy -c:a aac -shortest \
  "$TMP_DIR/original_padded.mp4"

# A short standalone SFX must not make -shortest truncate the video either.
ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i 'testsrc2=size=320x240:rate=25:duration=2' \
  -f lavfi -i 'sine=frequency=880:sample_rate=48000:duration=0.25' \
  -filter_complex '[1:a]asetpts=PTS-STARTPTS,volume=1.000,apad=whole_dur=2.000,atrim=duration=2.000[sfx_proc]' \
  -map 0:v:0 -map '[sfx_proc]' -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest \
  "$TMP_DIR/sfx_padded.mp4"

for output in "$TMP_DIR/original_padded.mp4" "$TMP_DIR/sfx_padded.mp4"; do
  duration="$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$output")"
  awk -v duration="$duration" 'BEGIN { if (duration < 1.95 || duration > 2.05) exit 1 }' || {
    echo "FAIL: $(basename "$output") duration was $duration seconds (expected about 2)" >&2
    exit 1
  }
  echo "PASS: $(basename "$output") duration $duration seconds"
done
