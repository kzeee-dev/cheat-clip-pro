import assert from 'node:assert/strict';
import { consumeSseBuffer } from '../src/utils/sseParser.ts';

const payload = [
  { step: 2, message: 'Working' },
  { done: true, result: { clips: [] } },
];

for (const [label, separator] of [['LF', '\n'], ['CRLF', '\r\n'], ['CR', '\r']]) {
  const stream = payload.map(value => `data: ${JSON.stringify(value)}${separator}${separator}`).join('');
  for (let chunkSize = 1; chunkSize <= 11; chunkSize++) {
    let buffer = '';
    const events = [];
    for (let offset = 0; offset < stream.length; offset += chunkSize) {
      buffer += stream.slice(offset, offset + chunkSize);
      const parsed = consumeSseBuffer(buffer);
      events.push(...parsed.events);
      buffer = parsed.remainder;
    }
    const trailing = consumeSseBuffer(buffer, true);
    events.push(...trailing.events);
    assert.deepEqual(events, payload, `${label}, chunk size ${chunkSize}`);
  }
  console.log(`PASS ${label} separators across 11 chunk sizes`);
}

const noFinalDelimiter = `data: ${JSON.stringify(payload[1])}`;
assert.deepEqual(consumeSseBuffer(noFinalDelimiter, true).events, [payload[1]]);
assert.equal(consumeSseBuffer('data: {"step":', false).events.length, 0);
assert.equal(consumeSseBuffer('event: ping\n\n').events.length, 0);
assert.deepEqual(
  consumeSseBuffer('data: {"joined":\ndata: true}\n\n').events,
  [{ joined: true }],
);
console.log('PASS final flush, incomplete chunks, comments/metadata, multiline data');
