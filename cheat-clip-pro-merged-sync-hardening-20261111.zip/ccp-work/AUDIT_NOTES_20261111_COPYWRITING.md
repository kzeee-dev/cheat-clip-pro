# Cheat Clip Pro — Copywriting Audit (2026-11-11)

## Change
Updated the three `is_mock` demo clip examples in `backend/routers/analyze.py`.

- Replaced exaggerated/unsupported marketing promises (e.g. guaranteed viral hotspots, scaling views, revolutionizing workflow) with neutral descriptions grounded in each mock transcript.
- Made primary and alternative titles specific while using distinct wording.
- Kept captions concise and tied to the demo clip content.
- Replaced generic growth/viral hashtags with topic-specific tags.

## Checks
- `python -m compileall -q backend`: passed.
- Python AST parse: passed.
- Static assertions for all three mock titles/captions, removal of the old hype claims, and preservation of transcript-language / visual-only safety rules: passed.

## Scope and limitations
- This pass changes mock/demo data only; production model prompt routing and runtime behavior are unchanged.
- No API calls, real video analysis, frontend build, Android Gradle build, APK build, or device test were performed.
- Existing release APK, signing files, and release configuration were not modified.

## Follow-up production prompt hardening
Updated the production analysis prompt in `backend/routers/analyze.py` and OpenRouter system instruction in `backend/services/openrouter_service.py`:

- Renamed the channel context label to `Channel metadata (source label only; NOT verified speaker identity)`.
- Explicitly prohibit attributing dialogue, opinions, expertise, or actions to the channel name.
- Strengthened OpenRouter's neutral attribution rule: channel/creator metadata is never proof of speaker identity or role.

This removes a prompt-level contradiction that could encourage models to treat a channel label as the person speaking.

### Follow-up checks
- `python -m compileall -q backend`: passed.
- AST parse for both edited Python modules: passed.
- Static assertions for the new metadata wording and attribution restrictions: passed.
- Full Gemini/OpenRouter API calls and real-video output checks remain unperformed because they require external credentials/network access.

## Follow-up — server-side copy validation (11 Nov 2026)

- Added conservative transcript quote verification before constructing the API response. Only string quotes with at least three normalized words that occur in the reconstructed clip transcript are retained; duplicates are removed and at most two are exposed. Visual-only mode and malformed quote values always produce an empty quote list.
- Hashtag suggestions are now parsed as actual hashtag tokens, lowercased, deduplicated, limited to six, and malformed/non-string values are discarded. The server does not fabricate tags to meet the prompt's requested minimum count; semantic relevance still depends on model output and is not reliably machine-verifiable here.
- Caption suggestions are accepted only as strings and capped at 500 characters. Malformed non-object clip candidates are skipped rather than crashing final response assembly. Clip transcript reconstruction now ignores malformed transcript line entries.
- Validation: backend `compileall` passed; isolated helper regression tests passed 10/10 (exact quote retained, invented/short/duplicate quotes rejected, visual-only quotes empty, malformed quote inputs safe, hashtag lowercase/deduplication/cap/format handling).
- Limitations: no live Gemini/OpenRouter request, real-video integration test, frontend build, Gradle build, APK build, or device runtime test. Hashtag topical relevance and title/caption factuality cannot be proven by syntax checks alone.
- Existing release APK, release signing material, and release configuration remain untouched.

## Follow-up: server-side copy validation hardening (11 Nov 2026)

- Extracted the dependency-light AI copy validators into `backend/utils/copy_validation.py` so they can be tested independently from optional backend integrations.
- Enforced a maximum of eight whitespace-delimited words for generated primary and alternative titles; generic placeholder titles are cleared rather than replaced with invented copy.
- Alternative titles that normalize to the same wording as the primary title are cleared.
- Caption text is type-checked, normalized, and capped at 500 characters; score explanations are type-checked and capped at 300 characters.
- Summary output is type-checked and capped at 4,000 characters before being sent to the client.
- Non-object top-level AI payloads and non-list `clips` fields now degrade to an empty analysis rather than raising during response construction.
- Quote matching now caps candidate text before verification and checks only complete transcript lines fully contained inside the clip time range; boundary-crossing lines are not used as quote evidence, and visual-only mode has no quotes.
- Score normalization handles infinities/overflow and remains bounded to 0..100.
- Added `backend/tests/test_copy_validation.py` with 18 focused regression tests.

### Verification
- `python -m unittest discover -s backend/tests -v`: 18/18 passed.
- `python -m compileall -q backend`: passed.
- AST parsing of `backend/routers/analyze.py`, `backend/services/openrouter_service.py`, and `backend/schemas/analyze.py`: passed.
- The test module loads the dependency-light validator directly because this working environment lacks `youtube_transcript_api`; this does not validate full FastAPI startup.
- Semantic truthfulness of arbitrary title/caption claims cannot be conclusively proven by deterministic string validation. The prompt remains responsible for grounding those claims in transcript/visible evidence; server checks enforce shape, bounds, duplicate-title handling, and exact quote provenance.
- No real Gemini/OpenRouter API calls, frontend build, Android Gradle build, APK build, or device runtime test performed.
- Existing release APK, signing material, and release configuration were not modified.
- Additional schema smoke test: constructing and dumping a `ViralClip` Pydantic response with empty optional copy fields passed.
- Quote-range regression tests confirm boundary-crossing transcript lines are excluded from quote verification.

## Follow-up — frontend analysis stream hardening (11 Nov 2026)

- Added `src/utils/sseParser.ts`, a small streaming SSE parser that accepts LF, CRLF, and CR event delimiters, preserves incomplete events across network chunks, supports multi-line `data:` payloads, and flushes a final event even when the connection ends without a trailing blank line.
- Updated the `/api/analyze` client flow to surface non-2xx HTTP response details before attempting to read an SSE stream.
- Centralized progress/result event handling, bounds-checks progress values, ignores malformed progress metadata, and rejects a malformed completion payload instead of caching an unusable analysis result.
- Added `scripts/test-sse-parser.mjs` with chunk-boundary regression coverage for LF/CRLF/CR, final flush, incomplete events, metadata-only events, and multi-line data.

### Verification
- SSE parser TypeScript standalone check: passed.
- SSE parser regression script: passed across 11 chunk sizes for each of LF, CRLF, and CR; final-flush and multiline cases passed.
- Backend `compileall`: passed; copy-validation tests: 18/18 passed; edited Python modules AST-parse successfully.
- Full frontend TypeScript project check remains blocked because `vite/client` types are not installed (`TS2688`). No dependency install was attempted, to avoid changing or damaging the existing dependency state.
- No full Vite build, live SSE/backend integration, Gemini/OpenRouter API call, Gradle build, APK build, or Android device test was performed.
- Existing release APK, signing material, and release configuration remain untouched.


## Android DownloadManager filename collision hardening (2026-11-11)

- Native WebView downloads now append a short UUID suffix before the file extension. This prevents two downloads with the same suggested filename from targeting the same public Downloads path and causing a file-already-exists failure.
- Original extension and sanitized suggested filename are preserved. Download URL, WebView User-Agent/Cookie forwarding, destination folder, notification behavior, and multi-download tracking are unchanged.
- Validation: source-level checks only; Android Gradle compilation and device download tests remain unavailable in this workspace.


## Browser-render download completion ordering (2026-11-11)

- `triggerBrowserDownload` now returns `Promise<boolean>` and reports whether the download handoff was prepared successfully. Native mode resolves only after the Blob has been persisted through `/api/save-client-download` and the HTTP(S) download link has been triggered; failures are caught, shown to the user, and reported as `false`. Browser mode returns success after triggering the anchor download.
- Client-side batch rendering now awaits this result and marks a clip completed only after successful download handoff. A failed Android staging upload no longer produces a false completed state.
- Other one-off download call sites can continue calling the async helper without awaiting because the helper handles and surfaces its own errors.
- Validation: source-level checks and TypeScript transpilation; full app build and Android runtime test remain blocked by missing dependencies/toolchain.

## Render ZIP and retry hardening (2026-11-11)

- Added `backend/utils/archive.py` with dependency-light `create_nonempty_zip()`:
  - Writes to a uniquely named temporary file in the destination directory and atomically replaces the published ZIP only after a successful non-empty archive is complete.
  - Skips missing/zero-byte source files and removes stale ZIP output when no usable completed clips remain.
  - Cleans up temporary files after both success and failure; a failed write preserves a previously published archive.
- Updated `update_batch_summary_and_zip()` to include only completed clips whose MP4 files still exist and are non-empty. It now clears `zip_url` when no valid files can be packaged.
- Updated `/api/download-batch-zip/{batch_id}` fallback packaging to include only completed clips, sanitize the source basename, reject empty/corrupt existing archives, and use the same atomic archive helper. A batch with no completed files now returns HTTP 404 rather than an empty ZIP.
- Hardened `/api/render-batch/{batch_id}/retry`: explicitly requested indices must all refer to clips currently in `error` state; duplicate indices are normalized and completed/pending clips cannot be accidentally re-rendered through the retry endpoint.
- Added `backend/tests/test_archive.py` (3 tests): successful archive with duplicate display names, no empty/stale ZIP, and preservation of a previous archive after a simulated write failure.
- Verification: archive unit tests 3/3 passed; copy-validation tests 18/18 passed; SSE parser regression script passed; Python syntax compilation passed for archive helper, render service, render router, and archive tests.
- Not verified: full backend runtime/import, live render/ZIP download, Gradle/APK build, and Android device behavior remain untested because optional dependencies/toolchain are unavailable in this environment.

## Render audio-duration hardening (2026-11-11)

- Fixed the FFmpeg audio graph in `backend/video_engine.py` so original audio,
  background music, and hook SFX are each normalized to the requested clip
  duration with `apad=whole_dur` followed by `atrim=duration`.
- Changed multi-source mixing from `amix duration=first` to bounded
  `duration=longest`; each source now has the same explicit target duration.
- This prevents a short source audio track or short hook SFX from causing
  `-shortest` to truncate the rendered video. A clip without any audio source
  continues to use the optional source-audio map.
- Added `scripts/test-render-audio-duration.sh` as a reproducible FFmpeg
  integration check for short original audio and short standalone SFX.
- Verified locally with FFmpeg/ffprobe: both generated outputs were exactly
  2.000 seconds for a 2-second video despite 0.4-second original audio and
  0.25-second SFX inputs.
- Regression suite: 21 backend tests passed; SSE parser tests passed; Python
  compileall and AST parsing passed. Full app/backend runtime and Android
  device/build validation remain outstanding due missing project dependencies
  and Android SDK/toolchain in this environment.

## Aspect-ratio output validation (2026-11-11)

- Executed the current `build_ffmpeg_filtergraph` outputs through FFmpeg using
  a synthetic 1280x720 source for every standard output ratio.
- Verified output dimensions: 9:16 = 1080x1920; 1:1 = 1080x1920 canvas;
  4:3 = 1080x1920 canvas; 16:9 = 1080x1920 canvas; and
  16:9_landscape = 1920x1080.
- No aspect-ratio filter changes were needed; all five tested graphs rendered
  successfully and matched their expected canvas dimensions.

## Subtitle positioning input hardening (2026-11-11)

- Hardened `generate_ass_file` against malformed render settings received from
  older clients or direct API requests.
- Subtitle/title percentage inputs now reject non-numeric and non-finite values
  and clamp accepted values to the 0-100 range before position calculations.
- Subtitle position mode is restricted to `bottom` or `center`; unknown values
  safely fall back to `bottom`.
- Subtitle timing offset is normalized to a finite number and bounded to
  +/-30 seconds to prevent pathological timestamp shifts.
- Verification: Python compile/AST checks passed; source assertions confirmed
  the finite-number guards, clamps, mode allowlist, and offset bounds. Existing
  copy-validation tests (18/18), SSE parser tests, and FFmpeg audio-duration
  integration checks passed again.
- A direct runtime ASS-generation test could not run because importing the
  video engine currently requires the unavailable `youtube_transcript_api`
  dependency. No claim is made that the full subtitle render path was tested.

## Watermark renderer input hardening (2026-11-11)

- Added renderer-boundary finite-number normalization for watermark size, opacity, and center-anchor X/Y positions. This protects direct/older API clients in addition to UI controls.
- Watermark center-anchor X/Y are constrained to 0..100%; prior -100..200% range could move the mark completely off-canvas.
- Watermark size is constrained to 0..500%; opacity to 0..1. Invalid, NaN, and infinite values fall back to safe defaults before FFmpeg filter construction.
- Added source-level regression tests for normal values, out-of-range values, NaN, infinity, and invalid strings.
- Runtime render/device verification remains pending because the complete media/transcription dependencies and Android toolchain are not installed in this environment.

## Font consistency audit — 2026-11-11

- Fixed custom-font resolution mismatch: the UI stores the embedded family name, while uploaded font files are stored using the uploaded filename. Pillow overlays and FFmpeg drawtext now resolve `.ttf`/`.otf` files by embedded family name as well as filename/stem.
- Custom font upload no longer overwrites an existing bundled or user font with the same filename; collisions receive a unique suffix.
- Restricted custom-font uploads and renderer font discovery to `.ttf`/`.otf`, because the backend Pillow/libass rendering path cannot reliably consume browser-only `.woff`/`.woff2` uploads. The UI advertises the supported formats.
- Removed `Impact` and `Arial Black` from the selectable built-in font list because matching renderer font files are not bundled; this avoids preview/render font mismatch.
- Added regression tests for custom family-name resolution, FFmpeg font path selection, and Montserrat fallback.
- Full app import/render integration remains unverified in this environment because `youtube_transcript_api` and other optional runtime dependencies are absent.

## Preview/render typography consistency — 2026-11-11

- Aligned all seven subtitle preset highlight colors between the React preview and ASS renderer. `clean_minimal` now uses the same blue (`#38BDF8`) in both paths; the renderer's ASS BGR value is `&H00F8BD38`.
- Added preview outline and shadow styling based on each renderer preset's actual outline/shadow widths, scaled by the preview-to-render canvas ratio. The preset outline colors and widths now track the ASS style values.
- Removed the preview-only 8% active-word enlargement. The ASS karaoke renderer deliberately keeps word metrics unchanged, so the preview no longer distorts line width while a word is highlighted.
- Aligned title preview size with the renderer's existing 1.30 title-font multiplier and scaled title outline/shadow to the preview canvas.
- Added source-level regression tests for preset color parity, subtitle outline/shadow scaling, active-word sizing, and title typography scaling.
- Verification: combined Python tests passed (26/26); `python -m compileall -q backend` passed; standalone TypeScript transpile of `ClipStudioSection.tsx` passed. Full Vite/typecheck, real ASS generation/rendering, and Android build/device testing remain unavailable/unperformed in this environment.

## Subtitle timing and clip-boundary hardening — 2026-11-11

- Added a shared subtitle word-time normalizer that applies the user sync offset,
  rejects malformed/non-finite/reversed intervals, sorts events, and clamps all
  accepted timestamps to the actual clip duration.
- Subtitle chunks are now re-clamped after overlap repair, preventing boundary
  adjustments from extending ASS dialogue beyond the rendered clip.
- Corrected ASS centisecond rounding to carry across second/minute boundaries
  (for example, 1.999 seconds formats as 2.00 rather than 1.99).
- Added five source-level regression tests covering offsets, clip bounds,
  invalid/NaN/infinite timestamps, and ASS timestamp carry behavior.
- Verification: full backend test suite passed (34/34); Python compileall passed;
  standalone TypeScript transpile of `ClipStudioSection.tsx` passed.
- Full ASS renderer integration, live audio/subtitle synchronization, Vite
  project typecheck/build, Android APK build, and device playback remain
  unperformed because the required runtime dependencies/toolchain are absent.

## 2026-11-11 — Whisper and fallback transcript timing hardening

- Normalized clip source bounds once and used the validated values when selecting transcript context and converting source-absolute fallback transcript timestamps to clip-relative timestamps.
- Malformed/non-finite fallback line starts are skipped safely; malformed end/duration values no longer abort the entire fallback path, and a valid duration can still be used when the explicit end is invalid.
- Fallback transcript entries that are not objects are ignored; text values are converted safely before cleaning.
- Whisper word timestamps now reject malformed, NaN/infinite, and reversed intervals before clamping; this prevents Python `max()` from accidentally turning NaN into an apparently valid zero-based timestamp.
- Both Whisper and transcript fallback word intervals are normalized to the downloaded clip duration, preventing subtitles from extending beyond the clip.
- Added regression tests for malformed fallback entries, invalid end/duration recovery, Whisper NaN rejection, and clip-bound enforcement.
- Validation: `python -m pytest -q backend/tests` — 37 passed; `python -m compileall -q backend` — passed.
- Limitations unchanged: no live Whisper model/audio run, no real video subtitle sync validation, no Android build/device test. Existing release APK and signing configuration remain untouched.

## 2026-11-11 — Merged-clip subtitle offset alignment

- Merged rendering now probes each downloaded segment's actual media duration and uses that measured duration when calculating the next segment's subtitle offset; requested source in/out duration remains a safe fallback if ffprobe cannot provide a valid duration.
- Merged output duration is probed after concatenation and used for ASS subtitle bounds/title duration rather than relying only on the sum of requested segment durations.
- Added `_append_segment_words()` to reject malformed/non-finite word intervals and clip each segment's local word timestamps to that segment's actual duration before applying its merged timeline offset. This prevents fallback words at the end of a short segment from spilling into the next segment.
- Added regression tests for measured duration preference/fallback, segment-local word clipping, and merged pipeline wiring.
- Validation: `python -m pytest -q backend/tests` — 42 passed; `python -m compileall -q backend` — passed.
- Limitations unchanged: no live FFmpeg/Whisper run on a real source video, no real multi-segment A/V sync playback, no Android build/device test. Existing release APK and signing configuration remain untouched.
