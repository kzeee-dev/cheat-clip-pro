/** Parse complete Server-Sent Events from a streaming text buffer. */
export interface SseBufferResult<T = unknown> {
  events: T[];
  remainder: string;
}

function parseEventBlock<T>(block: string): T | undefined {
  const dataLines = block
    .split(/\r\n|\n|\r/)
    .filter(line => line.startsWith('data:'))
    .map(line => line.slice(5).replace(/^ /, ''));
  if (dataLines.length === 0) return undefined;
  const payload = dataLines.join('\n');
  try {
    return JSON.parse(payload) as T;
  } catch {
    // Ignore malformed events; a later valid event may still complete the stream.
    return undefined;
  }
}

/** Supports LF, CRLF, and CR delimiters, including delimiters split across chunks. */
export function consumeSseBuffer<T = unknown>(buffer: string, flush = false): SseBufferResult<T> {
  const events: T[] = [];
  const separator = /(?:\r\n|\n|\r){2}/g;
  let consumed = 0;
  let match: RegExpExecArray | null;

  while ((match = separator.exec(buffer)) !== null) {
    const event = parseEventBlock<T>(buffer.slice(consumed, match.index));
    if (event !== undefined) events.push(event);
    consumed = separator.lastIndex;
  }

  let remainder = buffer.slice(consumed);
  if (flush && remainder.trim()) {
    const event = parseEventBlock<T>(remainder);
    if (event !== undefined) events.push(event);
    remainder = '';
  }
  return { events, remainder };
}
